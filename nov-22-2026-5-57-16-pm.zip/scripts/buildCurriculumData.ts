import fs from 'node:fs';
import path from 'node:path';

const ASSETS_DIR = path.resolve(process.cwd(), 'public/assets/aistudio');
const OUT_DIR = path.resolve(process.cwd(), 'src/data/curriculum');

type UnitId = 'unit1' | 'unit2' | 'unit3';
type Difficulty = 'سهل' | 'متوسط' | 'متقدم';
type SkillType = 'فهم ومفاهيم' | 'حسابات كيميائية' | 'معادلات وتفاعلات';
type SourceTag = 'بنك الدرس' | 'استنتاجي فائق' | 'متفوقين ومستويات عليا';

interface ParsedTable {
  headers: string[];
  rows: string[][];
}

interface ParsedBlock {
  type: 'paragraph' | 'formula' | 'example' | 'table' | 'analogy' | 'bullet';
  title?: string;
  content?: string;
  items?: string[];
  table?: ParsedTable;
}

interface ParsedLessonSection {
  title: string;
  body: string;
  equation?: string;
  blocks: ParsedBlock[];
}

interface ParsedLessonCheckMcq {
  id: string;
  kind: 'mcq';
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

interface ParsedLessonCheckEssay {
  id: string;
  kind: 'essay';
  question: string;
  modelAnswer: string;
}

type ParsedLessonCheck = ParsedLessonCheckMcq | ParsedLessonCheckEssay;

interface ParsedLesson {
  id: string;
  lessonNumber: number;
  unitId: UnitId;
  unitName: string;
  numberLabel: string;
  title: string;
  summary: string;
  coreIdea: string;
  curriculumImportance: string;
  durationMin: number;
  level: 'أساسي' | 'متوسط' | 'متقدم';
  coverImage: string;
  objectives: string[];
  sections: ParsedLessonSection[];
  examTip: string;
  examTraps: string[];
  focusPoints: string[];
  quickCheck: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
  practiceChecks: ParsedLessonCheck[];
}

interface ParsedRevisionLesson {
  lessonId: string;
  lessonNumber: number;
  unitId: UnitId;
  unitName: string;
  numberLabel: string;
  lessonTitle: string;
  points: Array<{
    id: string;
    index: number;
    text: string;
    subPoints: string[];
  }>;
}

interface ParsedMcq {
  id: string;
  unitId: UnitId;
  unit: string;
  lessonId: string;
  lessonTitle: string;
  subTopicId: string;
  subTopicTitle: string;
  difficulty: Difficulty;
  skillType: SkillType;
  sourceTag: SourceTag;
  sectionIndex: number;
  question: string;
  formula?: string;
  hint: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

interface ParsedEssay {
  id: string;
  unitId: UnitId;
  unit: string;
  lessonId: string;
  lessonTitle: string;
  subTopicId: string;
  subTopicTitle: string;
  difficulty: Difficulty;
  sourceTag: SourceTag;
  sectionIndex: number;
  question: string;
  modelAnswer: string;
}

const UNIT_NAMES: Record<UnitId, string> = {
  unit1: 'الباب الأول: الحساب الكيميائي',
  unit2: 'الباب الثاني: بنية الذرة',
  unit3: 'الباب الثالث: الجدول الدوري وتصنيف العناصر',
};

const UNIT_IMAGES: Record<UnitId, string> = {
  unit1: '/src/assets/images/lesson_atomic_orbitals_1795317629331.jpg',
  unit2: '/src/assets/images/lesson_electrochemistry_cell_1795317627843.jpg',
  unit3: '/src/assets/images/lesson_organic_benzene_1795317627662.jpg',
};

const SUBLESSON_TO_MASTER: Record<
  number,
  { lessonNum: number; unitId: UnitId; subTopicTitle: string; filename: string }
> = {
  1: {
    lessonNum: 1,
    unitId: 'unit1',
    subTopicTitle: 'المول والكتلة المولية',
    filename: '01_______________________44dae73f',
  },
  2: {
    lessonNum: 1,
    unitId: 'unit1',
    subTopicTitle: 'الحجم المولي للغازات وفرض أفوجادرو',
    filename: '02____________________________________5b01d403',
  },
  3: {
    lessonNum: 2,
    unitId: 'unit1',
    subTopicTitle: 'الحساب الكيميائي والعامل المحدد للتفاعل',
    filename: '03_________________________________________4c95c373',
  },
  4: {
    lessonNum: 3,
    unitId: 'unit1',
    subTopicTitle: 'حساب الصيغ الكيميائية',
    filename: '04_______________________92f7bc7e',
  },
  5: {
    lessonNum: 4,
    unitId: 'unit1',
    subTopicTitle: 'تركيز المحاليل وتخفيفها',
    filename: '05_________________________f76b0204',
  },
  6: {
    lessonNum: 5,
    unitId: 'unit2',
    subTopicTitle: 'تطور مفهوم بنية الذرة (طومسون ورذرفورد)',
    filename: '06_______________________________________674f1c0c',
  },
  7: {
    lessonNum: 6,
    unitId: 'unit2',
    subTopicTitle: 'طيف الانبعاث ونموذج ذرة بور',
    filename: '07_____________________________3efaf02b',
  },
  8: {
    lessonNum: 7,
    unitId: 'unit2',
    subTopicTitle: 'النظرية الذرية الحديثة وأعداد الكم',
    filename: '08____________________________________de27a7df',
  },
  9: {
    lessonNum: 8,
    unitId: 'unit2',
    subTopicTitle: 'قواعد توزيع الإلكترونات',
    filename: '09_________________________891bdb69',
  },
  10: {
    lessonNum: 9,
    unitId: 'unit3',
    subTopicTitle: 'الجدول الدوري الحديث وتصنيف العناصر',
    filename: '10_____________________________________4a85d430',
  },
  11: {
    lessonNum: 10,
    unitId: 'unit3',
    subTopicTitle: 'تدرج نصف القطر وجهد التأين',
    filename: '11____________________________0e7ab0dd',
  },
  12: {
    lessonNum: 10,
    unitId: 'unit3',
    subTopicTitle: 'تدرج الميل الإلكتروني والسالبية الكهربية',
    filename: '12__________________________________________6a2199c4',
  },
  13: {
    lessonNum: 11,
    unitId: 'unit3',
    subTopicTitle: 'الخاصية الفلزية واللافلزية والأكاسيد',
    filename: '13______________________________________8a04da26',
  },
  14: {
    lessonNum: 12,
    unitId: 'unit3',
    subTopicTitle: 'أعداد التأكسد وتفاعلات الأكسدة والاختزال',
    filename: '14__________________________________________8120da09',
  },
};

const LETTER_TO_INDEX: Record<string, number> = {
  أ: 0,
  ا: 0,
  ب: 1,
  ج: 2,
  د: 3,
};

function readUtf8(filename: string): string {
  const fullPath = path.join(ASSETS_DIR, filename);
  return fs.readFileSync(fullPath, 'utf8').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
}

function getUnitIdForLessonNum(lessonNum: number): UnitId {
  if (lessonNum <= 4) return 'unit1';
  if (lessonNum <= 8) return 'unit2';
  return 'unit3';
}

function isDashedSep(line: string): boolean {
  const t = line.trim();
  return /^-{10,}$/.test(t);
}

function isEqSep(line: string): boolean {
  const t = line.trim();
  return /^={10,}$/.test(t);
}

function inferSkillType(question: string, explanation: string, unitId: UnitId): SkillType {
  const combined = `${question} ${explanation}`;
  if (
    /→|⇌|معادلة|تفاعل|انحلال|أكسيد|أكسدة|اختزال|موازنة|عامل مؤكسد|عامل مختزل|تفكك/.test(
      combined
    )
  ) {
    if (/احسب|مول|g\/mol|كتلة|حجم|تركيز|M|مولارية|نسبة مئوية|L|mL/.test(question)) {
      return 'حسابات كيميائية';
    }
    return 'معادلات وتفاعلات';
  }
  if (
    unitId === 'unit1' ||
    /احسب|كم |كتلة|مول|حجم|تركيز|M₁|V₁|g\/mol|22\.4|24|6\.02|صيغة أولية|صيغة جزيئية|عدد تأكسد|كم عدد/.test(
      question
    )
  ) {
    return 'حسابات كيميائية';
  }
  return 'فهم ومفاهيم';
}

function inferBankDifficulty(questionNum: number, question: string): Difficulty {
  // Within each 50-MCQ lesson bank, questions naturally ramp from foundational to harder applications
  if (
    questionNum >= 38 ||
    /النسبة المئوية|خليط|عينة غير نقية|متبقية|استنتج|شذوذ|الترتيب الصحيح|أعلى حالة|أي العبارات.*صحيحة/.test(
      question
    )
  ) {
    return 'متقدم';
  }
  if (questionNum <= 15) {
    return 'سهل';
  }
  return 'متوسط';
}

function buildSmartHint(question: string, explanation: string, lessonTitle: string): string {
  const firstClause = explanation.split(/[؛.،]/)[0]?.trim() ?? '';
  if (firstClause.length >= 16 && firstClause.length <= 130) {
    // Avoid giving away the exact letter answer if present
    if (!/^[أبجد]\s*-/.test(firstClause)) {
      return `تلميح منهجي (${lessonTitle}): راجع علاقة "${firstClause.slice(0, 95)}${
        firstClause.length > 95 ? '...' : ''
      }".`;
    }
  }
  return `راجع قوانين ومفاهيم درس «${lessonTitle}» وطبّق القاعدة خطوة بخطوة قبل اختيار الإجابة.`;
}

function extractFormulaFromText(text: string): string | undefined {
  const eqMatch = text.match(/([A-Z][A-Za-z0-9₀-₉⁺⁻·()]*\s*(?:\+\s*[A-Za-z0-9₀-₉⁺⁻·()]+\s*)*(?:→|⇌|--[^>]+>)\s*[A-Za-z0-9₀-₉⁺⁻·()+\s]+)/);
  if (eqMatch && eqMatch[1].trim().length >= 8 && eqMatch[1].trim().length <= 90) {
    return eqMatch[1].trim();
  }
  return undefined;
}

function inferSectionIndex(text: string, sections: ParsedLessonSection[]): number {
  if (sections.length <= 1) return 0;
  const words = text
    .replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 3);

  let bestIdx = 0;
  let bestScore = -1;
  sections.forEach((sec, idx) => {
    const haystack = `${sec.title} ${sec.body}`;
    let score = 0;
    for (const w of words) {
      if (sec.title.includes(w)) score += 3;
      else if (haystack.includes(w)) score += 1;
    }
    if (score > bestScore) {
      bestScore = score;
      bestIdx = idx;
    }
  });
  return bestIdx;
}

// ============================================================================
// 1. PARSE ALL 12 LESSONS FROM `_________________12_____5e8fd798`
// ============================================================================
function parseSectionBlocks(rawLines: string[]): { blocks: ParsedBlock[]; body: string; equation?: string } {
  const blocks: ParsedBlock[] = [];
  const plainParts: string[] = [];
  let firstEquation: string | undefined;

  let i = 0;
  while (i < rawLines.length) {
    const line = rawLines[i].trim();
    if (!line) {
      i += 1;
      continue;
    }

    // Boxed formula / rule between ------- and -------
    if (isDashedSep(line)) {
      const boxLines: string[] = [];
      i += 1;
      while (i < rawLines.length && !isDashedSep(rawLines[i])) {
        const bl = rawLines[i].trim();
        if (bl) boxLines.push(bl);
        i += 1;
      }
      if (i < rawLines.length && isDashedSep(rawLines[i])) i += 1;

      if (boxLines.length > 0) {
        const title = boxLines.length > 1 ? boxLines[0] : 'قانون / قاعدة أساسية';
        const content = boxLines.length > 1 ? boxLines.slice(1).join('\n') : boxLines[0];
        blocks.push({ type: 'formula', title, content });
        if (!firstEquation) firstEquation = content.replace(/\n/g, '  |  ');
        plainParts.push(`${title}: ${content}`);
      }
      continue;
    }

    // Pipe Table: Header line with | followed by ----- and data rows with |
    if (
      line.includes('|') &&
      i + 1 < rawLines.length &&
      (isDashedSep(rawLines[i + 1]) || rawLines[i + 1].includes('|'))
    ) {
      const headers = line.split('|').map((c) => c.trim()).filter(Boolean);
      const rows: string[][] = [];
      i += 1;
      if (i < rawLines.length && isDashedSep(rawLines[i])) i += 1;
      while (i < rawLines.length && rawLines[i].trim().includes('|')) {
        const cells = rawLines[i].trim().split('|').map((c) => c.trim());
        if (cells.length >= 2) rows.push(cells);
        i += 1;
      }
      if (headers.length >= 2 && rows.length > 0) {
        blocks.push({ type: 'table', table: { headers, rows } });
        plainParts.push(rows.map((r) => r.join(' — ')).join('\n'));
        continue;
      }
    }

    // Feynman analogy or intuition note
    if (/^(تشبيه|تخيل|مثلاً في الحياة|تقريب|قصة|تشبيه فاينمان)/.test(line)) {
      blocks.push({ type: 'analogy', title: 'تشبيه وتقريب للفهم العميق', content: line });
      plainParts.push(line);
      i += 1;
      continue;
    }

    // Worked Example / Application block
    if (/^(مثال\s|تطبيق\s|تطبيقات\s|مسألة\s|مقارنة\s)/.test(line)) {
      const title = line;
      const exampleItems: string[] = [];
      i += 1;
      while (i < rawLines.length) {
        const nextLine = rawLines[i].trim();
        if (!nextLine) {
          i += 1;
          continue;
        }
        if (
          isDashedSep(nextLine) ||
          /^(المحور|مثال\s|تطبيق\s|تطبيقات\s|مسألة\s|تدريبات التحقق|فخاخ الامتحانات|أهم النقاط)/.test(
            nextLine
          ) ||
          (nextLine.includes('|') && i + 1 < rawLines.length && isDashedSep(rawLines[i + 1]))
        ) {
          break;
        }
        // Keep collecting lines belonging to the example (المثال:, - الخطوة, equations, etc.)
        if (
          /^(المثال:|المعادلة|علماً بأن|- |•|[0-9]+\s*-|الخطوة|الحل|الاستنتاج|النتيجة|المطلوب)/.test(
            nextLine
          ) ||
          /→|⇌/.test(nextLine) ||
          exampleItems.length === 0
        ) {
          exampleItems.push(nextLine.replace(/^-\s*/, ''));
          if (!firstEquation && /→|⇌/.test(nextLine)) {
            firstEquation = nextLine;
          }
          i += 1;
        } else {
          break;
        }
      }
      blocks.push({ type: 'example', title, items: exampleItems });
      plainParts.push(`${title}: ${exampleItems.join(' ')}`);
      continue;
    }

    // Bullet list
    if (line.startsWith('- ') || line.startsWith('• ')) {
      const items: string[] = [];
      while (i < rawLines.length) {
        const cur = rawLines[i].trim();
        if (cur.startsWith('- ') || cur.startsWith('• ')) {
          items.push(cur.replace(/^[-•]\s*/, ''));
          i += 1;
        } else if (!cur) {
          // check if next non-empty line is also a bullet
          let peek = i + 1;
          while (peek < rawLines.length && !rawLines[peek].trim()) peek += 1;
          if (peek < rawLines.length && /^[-•]\s/.test(rawLines[peek].trim())) {
            i = peek;
          } else {
            break;
          }
        } else {
          break;
        }
      }
      blocks.push({ type: 'bullet', items });
      plainParts.push(items.join(' • '));
      continue;
    }

    // Standalone equation line
    if (/→|⇌/.test(line) && line.length <= 120 && !/[؟?]/.test(line)) {
      blocks.push({ type: 'formula', title: 'معادلة كيميائية', content: line });
      if (!firstEquation) firstEquation = line;
      plainParts.push(line);
      i += 1;
      continue;
    }

    // Regular paragraph
    blocks.push({ type: 'paragraph', content: line });
    plainParts.push(line);
    i += 1;
  }

  return {
    blocks,
    body: plainParts.join('\n').slice(0, 600),
    equation: firstEquation,
  };
}

function parsePracticeChecks(lessonId: string, lines: string[]): ParsedLessonCheck[] {
  const checks: ParsedLessonCheck[] = [];
  const nonEmpty = lines.map((l) => l.trim()).filter(Boolean);
  let i = 0;

  while (i < nonEmpty.length) {
    const line = nonEmpty[i];
    const qMatch = line.match(/^(\d+)\s*[-.]\s*(.+)$/);
    if (!qMatch) {
      i += 1;
      continue;
    }
    const qNum = Number(qMatch[1]);
    const questionText = qMatch[2].trim();
    i += 1;

    const options: string[] = [];
    let answerLine = '';
    let modelAnswer = '';

    while (i < nonEmpty.length && !/^\d+\s*[-.]\s*/.test(nonEmpty[i])) {
      const cur = nonEmpty[i];
      const optMatch = cur.match(/^([أابجد])\s*[-.)]\s*(.+)$/);
      if (optMatch) {
        options.push(optMatch[2].trim());
      } else if (cur.startsWith('الإجابة الصحيحة:')) {
        answerLine = cur;
      } else if (cur.startsWith('نموذج الإجابة:') || cur.startsWith('الإجابة النموذجية:')) {
        modelAnswer = cur.replace(/^(نموذج الإجابة:|الإجابة النموذجية:)\s*/, '').trim();
      } else if (modelAnswer) {
        modelAnswer += `\n${cur}`;
      } else if (answerLine) {
        answerLine += ` ${cur}`;
      }
      i += 1;
    }

    if (options.length >= 2 && answerLine) {
      const letterMatch = answerLine.match(/الإجابة الصحيحة:\s*([أابجد])\s*[-.)]?/);
      const correctIndex = letterMatch ? (LETTER_TO_INDEX[letterMatch[1]] ?? 0) : 0;
      const expMatch = answerLine.match(/(?:التفسير|التعليل)\s*:\s*(.+)$/);
      const explanation = expMatch ? expMatch[1].trim() : answerLine.replace(/^الإجابة الصحيحة:\s*/, '').trim();
      checks.push({
        id: `${lessonId}-check-${qNum}`,
        kind: 'mcq',
        question: questionText,
        options,
        correctIndex,
        explanation,
      });
    } else if (modelAnswer) {
      checks.push({
        id: `${lessonId}-check-${qNum}`,
        kind: 'essay',
        question: questionText,
        modelAnswer,
      });
    }
  }

  return checks;
}

function parse12Lessons(): ParsedLesson[] {
  const raw = readUtf8('_________________12_____5e8fd798');
  const lessonChunks = raw.split(/={10,}\s*الدرس\s+(\d+)\s*={10,}/);
  const lessons: ParsedLesson[] = [];

  for (let c = 1; c < lessonChunks.length; c += 2) {
    const lessonNum = Number(lessonChunks[c]);
    const body = lessonChunks[c + 1] ?? '';
    const lines = body.split('\n');
    const unitId = getUnitIdForLessonNum(lessonNum);
    const lessonId = `lesson-${lessonNum}`;

    // Parse header box (first dashed block)
    let idx = 0;
    while (idx < lines.length && !isDashedSep(lines[idx])) idx += 1;
    idx += 1; // skip opening -----
    const headerLines: string[] = [];
    while (idx < lines.length && !isDashedSep(lines[idx])) {
      const t = lines[idx].trim();
      if (t) headerLines.push(t);
      idx += 1;
    }
    if (idx < lines.length && isDashedSep(lines[idx])) idx += 1;

    const title = headerLines[1] ?? `الدرس ${String(lessonNum).padStart(2, '0')}`;
    const coreIdeaLine = headerLines.find((l) => l.startsWith('الفكرة المحورية:')) ?? '';
    const importanceLine = headerLines.find((l) => l.startsWith('موقعه وأهميته')) ?? '';
    const coreIdea = coreIdeaLine.replace(/^الفكرة المحورية:\s*/, '').trim();
    const curriculumImportance = importanceLine.replace(/^موقعه وأهميته في المنهج:\s*/, '').trim();

    const remainingLines = lines.slice(idx);

    // Split remaining lines into: axes (المحور...), examTraps, practiceChecks, focusPoints
    const sectionsRaw: Array<{ title: string; lines: string[] }> = [];
    const examTraps: string[] = [];
    const focusPoints: string[] = [];
    const practiceLines: string[] = [];

    let mode: 'axes' | 'traps' | 'practice' | 'focus' = 'axes';
    let currentAxis: { title: string; lines: string[] } | null = null;

    for (let li = 0; li < remainingLines.length; li += 1) {
      const rawLine = remainingLines[li];
      const trimmed = rawLine.trim();

      // Check transitions
      if (trimmed === 'فخاخ الامتحانات والأخطاء الشائعة') {
        mode = 'traps';
        continue;
      }
      if (trimmed.startsWith('تدريبات التحقق من الفهم')) {
        mode = 'practice';
        continue;
      }
      if (trimmed === 'أهم النقاط للتركيز أثناء المذاكرة') {
        mode = 'focus';
        continue;
      }

      if (mode === 'traps') {
        if (isDashedSep(trimmed)) {
          // end of traps box
          mode = 'axes';
          continue;
        }
        if (trimmed) {
          examTraps.push(trimmed.replace(/^\d+\s*[-.)]\s*/, ''));
        }
        continue;
      }

      if (mode === 'focus') {
        if (isDashedSep(trimmed)) {
          continue;
        }
        if (trimmed) {
          focusPoints.push(trimmed.replace(/^[-•]\s*/, ''));
        }
        continue;
      }

      if (mode === 'practice') {
        if (isDashedSep(trimmed)) {
          // Check if next non-empty line is أهم النقاط
          let peek = li + 1;
          while (peek < remainingLines.length && !remainingLines[peek].trim()) peek += 1;
          if (
            peek < remainingLines.length &&
            remainingLines[peek].trim() === 'أهم النقاط للتركيز أثناء المذاكرة'
          ) {
            mode = 'focus';
            li = peek; // skip title line too
            continue;
          }
        }
        practiceLines.push(rawLine);
        continue;
      }

      // mode === 'axes'
      if (isDashedSep(trimmed)) {
        // Peek if next non-empty line is traps or focus
        let peek = li + 1;
        while (peek < remainingLines.length && !remainingLines[peek].trim()) peek += 1;
        if (peek < remainingLines.length) {
          const nextT = remainingLines[peek].trim();
          if (nextT === 'فخاخ الامتحانات والأخطاء الشائعة') {
            mode = 'traps';
            li = peek;
            continue;
          }
          if (nextT === 'أهم النقاط للتركيز أثناء المذاكرة') {
            mode = 'focus';
            li = peek;
            continue;
          }
        }
      }

      if (/^المحور\s+/.test(trimmed)) {
        if (currentAxis) sectionsRaw.push(currentAxis);
        currentAxis = { title: trimmed, lines: [] };
        continue;
      }

      if (currentAxis) {
        currentAxis.lines.push(rawLine);
      } else if (trimmed && !isDashedSep(trimmed)) {
        currentAxis = { title: 'مقدمة ومحاور الدرس', lines: [rawLine] };
      }
    }
    if (currentAxis) sectionsRaw.push(currentAxis);

    const parsedSections: ParsedLessonSection[] = sectionsRaw.map((sec) => {
      const { blocks, body: secBody, equation } = parseSectionBlocks(sec.lines);
      return {
        title: sec.title,
        body: secBody,
        equation,
        blocks,
      };
    });

    const practiceChecks = parsePracticeChecks(lessonId, practiceLines);
    const firstMcq = practiceChecks.find((c): c is ParsedLessonCheckMcq => c.kind === 'mcq');
    if (!firstMcq) {
      throw new Error(`Lesson ${lessonNum} has no MCQ quickCheck!`);
    }

    const level: 'أساسي' | 'متوسط' | 'متقدم' =
      [1, 5, 9].includes(lessonNum)
        ? 'أساسي'
        : [4, 7, 10, 12].includes(lessonNum)
        ? 'متقدم'
        : 'متوسط';

    lessons.push({
      id: lessonId,
      lessonNumber: lessonNum,
      unitId,
      unitName: UNIT_NAMES[unitId],
      numberLabel: `الدرس ${String(lessonNum).padStart(2, '0')}`,
      title,
      summary: coreIdea || curriculumImportance,
      coreIdea,
      curriculumImportance,
      durationMin: 18 + (lessonNum % 3) * 4,
      level,
      coverImage: UNIT_IMAGES[unitId],
      objectives: parsedSections.map((s) => s.title.replace(/^المحور\s+\S+\s*-\s*/, '')),
      sections: parsedSections,
      examTip: examTraps[0] ?? focusPoints[0] ?? coreIdea,
      examTraps,
      focusPoints,
      quickCheck: {
        question: firstMcq.question,
        options: firstMcq.options,
        correctIndex: firstMcq.correctIndex,
        explanation: firstMcq.explanation,
      },
      practiceChecks,
    });
  }

  return lessons;
}

// ============================================================================
// 2. PARSE FINAL REVISION KEY POINTS (`______________________________________1_30be4403`)
// ============================================================================
function parseRevisionPoints(lessons: ParsedLesson[]): ParsedRevisionLesson[] {
  const raw = readUtf8('______________________________________1_30be4403');
  const lines = raw.split('\n');
  const result: ParsedRevisionLesson[] = [];

  let current: ParsedRevisionLesson | null = null;
  let currentPoint: ParsedRevisionLesson['points'][number] | null = null;

  for (const rawLine of lines) {
    const trimmed = rawLine.trim();
    if (!trimmed || isEqSep(trimmed) || isDashedSep(trimmed) || /^\*{10,}$/.test(trimmed)) {
      continue;
    }

    const lessonMatch = trimmed.match(/^الدرس\s+(\d+)\s*-\s*(.+)$/);
    if (lessonMatch) {
      const lessonNum = Number(lessonMatch[1]);
      const lessonTitle = lessonMatch[2].trim();
      const unitId = getUnitIdForLessonNum(lessonNum);
      current = {
        lessonId: `lesson-${lessonNum}`,
        lessonNumber: lessonNum,
        unitId,
        unitName: UNIT_NAMES[unitId],
        numberLabel: `الدرس ${String(lessonNum).padStart(2, '0')}`,
        lessonTitle,
        points: [],
      };
      result.push(current);
      currentPoint = null;
      continue;
    }

    if (!current) continue;

    const pointMatch = trimmed.match(/^(\d+)\s*-\s*(.+)$/);
    if (pointMatch) {
      const pIdx = Number(pointMatch[1]);
      currentPoint = {
        id: `rev-${current.lessonId}-${pIdx}`,
        index: pIdx,
        text: pointMatch[2].trim(),
        subPoints: [],
      };
      current.points.push(currentPoint);
      continue;
    }

    if (currentPoint) {
      if (trimmed.startsWith('- ') || /^\s{2,}/.test(rawLine)) {
        currentPoint.subPoints.push(trimmed.replace(/^-\s*/, ''));
      } else if (!trimmed.startsWith('الباب ')) {
        currentPoint.subPoints.push(trimmed);
      }
    }
  }

  if (result.length !== lessons.length) {
    throw new Error(`Expected ${lessons.length} revision lessons, got ${result.length}`);
  }
  return result;
}

// ============================================================================
// 3. PARSE 14 LESSON QUESTION BANK FILES (`01`..`14`) + FILE `15`
// ============================================================================
function parseNumberedQuestionBankFile(
  filename: string,
  idPrefix: string,
  defaultSubLessonNum: number | null,
  sourceTag: SourceTag,
  forcedDifficulty: Difficulty | null,
  lessonsByNum: Map<number, ParsedLesson>
): { mcqs: ParsedMcq[]; essays: ParsedEssay[] } {
  const raw = readUtf8(filename);
  const lines = raw.split('\n');

  const mcqs: ParsedMcq[] = [];
  const essays: ParsedEssay[] = [];

  let sectionMode: 'header' | 'mcq' | 'essay' = 'header';
  let currentBlock: string[] = [];

  const flushBlock = () => {
    const cleaned = currentBlock.map((l) => l.trim()).filter(Boolean);
    currentBlock = [];
    if (cleaned.length === 0 || sectionMode === 'header') return;

    const firstLine = cleaned[0];
    const qMatch = firstLine.match(/^(\d+)\s*[-.)]\s*(.+)$/);
    if (!qMatch) return;

    const qNum = Number(qMatch[1]);
    let rawQuestion = qMatch[2].trim();

    // Determine sub-lesson number (from [الدرس XX] prefix in file 15 or defaultSubLessonNum)
    let subLessonNum = defaultSubLessonNum ?? 1;
    const tagMatch = rawQuestion.match(/^\[الدرس\s+(\d+)\]\s*(.+)$/);
    if (tagMatch) {
      subLessonNum = Number(tagMatch[1]);
      rawQuestion = tagMatch[2].trim();
    }

    const mapping = SUBLESSON_TO_MASTER[subLessonNum] ?? SUBLESSON_TO_MASTER[1];
    const masterLesson = lessonsByNum.get(mapping.lessonNum)!;
    const unitId = mapping.unitId;
    const subTopicId = `sub-${String(subLessonNum).padStart(2, '0')}`;

    if (sectionMode === 'mcq') {
      const options: string[] = [];
      let answerLine = '';
      const extraQuestionLines: string[] = [];

      for (let i = 1; i < cleaned.length; i += 1) {
        const line = cleaned[i];
        const optMatch = line.match(/^([أابجد])\s*[-.)]\s*(.+)$/);
        if (optMatch) {
          options.push(optMatch[2].trim());
        } else if (line.startsWith('الإجابة الصحيحة:')) {
          answerLine = line;
        } else if (answerLine) {
          answerLine += ` ${line}`;
        } else if (options.length === 0) {
          extraQuestionLines.push(line);
        }
      }

      if (extraQuestionLines.length > 0) {
        rawQuestion = `${rawQuestion}\n${extraQuestionLines.join('\n')}`;
      }

      if (options.length !== 4 || !answerLine) {
        throw new Error(
          `Malformed MCQ #${qNum} in ${filename}: options=${options.length}, hasAns=${Boolean(answerLine)}`
        );
      }

      const letterMatch = answerLine.match(/الإجابة الصحيحة:\s*([أابجد])\s*[-.)]?/);
      const correctIndex = letterMatch ? LETTER_TO_INDEX[letterMatch[1]] : undefined;
      if (correctIndex === undefined) {
        throw new Error(`Could not parse answer letter for MCQ #${qNum} in ${filename}: ${answerLine}`);
      }

      const expMatch = answerLine.match(/(?:التعليل|التفسير)\s*:\s*(.+)$/);
      const explanation = expMatch
        ? expMatch[1].trim()
        : answerLine.replace(/^الإجابة الصحيحة:\s*/, '').trim();

      const difficulty = forcedDifficulty ?? inferBankDifficulty(qNum, rawQuestion);
      const skillType = inferSkillType(rawQuestion, explanation, unitId);
      const sectionIndex = inferSectionIndex(`${rawQuestion} ${explanation}`, masterLesson.sections);

      mcqs.push({
        id: `${idPrefix}-mcq-${qNum}`,
        unitId,
        unit: UNIT_NAMES[unitId],
        lessonId: masterLesson.id,
        lessonTitle: masterLesson.title,
        subTopicId,
        subTopicTitle: mapping.subTopicTitle,
        difficulty,
        skillType,
        sourceTag,
        sectionIndex,
        question: rawQuestion,
        formula: extractFormulaFromText(rawQuestion),
        hint: buildSmartHint(rawQuestion, explanation, masterLesson.title),
        options,
        correctIndex,
        explanation,
      });
    } else if (sectionMode === 'essay') {
      let modelAnswerLines: string[] = [];
      const extraQuestionLines: string[] = [];
      let inAnswer = false;

      for (let i = 1; i < cleaned.length; i += 1) {
        const line = cleaned[i];
        if (line.startsWith('الإجابة النموذجية:') || line.startsWith('نموذج الإجابة:')) {
          inAnswer = true;
          const after = line.replace(/^(الإجابة النموذجية:|نموذج الإجابة:)\s*/, '').trim();
          if (after) modelAnswerLines.push(after);
        } else if (inAnswer) {
          modelAnswerLines.push(line);
        } else {
          extraQuestionLines.push(line);
        }
      }

      if (extraQuestionLines.length > 0) {
        rawQuestion = `${rawQuestion}\n${extraQuestionLines.join('\n')}`;
      }

      const modelAnswer = modelAnswerLines.join('\n').trim();
      if (!modelAnswer) {
        throw new Error(`Malformed Essay #${qNum} in ${filename}: missing modelAnswer`);
      }

      const difficulty =
        forcedDifficulty ?? (qNum >= 88 ? 'متقدم' : qNum <= 65 ? 'سهل' : 'متوسط');
      const sectionIndex = inferSectionIndex(`${rawQuestion} ${modelAnswer}`, masterLesson.sections);

      essays.push({
        id: `${idPrefix}-essay-${qNum}`,
        unitId,
        unit: UNIT_NAMES[unitId],
        lessonId: masterLesson.id,
        lessonTitle: masterLesson.title,
        subTopicId,
        subTopicTitle: mapping.subTopicTitle,
        difficulty,
        sourceTag,
        sectionIndex,
        question: rawQuestion,
        modelAnswer,
      });
    }
  };

  for (const line of lines) {
    const trimmed = line.trim();
    if (/^أولاً:\s*القسم الأول/.test(trimmed)) {
      flushBlock();
      sectionMode = 'mcq';
      continue;
    }
    if (/^ثانياً:\s*القسم الثاني/.test(trimmed)) {
      flushBlock();
      sectionMode = 'essay';
      continue;
    }
    if (isEqSep(trimmed)) {
      flushBlock();
      continue;
    }
    if (sectionMode !== 'header') {
      currentBlock.push(line);
    }
  }
  flushBlock();

  return { mcqs, essays };
}

// ============================================================================
// 4. PARSE 60 DEDUCTIVE HARD QUESTIONS (`_________________________________________1_bef8dba6`)
// ============================================================================
function parse60DeductiveQuestions(
  lessonsByNum: Map<number, ParsedLesson>
): { mcqs: ParsedMcq[]; essays: ParsedEssay[] } {
  const raw = readUtf8('_________________________________________1_bef8dba6');
  const lines = raw.split('\n');

  const mcqs: ParsedMcq[] = [];
  const essays: ParsedEssay[] = [];

  let currentLessonNum = 1;
  let i = 0;

  while (i < lines.length) {
    const trimmed = lines[i].trim();
    if (!trimmed || isEqSep(trimmed) || isDashedSep(trimmed) || /^\*{10,}$/.test(trimmed)) {
      i += 1;
      continue;
    }

    const lessonMatch = trimmed.match(/^الدرس\s+(\d+)\s*-\s*(.+)$/);
    if (lessonMatch) {
      currentLessonNum = Number(lessonMatch[1]);
      i += 1;
      continue;
    }

    const qMatch = trimmed.match(/^(\d+)\s*-\s*(.+)$/);
    if (!qMatch) {
      i += 1;
      continue;
    }

    const qNum = Number(qMatch[1]);
    let questionText = qMatch[2].trim();
    i += 1;

    const options: string[] = [];
    let answerLetterLine = '';
    let explanationLine = '';
    let modelAnswer = '';
    let inModelAnswer = false;

    while (i < lines.length) {
      const cur = lines[i].trim();
      if (!cur) {
        i += 1;
        continue;
      }
      const nextNumMatch = cur.match(/^(\d+)\s*-\s+/);
      const isNextQuestion =
        nextNumMatch !== null &&
        Number(nextNumMatch[1]) === qNum + 1 &&
        (Boolean(answerLetterLine) || inModelAnswer);
      if (
        isDashedSep(cur) ||
        isEqSep(cur) ||
        /^\*{10,}$/.test(cur) ||
        /^الدرس\s+\d+\s*-/.test(cur) ||
        isNextQuestion
      ) {
        break;
      }
      const optMatch = cur.match(/^([أابجد])\s*[-.)]\s*(.+)$/);
      if (optMatch && !inModelAnswer) {
        options.push(optMatch[2].trim());
      } else if (cur.startsWith('الإجابة الصحيحة:')) {
        answerLetterLine = cur;
      } else if (cur.startsWith('التفسير:') || cur.startsWith('التعليل:')) {
        explanationLine = cur.replace(/^(التفسير:|التعليل:)\s*/, '').trim();
      } else if (cur.startsWith('نموذج الإجابة:') || cur.startsWith('الإجابة النموذجية:')) {
        inModelAnswer = true;
        const after = cur.replace(/^(نموذج الإجابة:|الإجابة النموذجية:)\s*/, '').trim();
        if (after) modelAnswer = after;
      } else if (inModelAnswer) {
        modelAnswer = modelAnswer ? `${modelAnswer}\n${cur}` : cur;
      } else if (explanationLine) {
        explanationLine += ` ${cur}`;
      } else if (options.length === 0 && !answerLetterLine) {
        questionText += `\n${cur}`;
      }
      i += 1;
    }

    const masterLesson = lessonsByNum.get(currentLessonNum)!;
    const unitId = masterLesson.unitId;
    const subTopicId = `deductive-l${String(currentLessonNum).padStart(2, '0')}`;

    if (options.length === 4 && answerLetterLine) {
      const letterMatch = answerLetterLine.match(/الإجابة الصحيحة:\s*([أابجد])\s*[-.)]?/);
      const correctIndex = letterMatch ? LETTER_TO_INDEX[letterMatch[1]] : undefined;
      if (correctIndex === undefined) {
        throw new Error(`Malformed deductive MCQ #${qNum}: ${answerLetterLine}`);
      }
      const explanation =
        explanationLine || answerLetterLine.replace(/^الإجابة الصحيحة:\s*/, '').trim();
      const skillType = inferSkillType(questionText, explanation, unitId);
      const sectionIndex = inferSectionIndex(
        `${questionText} ${explanation}`,
        masterLesson.sections
      );

      mcqs.push({
        id: `ded-mcq-${qNum}`,
        unitId,
        unit: UNIT_NAMES[unitId],
        lessonId: masterLesson.id,
        lessonTitle: masterLesson.title,
        subTopicId,
        subTopicTitle: masterLesson.title,
        difficulty: 'متقدم',
        skillType,
        sourceTag: 'استنتاجي فائق',
        sectionIndex,
        question: questionText,
        formula: extractFormulaFromText(questionText),
        hint: buildSmartHint(questionText, explanation, masterLesson.title),
        options,
        correctIndex,
        explanation,
      });
    } else if (modelAnswer) {
      const sectionIndex = inferSectionIndex(
        `${questionText} ${modelAnswer}`,
        masterLesson.sections
      );
      essays.push({
        id: `ded-essay-${qNum}`,
        unitId,
        unit: UNIT_NAMES[unitId],
        lessonId: masterLesson.id,
        lessonTitle: masterLesson.title,
        subTopicId,
        subTopicTitle: masterLesson.title,
        difficulty: 'متقدم',
        sourceTag: 'استنتاجي فائق',
        sectionIndex,
        question: questionText,
        modelAnswer,
      });
    } else {
      throw new Error(`Unrecognized deductive item #${qNum}: ${questionText}`);
    }
  }

  return { mcqs, essays };
}

// ============================================================================
// MAIN EXECUTION & STRICT INTEGRITY ASSERTIONS
// ============================================================================
function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });

  // 1. Parse 12 Lessons
  const lessons = parse12Lessons();
  if (lessons.length !== 12) {
    throw new Error(`Expected 12 lessons, parsed ${lessons.length}`);
  }
  const lessonsByNum = new Map(lessons.map((l) => [l.lessonNumber, l]));

  // 2. Parse 12 Final Revision Key Points blocks
  const revisionLessons = parseRevisionPoints(lessons);
  const totalRevisionPoints = revisionLessons.reduce((acc, l) => acc + l.points.length, 0);

  // 3. Parse 14 Lesson Bank Files (each 50 MCQ + 50 Essay = 1400 total)
  const allMcqs: ParsedMcq[] = [];
  const allEssays: ParsedEssay[] = [];

  for (let subNum = 1; subNum <= 14; subNum += 1) {
    const info = SUBLESSON_TO_MASTER[subNum];
    const { mcqs, essays } = parseNumberedQuestionBankFile(
      info.filename,
      `b${String(subNum).padStart(2, '0')}`,
      subNum,
      'بنك الدرس',
      null,
      lessonsByNum
    );
    if (mcqs.length !== 50 || essays.length !== 50) {
      throw new Error(
        `File ${info.filename} (sub ${subNum}) expected 50+50, got ${mcqs.length} MCQ + ${essays.length} Essay`
      );
    }
    allMcqs.push(...mcqs);
    allEssays.push(...essays);
  }

  // 4. Parse 60 Deductive Hard Questions (48 MCQ + 12 Essay)
  const ded = parse60DeductiveQuestions(lessonsByNum);
  if (ded.mcqs.length + ded.essays.length !== 60) {
    throw new Error(
      `Deductive file expected 60 total, got ${ded.mcqs.length} MCQ + ${ded.essays.length} Essay`
    );
  }
  allMcqs.push(...ded.mcqs);
  allEssays.push(...ded.essays);

  // 5. Parse File 15 Elite Toppers Questions (50 MCQ + 50 Essay)
  const elite = parseNumberedQuestionBankFile(
    '15___________________________2e33d048',
    'elite',
    null,
    'متفوقين ومستويات عليا',
    'متقدم',
    lessonsByNum
  );
  if (elite.mcqs.length !== 50 || elite.essays.length !== 50) {
    throw new Error(
      `File 15 expected 50+50, got ${elite.mcqs.length} MCQ + ${elite.essays.length} Essay`
    );
  }
  allMcqs.push(...elite.mcqs);
  allEssays.push(...elite.essays);

  // Write JSON files
  fs.writeFileSync(path.join(OUT_DIR, 'lessons.json'), JSON.stringify(lessons, null, 2), 'utf8');
  fs.writeFileSync(
    path.join(OUT_DIR, 'revisionPoints.json'),
    JSON.stringify(revisionLessons, null, 2),
    'utf8'
  );
  fs.writeFileSync(path.join(OUT_DIR, 'mcqBank.json'), JSON.stringify(allMcqs), 'utf8');
  fs.writeFileSync(path.join(OUT_DIR, 'essayBank.json'), JSON.stringify(allEssays), 'utf8');

  console.log('=== CURRICULUM DATA BUILD SUCCEEDED (100% ZERO-LOSS) ===');
  console.log(`Lessons: ${lessons.length} (sections total: ${lessons.reduce((a, l) => a + l.sections.length, 0)}, practice checks: ${lessons.reduce((a, l) => a + l.practiceChecks.length, 0)})`);
  console.log(`Final Revision Lessons: ${revisionLessons.length} (total numbered points: ${totalRevisionPoints})`);
  console.log(`MCQs Total: ${allMcqs.length} (Lesson Banks: 700, Deductive: ${ded.mcqs.length}, Elite: ${elite.mcqs.length})`);
  console.log(`Essays/Problems Total: ${allEssays.length} (Lesson Banks: 700, Deductive: ${ded.essays.length}, Elite: ${elite.essays.length})`);
  console.log(`Grand Total Questions: ${allMcqs.length + allEssays.length}`);
}

main();
