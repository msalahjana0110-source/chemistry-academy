import { useCallback, useEffect, useState } from 'react';
import { ACADEMY_DATA } from './data/academyData';
import { AmbientChemistryBackdrop } from './components/AmbientChemistryBackdrop';
import { CertificatesView } from './components/CertificatesView';
import { CommandModal, type CommandJumpTarget } from './components/CommandModal';
import { ConceptMasteryView } from './components/ConceptMasteryView';
import { Header } from './components/Header';
import { HomeView } from './components/HomeView';
import { LabView, type LabToolTab } from './components/LabView';
import {
  LessonsView,
  type HighlightedLessonSection,
} from './components/LessonsView';
import {
  MistakesView,
  type ExplanationJumpTarget,
} from './components/MistakesView';
import { MobileBottomNav } from './components/MobileBottomNav';
import { OpenBookView } from './components/OpenBookView';
import { QuizView } from './components/QuizView';
import { SplashGate } from './components/SplashGate';
import { StudioView } from './components/StudioView';
import { SyllabusAtlasView } from './components/SyllabusAtlasView';
import { ToastStack, type ToastMessage } from './components/ToastStack';
import type { SavedCertificate } from './utils/certificateEngine';
import {
  markMistakeResolved,
  removeMistakeRecord,
  upsertMistakeRecord,
  type MistakeInput,
  type MistakeRecord,
} from './utils/mistakesEngine';
import { SmartCurriculumAssistantPage } from './components/assistant/SmartCurriculumAssistantPage';
import {
  getInitialViewFromSearch,
  normalizePalette,
  normalizeQuizSubTab,
  normalizeView,
  shouldAutostart,
  type AcademyViewId,
  type PaletteId,
  type QuizSubTabId,
} from './utils/academyState';
import {
  DEFAULT_SITE_SETTINGS,
  getContainerMaxWidthCss,
  getRootFontSizePercent,
  loadSiteSettings,
  saveSiteSettings,
  type SiteSettings,
} from './utils/siteSettings';

function readStoredArray(key: string): string[] {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

export default function App() {
  const [splashVisible, setSplashVisible] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return !shouldAutostart(window.location.search);
  });
  const [splashExiting, setSplashExiting] = useState(false);
  const [activeView, setActiveView] = useState<AcademyViewId>(() => {
    if (typeof window === 'undefined') return 'home';
    return getInitialViewFromSearch(window.location.search);
  });
  const [activeQuizSub, setActiveQuizSub] = useState<QuizSubTabId>('bank');
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => loadSiteSettings());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [cmdModalOpen, setCmdModalOpen] = useState(false);

  // Interactive Academy Persistent State
  const [selectedLessonId, setSelectedLessonId] = useState(ACADEMY_DATA.lessons.items[0].id);
  const [completedLessons, setCompletedLessons] = useState<string[]>(() =>
    readStoredArray('chem_completed_lessons')
  );
  const [pinnedOpenBookIds, setPinnedOpenBookIds] = useState<string[]>(() =>
    readStoredArray('chem_pinned_openbook')
  );
  const [masteredCardIds, setMasteredCardIds] = useState<string[]>(() =>
    readStoredArray('chem_mastered_cards')
  );
  const [bestQuizScore, setBestQuizScore] = useState<number | null>(() => {
    try {
      const raw = window.localStorage.getItem('chem_best_quiz');
      const num = raw ? Number(raw) : NaN;
      return Number.isFinite(num) ? num : null;
    } catch {
      return null;
    }
  });
  const [savedCertificates, setSavedCertificates] = useState<SavedCertificate[]>(() => {
    try {
      const raw = window.localStorage.getItem('chem_saved_certificates');
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? (parsed as SavedCertificate[]) : [];
    } catch {
      return [];
    }
  });
  const [mistakes, setMistakes] = useState<MistakeRecord[]>(() => {
    try {
      const raw = window.localStorage.getItem('chem_mistake_records');
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? (parsed as MistakeRecord[]) : [];
    } catch {
      return [];
    }
  });
  const [highlightedLessonSection, setHighlightedLessonSection] =
    useState<HighlightedLessonSection | null>(null);

  // Lab, OpenBook, Studio & Quiz deep-link state
  const [labTool, setLabTool] = useState<LabToolTab>('experiments');
  const [selectedElementSymbol, setSelectedElementSymbol] = useState('Fe');
  const [openBookQuery, setOpenBookQuery] = useState('');
  const [quizLessonFilter, setQuizLessonFilter] = useState<string | null>(null);
  const [quizSubTopicFilter, setQuizSubTopicFilter] = useState<string | null>(null);
  const [studioLessonNum, setStudioLessonNum] = useState<number | null>(null);

  // Toast Notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const notify = useCallback((text: string, tone: ToastMessage['tone'] = 'success') => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setToasts((prev) => [...prev.slice(-2), { id, text, tone }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  }, []);

  // Sync unified SiteSettings to DOM attributes, CSS variables, and localStorage
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-palette', siteSettings.palette);
    root.classList.toggle('dark', siteSettings.isDark);
    root.style.fontSize = getRootFontSizePercent(siteSettings.fontScale);
    root.style.setProperty('--academy-max-w', getContainerMaxWidthCss(siteSettings.containerWidth));
    root.setAttribute('data-density', siteSettings.density);
    root.setAttribute('data-contrast', siteSettings.highContrast ? 'high' : 'normal');
    root.setAttribute('data-reduced-motion', siteSettings.reducedMotion ? 'true' : 'false');
    saveSiteSettings(siteSettings);
  }, [siteSettings]);

  useEffect(() => {
    try {
      window.localStorage.setItem('chem_completed_lessons', JSON.stringify(completedLessons));
    } catch {
      // ignore storage quota issues
    }
  }, [completedLessons]);

  useEffect(() => {
    try {
      window.localStorage.setItem('chem_pinned_openbook', JSON.stringify(pinnedOpenBookIds));
    } catch {
      // ignore
    }
  }, [pinnedOpenBookIds]);

  useEffect(() => {
    try {
      window.localStorage.setItem('chem_mastered_cards', JSON.stringify(masteredCardIds));
    } catch {
      // ignore
    }
  }, [masteredCardIds]);

  useEffect(() => {
    try {
      window.localStorage.setItem('chem_saved_certificates', JSON.stringify(savedCertificates));
    } catch {
      // ignore
    }
  }, [savedCertificates]);

  useEffect(() => {
    try {
      window.localStorage.setItem('chem_mistake_records', JSON.stringify(mistakes));
    } catch {
      // ignore
    }
  }, [mistakes]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCmdModalOpen((open) => !open);
      } else if (e.key === 'Escape' && cmdModalOpen) {
        setCmdModalOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [cmdModalOpen]);

  const handleEnterPlatform = () => {
    if (splashExiting) return;
    setSplashExiting(true);
    window.setTimeout(() => {
      setSplashVisible(false);
      setSplashExiting(false);
    }, 550);
  };

  const handleSwitchView = (view: AcademyViewId) => {
    setActiveView(normalizeView(view));
    setSettingsOpen(false);
    window.scrollTo({ top: 0, behavior: siteSettings.reducedMotion ? 'auto' : 'smooth' });
  };

  const handleUpdateSettings = (patch: Partial<SiteSettings>) => {
    setSiteSettings((prev) => ({ ...prev, ...patch }));
  };

  const handleSelectPalette = (nextPalette: PaletteId) => {
    const valid = normalizePalette(nextPalette);
    setSiteSettings((prev) => ({ ...prev, palette: valid }));
    notify(`تم تفعيل لوحة الألوان: ${valid}`, 'info');
  };

  const handleResetSettings = () => {
    setSiteSettings({ ...DEFAULT_SITE_SETTINGS });
    notify('تمت استعادة الإعدادات الافتراضية للتصميم والمؤثرات', 'info');
  };

  const handleToggleLessonComplete = (id: string) => {
    setCompletedLessons((prev) => {
      const exists = prev.includes(id);
      notify(exists ? 'تمت إزالة علامة الإتمام عن الدرس' : 'أحسنت! تم تسجيل إتمام الدرس بنجاح');
      return exists ? prev.filter((item) => item !== id) : [...prev, id];
    });
  };

  const handleTogglePinOpenBook = (id: string) => {
    setPinnedOpenBookIds((prev) => {
      const exists = prev.includes(id);
      notify(exists ? 'تمت إزالة القانون من المفضلة' : 'تم تثبيت القانون في ورقة المراجعة');
      return exists ? prev.filter((item) => item !== id) : [...prev, id];
    });
  };

  const handleToggleMasteredCard = (id: string) => {
    setMasteredCardIds((prev) => {
      const exists = prev.includes(id);
      notify(exists ? 'تمت إعادة البطاقة لقائمة المراجعة' : 'ممتاز! تم تسجيل إتقان البطاقة');
      return exists ? prev.filter((item) => item !== id) : [...prev, id];
    });
  };

  const handleFinishExamScore = (pct: number) => {
    setBestQuizScore((prev) => {
      const next = prev === null ? pct : Math.max(prev, pct);
      try {
        window.localStorage.setItem('chem_best_quiz', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const handleRecordMistake = useCallback(
    (input: MistakeInput) => {
      setMistakes((prev) => upsertMistakeRecord(prev, input));
      notify('تم حفظ السؤال في تبويب «أخطائي» للعودة إلى شرحه', 'info');
    },
    [notify]
  );

  const handleJumpToExplanation = (target: ExplanationJumpTarget) => {
    setSelectedLessonId(target.lessonId);
    setHighlightedLessonSection({ ...target });
    setActiveView('lessons');
    notify(`تم نقلك إلى شرح: ${target.sectionTitle}`);
  };

  const unresolvedMistakesCount = mistakes.filter((m) => !m.resolved).length;

  const handleCommandJump = (target: CommandJumpTarget) => {
    if (target.lessonId) {
      setSelectedLessonId(target.lessonId);
    }
    if (target.elementSymbol) {
      setSelectedElementSymbol(target.elementSymbol);
      setLabTool('periodic');
    }
    if (target.openBookQuery !== undefined) {
      setOpenBookQuery(target.openBookQuery);
    }
    if (target.studioLessonNum !== undefined) {
      setStudioLessonNum(target.studioLessonNum);
    }
    handleSwitchView(target.view);
  };

  if (activeView === 'assistant') {
    return (
      <>
        <SmartCurriculumAssistantPage
          isDark={siteSettings.isDark}
          onToggleTheme={() => handleUpdateSettings({ isDark: !siteSettings.isDark })}
          onExitToPlatform={() => handleSwitchView('home')}
          onNotify={notify}
        />
        <ToastStack toasts={toasts} />
      </>
    );
  }

  return (
    <>
      <AmbientChemistryBackdrop
        visualEffects={siteSettings.visualEffects}
        reducedMotion={siteSettings.reducedMotion}
        showScrollProgress={siteSettings.showScrollProgress}
      />

      <SplashGate
        brand={ACADEMY_DATA.brand}
        visible={splashVisible}
        exiting={splashExiting}
        onEnter={handleEnterPlatform}
      />

      <Header
        brand={ACADEMY_DATA.brand}
        activeView={activeView}
        settings={siteSettings}
        settingsOpen={settingsOpen}
        completedLessonsCount={completedLessons.length}
        totalLessonsCount={ACADEMY_DATA.lessons.items.length}
        unresolvedMistakesCount={unresolvedMistakesCount}
        savedCertificatesCount={savedCertificates.length}
        onSwitchView={handleSwitchView}
        onSelectPalette={handleSelectPalette}
        onToggleTheme={() => handleUpdateSettings({ isDark: !siteSettings.isDark })}
        onToggleSettings={() => setSettingsOpen((o) => !o)}
        onCloseSettings={() => setSettingsOpen(false)}
        onUpdateSettings={handleUpdateSettings}
        onResetSettings={handleResetSettings}
        onReopenSplash={() => {
          setSplashExiting(false);
          setSplashVisible(true);
        }}
        onOpenCommand={() => setCmdModalOpen(true)}
      />

      <main className="relative z-10 flex-1 pb-20 lg:pb-0">
        <HomeView
          active={activeView === 'home'}
          palette={siteSettings.palette}
          completedLessonsCount={completedLessons.length}
          masteredCardsCount={masteredCardIds.length}
          bestQuizScore={bestQuizScore}
          onSwitchView={handleSwitchView}
          onJumpToLesson={(lessonId) => {
            setSelectedLessonId(lessonId);
            setHighlightedLessonSection(null);
            handleSwitchView('lessons');
          }}
          onOpenLabTool={(tool, elementSymbol) => {
            setLabTool(tool);
            if (elementSymbol) {
              setSelectedElementSymbol(elementSymbol);
            }
            handleSwitchView('lab');
          }}
          onNotify={notify}
        />

        <LessonsView
          active={activeView === 'lessons'}
          selectedLessonId={selectedLessonId}
          completedLessons={completedLessons}
          highlightedSection={highlightedLessonSection}
          onSelectLesson={(id) => {
            setSelectedLessonId(id);
            if (highlightedLessonSection && highlightedLessonSection.lessonId !== id) {
              setHighlightedLessonSection(null);
            }
          }}
          onToggleComplete={handleToggleLessonComplete}
          onRecordMistake={handleRecordMistake}
          onJumpToExplanation={handleJumpToExplanation}
          onClearHighlightedSection={() => setHighlightedLessonSection(null)}
          onReturnToMistakes={() => handleSwitchView('mistakes')}
          onOpenLessonQuestions={(lessonId) => {
            setQuizSubTopicFilter(null);
            setQuizLessonFilter(lessonId);
            setActiveQuizSub('bank');
            handleSwitchView('quiz');
          }}
          onNotify={notify}
        />

        <SyllabusAtlasView
          active={activeView === 'syllabus'}
          onOpenDeepLesson={(lessonId) => {
            setSelectedLessonId(lessonId);
            setHighlightedLessonSection(null);
            handleSwitchView('lessons');
          }}
          onOpenSubTopicQuestions={(subTopicId, lessonId) => {
            setQuizLessonFilter(lessonId);
            setQuizSubTopicFilter(subTopicId);
            setActiveQuizSub('bank');
            handleSwitchView('quiz');
          }}
          onOpenLessonFlashcards={(lessonNum) => {
            setStudioLessonNum(lessonNum);
            handleSwitchView('studio');
          }}
          onOpenLab={() => handleSwitchView('lab')}
          onNotify={notify}
        />

        <LabView
          active={activeView === 'lab'}
          activeTool={labTool}
          selectedElementSymbol={selectedElementSymbol}
          onSelectTool={setLabTool}
          onSelectElementSymbol={setSelectedElementSymbol}
          onNotify={notify}
        />

        <OpenBookView
          active={activeView === 'openbook'}
          initialQuery={openBookQuery}
          pinnedIds={pinnedOpenBookIds}
          onTogglePin={handleTogglePinOpenBook}
          onNotify={notify}
        />

        <StudioView
          active={activeView === 'studio'}
          initialLessonNum={studioLessonNum}
          masteredIds={masteredCardIds}
          onToggleMastered={handleToggleMasteredCard}
          onNotify={notify}
        />

        <QuizView
          active={activeView === 'quiz'}
          activeSubTab={activeQuizSub}
          initialLessonId={quizLessonFilter}
          initialSubTopicId={quizSubTopicFilter}
          onSwitchSubTab={(sub) => setActiveQuizSub(normalizeQuizSubTab(sub))}
          onFinishExamScore={handleFinishExamScore}
          onRecordMistake={handleRecordMistake}
          onJumpToExplanation={handleJumpToExplanation}
          onOpenStudioLesson={(lessonNum) => {
            setStudioLessonNum(lessonNum);
            handleSwitchView('studio');
          }}
          onNotify={notify}
        />

        <CertificatesView
          active={activeView === 'certificates'}
          savedCertificates={savedCertificates}
          onSaveCertificate={(cert) => {
            setSavedCertificates((prev) =>
              prev.some((c) => c.serial === cert.serial) ? prev : [cert, ...prev]
            );
            notify('تم حفظ شهادة التقدير في سجل شهاداتك بنجاح');
          }}
          onDeleteCertificate={(id) => {
            setSavedCertificates((prev) => prev.filter((c) => c.id !== id));
            notify('تم حذف الشهادة من السجل', 'info');
          }}
          onRecordMistake={handleRecordMistake}
          onJumpToExplanation={handleJumpToExplanation}
          onNotify={notify}
        />

        <MistakesView
          active={activeView === 'mistakes'}
          mistakes={mistakes}
          onJumpToExplanation={handleJumpToExplanation}
          onToggleResolved={(questionId, resolved) => {
            setMistakes((prev) => markMistakeResolved(prev, questionId, resolved));
          }}
          onDeleteMistake={(questionId) => {
            setMistakes((prev) => removeMistakeRecord(prev, questionId));
            notify('تمت إزالة السؤال من سجل أخطائي', 'info');
          }}
          onClearAllMistakes={() => {
            setMistakes([]);
            notify('تم مسح سجل الأخطاء بالكامل', 'info');
          }}
          onNavigate={handleSwitchView}
          onNotify={notify}
        />

        <ConceptMasteryView
          active={activeView === 'mastery'}
          completedLessons={completedLessons}
          mistakes={mistakes}
          onJumpToLesson={(lessonId) => {
            setSelectedLessonId(lessonId);
            setHighlightedLessonSection(null);
            handleSwitchView('lessons');
          }}
          onJumpToExplanation={handleJumpToExplanation}
          onOpenLessonQuestions={(lessonId) => {
            setQuizLessonFilter(lessonId);
            setActiveQuizSub('bank');
            handleSwitchView('quiz');
          }}
          onOpenMistakes={() => handleSwitchView('mistakes')}
          onNotify={notify}
        />
      </main>

      {/* Animated Kinetic Prestige Marquee Ribbon (Bottom of Platform) */}
      <div
        id="platformBottomMarquee"
        aria-label="الشريط الإخباري للمنصة"
        className="relative z-10 no-print border-t border-slate-200 dark:border-white/10 bg-slate-100/85 dark:bg-white/[0.03] glass-panel py-3 overflow-hidden"
      >
        <div className="ticker-track gap-8 text-sm font-bold text-slate-700 dark:text-slate-300">
          {ACADEMY_DATA.home.marqueeItems.map((item, idx) => (
            <span key={`m1-${idx}`} className="whitespace-nowrap">
              {item}
            </span>
          ))}
          {ACADEMY_DATA.home.marqueeItems.map((item, idx) => (
            <span key={`m2-${idx}`} aria-hidden="true" className="whitespace-nowrap">
              {item}
            </span>
          ))}
        </div>
      </div>

      <footer className="relative z-10 border-t border-slate-200 dark:border-white/10 py-6 pb-24 lg:pb-6 text-center text-xs text-slate-600 dark:text-slate-400">
        {ACADEMY_DATA.brand.footerText}
      </footer>

      <MobileBottomNav
        activeView={activeView}
        unresolvedMistakesCount={unresolvedMistakesCount}
        onSwitchView={handleSwitchView}
      />

      <CommandModal
        open={cmdModalOpen}
        onClose={() => setCmdModalOpen(false)}
        onJump={handleCommandJump}
      />

      <ToastStack toasts={toasts} />
    </>
  );
}
