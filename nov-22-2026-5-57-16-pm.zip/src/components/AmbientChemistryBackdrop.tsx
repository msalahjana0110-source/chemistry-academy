import { useEffect, useState, type CSSProperties } from 'react';
import { ArrowUp } from 'lucide-react';
import { motion } from 'motion/react';

interface AmbientChemistryBackdropProps {
  visualEffects: boolean;
  reducedMotion: boolean;
  showScrollProgress: boolean;
}

interface ChemicalRainParticle {
  id: string;
  kind: 'formula' | 'molecule' | 'hex';
  label?: string;
  leftPct: number;
  durationSec: number;
  delaySec: number;
  swayPx: number;
  rotStart: number;
  rotEnd: number;
  opacity: number;
  size: 'sm' | 'md' | 'lg';
  useSecondary?: boolean;
  desktopOnly?: boolean;
}

const CHEMICAL_RAIN_DROPS: readonly ChemicalRainParticle[] = [
  { id: 'r01', kind: 'formula', label: 'H₂O', leftPct: 4, durationSec: 17, delaySec: -2.4, swayPx: 14, rotStart: -6, rotEnd: 5, opacity: 0.34, size: 'md' },
  { id: 'r02', kind: 'molecule', leftPct: 9, durationSec: 21, delaySec: -11.2, swayPx: -12, rotStart: -12, rotEnd: 14, opacity: 0.3, size: 'sm', useSecondary: true, desktopOnly: true },
  { id: 'r03', kind: 'formula', label: 'CO₂', leftPct: 14, durationSec: 19, delaySec: -7.5, swayPx: 16, rotStart: 5, rotEnd: -6, opacity: 0.3, size: 'sm', useSecondary: true },
  { id: 'r04', kind: 'hex', leftPct: 19, durationSec: 24, delaySec: -16.0, swayPx: -15, rotStart: -18, rotEnd: 18, opacity: 0.26, size: 'md', desktopOnly: true },
  { id: 'r05', kind: 'formula', label: 'NaCl', leftPct: 24, durationSec: 16, delaySec: -4.1, swayPx: 12, rotStart: -5, rotEnd: 6, opacity: 0.32, size: 'sm' },
  { id: 'r06', kind: 'formula', label: 'NH₃', leftPct: 29, durationSec: 22, delaySec: -13.5, swayPx: -18, rotStart: 4, rotEnd: -7, opacity: 0.28, size: 'md', useSecondary: true, desktopOnly: true },
  { id: 'r07', kind: 'molecule', leftPct: 34, durationSec: 18, delaySec: -9.0, swayPx: 14, rotStart: -15, rotEnd: 12, opacity: 0.3, size: 'md' },
  { id: 'r08', kind: 'formula', label: 'O₂', leftPct: 39, durationSec: 15, delaySec: -1.8, swayPx: -10, rotStart: -4, rotEnd: 5, opacity: 0.35, size: 'lg', useSecondary: true },
  { id: 'r09', kind: 'formula', label: 'Al₂O₃', leftPct: 44, durationSec: 23, delaySec: -15.2, swayPx: 16, rotStart: 6, rotEnd: -5, opacity: 0.26, size: 'sm', desktopOnly: true },
  { id: 'r10', kind: 'hex', leftPct: 49, durationSec: 20, delaySec: -6.3, swayPx: -14, rotStart: -20, rotEnd: 20, opacity: 0.28, size: 'sm', useSecondary: true },
  { id: 'r11', kind: 'formula', label: 'HCl', leftPct: 54, durationSec: 17.5, delaySec: -10.8, swayPx: 15, rotStart: -5, rotEnd: 6, opacity: 0.32, size: 'md', desktopOnly: true },
  { id: 'r12', kind: 'formula', label: 'mol', leftPct: 59, durationSec: 21.5, delaySec: -3.6, swayPx: -13, rotStart: 5, rotEnd: -5, opacity: 0.29, size: 'sm' },
  { id: 'r13', kind: 'molecule', leftPct: 64, durationSec: 19, delaySec: -14.1, swayPx: 18, rotStart: -14, rotEnd: 16, opacity: 0.3, size: 'md', useSecondary: true, desktopOnly: true },
  { id: 'r14', kind: 'formula', label: 'Cr', leftPct: 69, durationSec: 16.5, delaySec: -8.2, swayPx: -12, rotStart: -6, rotEnd: 4, opacity: 0.34, size: 'md' },
  { id: 'r15', kind: 'formula', label: 'Cu', leftPct: 74, durationSec: 22.5, delaySec: -17.4, swayPx: 14, rotStart: 4, rotEnd: -6, opacity: 0.28, size: 'sm', useSecondary: true, desktopOnly: true },
  { id: 'r16', kind: 'formula', label: 'e⁻', leftPct: 79, durationSec: 14.5, delaySec: -5.0, swayPx: -11, rotStart: -8, rotEnd: 8, opacity: 0.36, size: 'lg' },
  { id: 'r17', kind: 'hex', leftPct: 84, durationSec: 23.5, delaySec: -12.3, swayPx: 15, rotStart: -16, rotEnd: 16, opacity: 0.26, size: 'md', desktopOnly: true },
  { id: 'r18', kind: 'formula', label: 'NaOH', leftPct: 89, durationSec: 18.5, delaySec: -3.1, swayPx: -15, rotStart: 5, rotEnd: -5, opacity: 0.3, size: 'sm', useSecondary: true },
  { id: 'r19', kind: 'formula', label: 'Nₐ', leftPct: 94, durationSec: 16, delaySec: -9.8, swayPx: 11, rotStart: -4, rotEnd: 5, opacity: 0.33, size: 'md' },
  { id: 'r20', kind: 'formula', label: 'Fe', leftPct: 47, durationSec: 25, delaySec: -19.0, swayPx: 12, rotStart: -5, rotEnd: 6, opacity: 0.25, size: 'sm', desktopOnly: true },
  { id: 'r21', kind: 'molecule', leftPct: 17, durationSec: 20.5, delaySec: -1.2, swayPx: -14, rotStart: -12, rotEnd: 14, opacity: 0.28, size: 'sm', desktopOnly: true },
  { id: 'r22', kind: 'formula', label: 'H₂', leftPct: 76, durationSec: 17, delaySec: -13.0, swayPx: 13, rotStart: 4, rotEnd: -5, opacity: 0.31, size: 'sm', useSecondary: true, desktopOnly: true },
];

export function AmbientChemistryBackdrop({
  visualEffects,
  reducedMotion,
  showScrollProgress,
}: AmbientChemistryBackdropProps) {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    let rafId = 0;
    const updateScroll = () => {
      rafId = 0;
      const doc = document.documentElement;
      const scrollTop = window.scrollY || doc.scrollTop || 0;
      const scrollable = Math.max(1, doc.scrollHeight - window.innerHeight);
      const pct = Math.min(1, Math.max(0, scrollTop / scrollable));
      setScrollProgress(pct);
      setShowBackToTop(scrollTop > 420);
    };

    const onScroll = () => {
      if (!rafId) {
        rafId = window.requestAnimationFrame(updateScroll);
      }
    };

    updateScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (rafId) window.cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <>
      {/* Top GPU-accelerated reading progress bar */}
      {showScrollProgress && (
        <div
          aria-hidden="true"
          className="fixed top-0 left-0 right-0 h-[3px] z-50 pointer-events-none no-print bg-transparent"
        >
          <div
            className="h-full w-full origin-right theme-grad-btn transition-transform duration-150 ease-out"
            style={{ transform: `scaleX(${scrollProgress})` }}
          />
        </div>
      )}

      {/* Subtle Ambient Chemistry Atmospheric Layer + Gentle Falling Chemical Rain */}
      {visualEffects && (
        <div
          aria-hidden="true"
          data-ambient-rain="active"
          className="fixed inset-0 z-0 pointer-events-none overflow-hidden no-print"
        >
          {/* Delicate Hexagonal Chemistry Lattice */}
          <div className="ambient-chem-grid absolute inset-0 opacity-[0.045] dark:opacity-[0.065]" />

          {/* Dual Soft Atmospheric Glow Orbs */}
          <div
            className={`ambient-orb-primary absolute -top-28 -right-24 w-[420px] h-[420px] sm:w-[560px] sm:h-[560px] rounded-full blur-3xl opacity-20 dark:opacity-25 ${
              reducedMotion ? '' : 'ambient-drift-slow'
            }`}
          />
          <div
            className={`ambient-orb-secondary absolute bottom-0 -left-24 w-[380px] h-[380px] sm:w-[520px] sm:h-[520px] rounded-full blur-3xl opacity-15 dark:opacity-20 ${
              reducedMotion ? '' : 'ambient-drift-reverse'
            }`}
          />

          {/* Subtle Scientific Orbital Arc (Desktop) */}
          <svg
            viewBox="0 0 600 600"
            className={`hidden lg:block absolute top-24 left-8 w-[420px] h-[420px] opacity-[0.07] dark:opacity-[0.11] ${
              reducedMotion ? '' : 'orbit-spin-slow'
            }`}
            fill="none"
          >
            <circle cx="300" cy="300" r="240" stroke="var(--p-primary)" strokeWidth="1" strokeDasharray="6 10" />
            <ellipse
              cx="300"
              cy="300"
              rx="240"
              ry="104"
              stroke="var(--p-secondary)"
              strokeWidth="1"
              transform="rotate(-24 300 300)"
            />
            <circle cx="540" cy="300" r="5" fill="var(--p-primary)" />
            <circle cx="110" cy="214" r="4" fill="var(--p-secondary)" />
          </svg>

          {/* Gentle Falling Chemical Rain (Framer Motion entrance + GPU CSS fall) */}
          <motion.div
            initial={reducedMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.9, ease: 'easeOut' }}
            className="absolute inset-0 overflow-hidden"
          >
            {CHEMICAL_RAIN_DROPS.map((drop, idx) => {
              const toneColor = drop.useSecondary ? 'var(--p-secondary)' : 'var(--p-primary)';
              const sizeText =
                drop.size === 'lg'
                  ? 'text-[13px] sm:text-sm'
                  : drop.size === 'md'
                    ? 'text-[11px] sm:text-xs'
                    : 'text-[10px] sm:text-[11px]';

              const staticTopPct = ((idx * 17 + 9) % 82) + 8;

              const rainStyle = {
                left: `${drop.leftPct}%`,
                top: reducedMotion ? `${staticTopPct}%` : '0%',
                color: toneColor,
                opacity: reducedMotion ? drop.opacity * 0.65 : undefined,
                animationDuration: reducedMotion ? undefined : `${drop.durationSec}s`,
                animationDelay: reducedMotion ? undefined : `${drop.delaySec}s`,
                '--rain-sway': `${drop.swayPx}px`,
                '--rain-rot-start': `${drop.rotStart}deg`,
                '--rain-rot-end': `${drop.rotEnd}deg`,
                '--rain-opacity': String(drop.opacity),
              } as CSSProperties;

              return (
                <div
                  key={drop.id}
                  style={rainStyle}
                  className={`${
                    drop.desktopOnly ? 'hidden sm:flex' : 'flex'
                  } ${
                    reducedMotion ? '' : 'chem-rain-drop'
                  } absolute flex-col items-center select-none`}
                >
                  {/* Delicate Rain Droplet Trail */}
                  <span
                    className={`w-[1.5px] ${
                      drop.size === 'lg' ? 'h-9' : drop.size === 'md' ? 'h-7' : 'h-5'
                    } rounded-full mb-1 ${
                      drop.useSecondary ? 'chem-rain-trail-alt' : 'chem-rain-trail'
                    }`}
                  />

                  {/* Falling Molecule / Formula / Hex Ring */}
                  {drop.kind === 'formula' && (
                    <span
                      className={`formula-ltr font-extrabold tracking-tight leading-none ${sizeText} drop-shadow-[0_0_8px_var(--p-glow)]`}
                    >
                      {drop.label}
                    </span>
                  )}

                  {drop.kind === 'molecule' && (
                    <svg
                      viewBox="0 0 28 24"
                      className={drop.size === 'md' ? 'w-5 h-5' : 'w-4 h-4'}
                      fill="none"
                    >
                      <line x1="14" y1="6" x2="6" y2="17" stroke="currentColor" strokeWidth="1.5" strokeOpacity="0.85" />
                      <line x1="14" y1="6" x2="22" y2="17" stroke="currentColor" strokeWidth="1.5" strokeOpacity="0.85" />
                      <circle cx="14" cy="6" r="3.4" fill="currentColor" />
                      <circle cx="6" cy="17" r="2.4" fill="currentColor" fillOpacity="0.85" />
                      <circle cx="22" cy="17" r="2.4" fill="currentColor" fillOpacity="0.85" />
                    </svg>
                  )}

                  {drop.kind === 'hex' && (
                    <svg
                      viewBox="0 0 28 28"
                      className={drop.size === 'md' ? 'w-5 h-5' : 'w-4 h-4'}
                      fill="none"
                    >
                      <polygon
                        points="14,2 24,8 24,20 14,26 4,20 4,8"
                        stroke="currentColor"
                        strokeWidth="1.5"
                      />
                      <circle cx="14" cy="14" r="4.5" stroke="currentColor" strokeWidth="1.1" strokeOpacity="0.7" />
                    </svg>
                  )}
                </div>
              );
            })}
          </motion.div>
        </div>
      )}

      {/* Scroll-to-Top Floating Button (clears mobile bottom nav cleanly) */}
      <button
        type="button"
        onClick={() => window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' })}
        aria-label="العودة إلى أعلى الصفحة"
        title="العودة لأعلى"
        className={`no-print fixed left-4 bottom-20 lg:bottom-6 z-30 min-h-[44px] min-w-[44px] rounded-2xl border border-slate-200 dark:border-white/15 bg-white/90 dark:bg-slate-900/90 glass-panel text-slate-700 dark:text-slate-100 shadow-lg flex items-center justify-center transition-all duration-200 hover:scale-105 theme-border cursor-pointer ${
          showBackToTop
            ? 'opacity-100 translate-y-0 pointer-events-auto'
            : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
      >
        <ArrowUp className="w-4 h-4 theme-text" />
      </button>
    </>
  );
}
