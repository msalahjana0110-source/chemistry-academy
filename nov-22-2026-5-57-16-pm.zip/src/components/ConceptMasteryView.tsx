import { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  Atom,
  BookOpen,
  BrainCircuit,
  Calculator,
  CheckCircle2,
  Compass,
  Droplets,
  GitBranch,
  Layers,
  Scale,
  Sparkles,
  Target,
} from 'lucide-react';
import { ACADEMY_DATA, CURRICULUM_UNIT_META, type UnitId } from '../data/academyData';
import type { MistakeRecord } from '../utils/mistakesEngine';
import type { ExplanationJumpTarget } from './MistakesView';
import { WrongAnswerExplainButton } from './WrongAnswerExplainButton';
import {
  CONCEPT_COMPARISON_DECKS,
  FEATURED_QUANTUM_ELEMENTS,
  OXIDATION_WORKED_CASES,
  analyzeElementQuantum,
  computeReadinessDiagnostic,
  solveDilutionProblem,
  solveMoleProblem,
} from '../utils/conceptTutorEngine';

interface ConceptMasteryViewProps {
  active: boolean;
  completedLessons: string[];
  mistakes: MistakeRecord[];
  onJumpToLesson: (lessonId: string) => void;
  onJumpToExplanation: (target: ExplanationJumpTarget) => void;
  onOpenLessonQuestions: (lessonId: string) => void;
  onOpenMistakes: () => void;
  onNotify: (msg: string, tone?: 'success' | 'info') => void;
}

type MasterySubTab = 'map' | 'solver' | 'compare' | 'roadmap';
type SolverTool = 'mole' | 'dilution' | 'quantum' | 'oxidation';

export function ConceptMasteryView({
  active,
  completedLessons,
  mistakes,
  onJumpToLesson,
  onJumpToExplanation,
  onOpenLessonQuestions,
  onOpenMistakes,
  onNotify,
}: ConceptMasteryViewProps) {
  const lessons = ACADEMY_DATA.lessons.items;

  const [subTab, setSubTab] = useState<MasterySubTab>('map');
  const [selectedMapLessonId, setSelectedMapLessonId] = useState<string>(lessons[0].id);

  // Step-by-Step Solver State
  const [solverTool, setSolverTool] = useState<SolverTool>('quantum');
  const [massInput, setMassInput] = useState('44');
  const [molarMassInput, setMolarMassInput] = useState('44');
  const [m1Input, setM1Input] = useState('2');
  const [v1Input, setV1Input] = useState('100');
  const [m2Input, setM2Input] = useState('0.5');
  const [atomicZ, setAtomicZ] = useState(24);
  const [selectedOxId, setSelectedOxId] = useState<string>(OXIDATION_WORKED_CASES[0].id);

  // Concept Clarifier Quick-Check Answers
  const [compareAnswers, setCompareAnswers] = useState<Record<string, number>>({});

  const diagnostic = useMemo(
    () => computeReadinessDiagnostic(lessons, completedLessons, mistakes),
    [lessons, completedLessons, mistakes]
  );

  const selectedLesson =
    lessons.find((l) => l.id === selectedMapLessonId) ?? lessons[0];
  const selectedNode =
    diagnostic.nodes.find((n) => n.lessonId === selectedLesson.id) ?? diagnostic.nodes[0];

  const moleResult = useMemo(
    () => solveMoleProblem(Number(massInput), Number(molarMassInput)),
    [massInput, molarMassInput]
  );
  const dilutionResult = useMemo(
    () => solveDilutionProblem(Number(m1Input), Number(v1Input), Number(m2Input)),
    [m1Input, v1Input, m2Input]
  );
  const quantumResult = useMemo(() => analyzeElementQuantum(atomicZ), [atomicZ]);
  const activeOxCase =
    OXIDATION_WORKED_CASES.find((c) => c.id === selectedOxId) ?? OXIDATION_WORKED_CASES[0];

  const unitColors: Record<UnitId, string> = {
    unit1: 'from-emerald-500/15 to-cyan-500/10 border-emerald-500/30',
    unit2: 'from-sky-500/15 to-indigo-500/10 border-sky-500/30',
    unit3: 'from-amber-500/15 to-rose-500/10 border-amber-500/30',
  };

  return (
    <section
      id="view-mastery"
      className={`app-view ${
        active ? 'view-reveal' : 'hidden'
      } academy-container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-6`}
    >
      {/* Header Banner */}
      <div className="space-y-4">
        <div className="space-y-1.5">
          <p className="text-xs font-extrabold theme-text">
            مُعلّم الفهم التفاعلي · خريطة المنهج · مُحلّل المسائل بالخطوات
          </p>
          <h2 className="text-2xl sm:text-3xl font-black aurora-text">
            مُعلّم الفهم وإتقان منهج الكيمياء
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 max-w-3xl">
            أداة مبتكرة لفهم ترابط الدروس الـ 12 بصرياً، وحل مسائل المول والغازات والتخفيف وأعداد الكم والتأكسد خطوة بخطوة، وفك اشتباك أصعب مقارنات الامتحان.
          </p>
        </div>

        {/* Sub-Navigation Segmented Control */}
        <div
          role="tablist"
          aria-label="أدوات مُعلّم الفهم"
          className="grid grid-cols-2 md:inline-flex md:flex-nowrap gap-1.5 p-1.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04]"
        >
          {[
            { id: 'map' as const, label: 'خريطة المنهج (12)', icon: GitBranch },
            { id: 'solver' as const, label: 'مُحلّل المسائل بالخطوات', icon: Calculator },
            { id: 'compare' as const, label: 'فك الاشتباك والمقارنات', icon: Scale },
            { id: 'roadmap' as const, label: 'تشخيص الجاهزية', icon: Target },
          ].map((tab) => {
            const Icon = tab.icon;
            const isCurrent = subTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={isCurrent}
                onClick={() => setSubTab(tab.id)}
                className={`min-h-[44px] md:min-h-0 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold inline-flex items-center justify-center gap-1.5 transition cursor-pointer whitespace-nowrap ${
                  isCurrent
                    ? 'theme-grad-btn text-white'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: Interactive 12-Lesson Concept Map */}
      {subTab === 'map' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Interactive Visual Concept Graph */}
          <div className="lg:col-span-8 space-y-4">
            {CURRICULUM_UNIT_META.map((unit) => {
              const unitNodes = diagnostic.nodes.filter((n) => n.unitId === unit.id);
              return (
                <div
                  key={unit.id}
                  className={`p-4 sm:p-5 rounded-2xl border bg-gradient-to-br ${unitColors[unit.id]} dark:bg-white/[0.03] space-y-3.5`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-extrabold theme-text">{unit.kicker}</div>
                      <h3 className="font-black text-base sm:text-lg text-slate-900 dark:text-slate-100">
                        {unit.title}
                      </h3>
                    </div>
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400 tabular-nums">
                      مُتقن: {unitNodes.filter((n) => n.status === 'mastered').length} / {unitNodes.length}
                    </span>
                  </div>

                  {/* Connected Step Nodes */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {unitNodes.map((node) => {
                      const isSelected = node.lessonId === selectedLesson.id;
                      const statusLabel =
                        node.status === 'mastered'
                          ? 'مُتقن'
                          : node.status === 'needs-review'
                            ? `يحتاج مراجعة (${node.unresolvedMistakes})`
                            : 'قيد الدراسة';

                      return (
                        <button
                          key={node.lessonId}
                          type="button"
                          onClick={() => setSelectedMapLessonId(node.lessonId)}
                          aria-pressed={isSelected}
                          className={`w-full p-3.5 rounded-2xl border text-right transition-all duration-200 cursor-pointer flex items-start justify-between gap-3 ${
                            isSelected
                              ? 'theme-border bg-white dark:bg-slate-900 shadow-lg ring-2 ring-cyan-400/35'
                              : 'border-slate-200/90 dark:border-white/10 bg-white/85 dark:bg-slate-950/60 hover:border-slate-300 dark:hover:border-white/25'
                          }`}
                        >
                          <div className="space-y-1 min-w-0">
                            <div className="flex items-center gap-2 text-[11px] font-extrabold text-slate-500 dark:text-slate-400">
                              <span className="formula-ltr theme-text">
                                {String(node.lessonNumber).padStart(2, '0')}
                              </span>
                              <span>·</span>
                              <span
                                className={
                                  node.status === 'mastered'
                                    ? 'text-emerald-600 dark:text-emerald-400'
                                    : node.status === 'needs-review'
                                      ? 'text-rose-600 dark:text-rose-400'
                                      : 'text-slate-500 dark:text-slate-400'
                                }
                              >
                                {statusLabel}
                              </span>
                            </div>
                            <div className="font-extrabold text-sm text-slate-900 dark:text-slate-100 leading-snug">
                              {node.title}
                            </div>
                            {node.prerequisiteIds.length > 0 && (
                              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                                يعتمد على:{' '}
                                {node.prerequisiteIds
                                  .map((pid) => `الدرس ${pid.replace('lesson-', '').padStart(2, '0')}`)
                                  .join(' + ')}
                              </div>
                            )}
                          </div>
                          <span className="shrink-0 mt-0.5">
                            {node.status === 'mastered' ? (
                              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                            ) : node.status === 'needs-review' ? (
                              <AlertCircle className="w-5 h-5 text-rose-500" />
                            ) : (
                              <Compass className="w-5 h-5 text-slate-400" />
                            )}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Inspector Deck for Selected Lesson Node */}
          <aside className="lg:col-span-4 lg:sticky lg:top-20 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            <div className="space-y-1.5">
              <div className="text-xs font-extrabold theme-text">
                {selectedLesson.unitName} · {selectedLesson.numberLabel}
              </div>
              <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-slate-100">
                {selectedLesson.title}
              </h3>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/80 dark:border-white/10 space-y-1.5">
              <div className="text-xs font-extrabold theme-text">الفكرة الجوهرية للدرس</div>
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {selectedLesson.coreIdea}
              </p>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                المتطلبات السابقة لفهم هذا الدرس
              </div>
              {selectedNode.prerequisiteIds.length === 0 ? (
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  درس تأسيسي لبداية الباب — لا يتطلب دروساً سابقة ويمكنك البدء به مباشرة.
                </p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {selectedNode.prerequisiteIds.map((pid) => {
                    const pre = lessons.find((l) => l.id === pid);
                    if (!pre) return null;
                    return (
                      <button
                        key={pid}
                        type="button"
                        onClick={() => setSelectedMapLessonId(pid)}
                        className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:border-cyan-400 text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
                      >
                        {pre.numberLabel}: {pre.title}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {selectedLesson.examTraps[0] && (
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 space-y-1">
                <div className="text-xs font-extrabold text-amber-700 dark:text-amber-300">
                  أهم فخ امتحاني يجب تجنّبه
                </div>
                <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                  {selectedLesson.examTraps[0]}
                </p>
              </div>
            )}

            <div className="grid grid-cols-1 gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => onJumpToLesson(selectedLesson.id)}
                className="theme-grad-btn w-full py-3 px-4 rounded-xl text-white text-sm font-extrabold inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <BookOpen className="w-4 h-4" />
                <span>افتح شرح هذا الدرس بالكامل</span>
              </button>
              <button
                type="button"
                onClick={() => onOpenLessonQuestions(selectedLesson.id)}
                className="w-full py-2.5 px-4 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100 inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <Layers className="w-4 h-4 theme-text" />
                <span>تدرّب على بنك أسئلة هذا الدرس</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* TAB 2: Interactive Step-by-Step Chemistry Problem Tutor */}
      {subTab === 'solver' && (
        <div className="space-y-5">
          {/* Solver Tool Selector */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
            {[
              { id: 'quantum' as const, label: 'أعداد الكم والتوزيع (Z=1..36)', icon: Atom },
              { id: 'mole' as const, label: 'مسائل المول و STP / rtp', icon: Calculator },
              { id: 'dilution' as const, label: 'المولارية والتخفيف (M₁V₁)', icon: Droplets },
              { id: 'oxidation' as const, label: 'أعداد التأكسد والمركبات الشاذة', icon: Sparkles },
            ].map((tool) => {
              const Icon = tool.icon;
              const activeTool = solverTool === tool.id;
              return (
                <button
                  key={tool.id}
                  type="button"
                  onClick={() => setSolverTool(tool.id)}
                  aria-pressed={activeTool}
                  className={`p-3.5 rounded-2xl border text-right flex items-center gap-2.5 transition cursor-pointer ${
                    activeTool
                      ? 'theme-border theme-bg-soft theme-text shadow-sm'
                      : 'border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] text-slate-700 dark:text-slate-200 hover:border-slate-300 dark:hover:border-white/25'
                  }`}
                >
                  <Icon className="w-5 h-5 shrink-0" />
                  <span className="text-xs sm:text-sm font-extrabold leading-snug">{tool.label}</span>
                </button>
              );
            })}
          </div>

          {/* SOLVER A: Quantum Numbers & Orbital Boxes Simulator */}
          {solverTool === 'quantum' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-5 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
                <div>
                  <h3 className="font-black text-lg text-slate-900 dark:text-slate-100">
                    مُفسّر التوزيع الإلكتروني وأعداد الكم الأربعة
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    اختر العدد الذري (1 إلى 36) لمشاهدة التوزيع طبقاً لأوفباو وقاعدة هوند وأعداد الكم للإلكترون الأخير.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold">
                    <label htmlFor="quantumZRange">العدد الذري (Z)</label>
                    <span className="formula-ltr text-base font-black theme-text tabular-nums">
                      Z = {quantumResult.atomicNumber} ({quantumResult.symbol} · {quantumResult.nameAr})
                    </span>
                  </div>
                  <input
                    id="quantumZRange"
                    type="range"
                    min={1}
                    max={36}
                    value={atomicZ}
                    onChange={(e) => setAtomicZ(Number(e.target.value))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <div className="text-xs font-bold text-slate-600 dark:text-slate-400">
                    عناصر منهجية هامة (اضغط للمقارنة الفورية):
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {FEATURED_QUANTUM_ELEMENTS.map((item) => (
                      <button
                        key={item.z}
                        type="button"
                        onClick={() => setAtomicZ(item.z)}
                        className={`px-2.5 py-1.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                          atomicZ === item.z
                            ? 'theme-border theme-bg-soft theme-text'
                            : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>

                {quantumResult.isAnomaly && quantumResult.anomalyNote && (
                  <div className="p-3.5 rounded-xl bg-amber-500/12 border border-amber-500/35 text-xs text-amber-800 dark:text-amber-200 leading-relaxed font-semibold">
                    {quantumResult.anomalyNote}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2.5 text-center">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/80 dark:border-white/10">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">الدورة والفئة</div>
                    <div className="font-black text-sm theme-text mt-0.5 tabular-nums">
                      الدورة {quantumResult.period} · الفئة {quantumResult.block}
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/80 dark:border-white/10">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">الإلكترونات المفردة</div>
                    <div className="font-black text-sm theme-text mt-0.5 tabular-nums">
                      {quantumResult.unpairedElectrons} إلكترون مفرد
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-white/10">
                  <div>
                    <div className="text-xs font-bold text-slate-500 dark:text-slate-400">
                      التوزيع لأقرب غاز خامل · {quantumResult.groupLabel}
                    </div>
                    <div className="formula-ltr text-lg sm:text-xl font-black theme-text mt-1">
                      {quantumResult.nobleGasConfig}
                    </div>
                  </div>
                  <code className="formula-ltr text-xs px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300">
                    {quantumResult.fullConfig}
                  </code>
                </div>

                {/* Hund's Rule Orbital Box Diagram for Last Subshells */}
                <div className="space-y-3">
                  <div className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
                    تمثيل أوربيتالات التكافؤ طبقاً لقاعدة هوند (فرادى أولاً ثم ازدواج):
                  </div>
                  <div className="flex flex-wrap gap-4">
                    {quantumResult.subshells.slice(-3).map((sub) => (
                      <div key={sub.label} className="space-y-1.5">
                        <div className="formula-ltr text-xs font-extrabold theme-text">
                          {sub.label} ({sub.count}/{sub.capacity})
                        </div>
                        <div className="flex items-center gap-1.5" dir="ltr">
                          {sub.boxes.map((box) => (
                            <div key={`${sub.label}-${box.ml}`} className="flex flex-col items-center gap-1">
                              <div className="w-10 h-10 rounded-lg border-2 border-slate-300 dark:border-white/20 bg-slate-50 dark:bg-slate-900/90 flex items-center justify-center gap-0.5 font-mono text-base font-black">
                                {box.electrons.map((spin, i) => (
                                  <span
                                    key={i}
                                    className={spin === 'up' ? 'text-emerald-500' : 'text-cyan-400'}
                                  >
                                    {spin === 'up' ? '↑' : '↓'}
                                  </span>
                                ))}
                              </div>
                              <span className="formula-ltr text-[10px] text-slate-500 dark:text-slate-400 tabular-nums">
                                {box.ml > 0 ? `+${box.ml}` : box.ml}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Four Quantum Numbers of Last Electron */}
                <div className="space-y-2.5 pt-2 border-t border-slate-200 dark:border-white/10">
                  <div className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                    أعداد الكم الأربعة للإلكترون الأخير (المستوى الفرعي {quantumResult.lastSubshell.label}):
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {[
                      {
                        sym: 'n',
                        title: 'الرئيسي',
                        val: String(quantumResult.lastElectronQuantum.n),
                      },
                      {
                        sym: 'l',
                        title: `الثانوي (${quantumResult.lastElectronQuantum.subshellLetter})`,
                        val: String(quantumResult.lastElectronQuantum.l),
                      },
                      {
                        sym: 'mₗ',
                        title: 'المغناطيسي',
                        val:
                          quantumResult.lastElectronQuantum.ml > 0
                            ? `+${quantumResult.lastElectronQuantum.ml}`
                            : String(quantumResult.lastElectronQuantum.ml),
                      },
                      {
                        sym: 'mₛ',
                        title: 'المغزلي',
                        val: quantumResult.lastElectronQuantum.ms,
                      },
                    ].map((q) => (
                      <div
                        key={q.sym}
                        className="p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-900/60 text-center"
                      >
                        <div className="formula-ltr text-xs font-bold text-slate-500 dark:text-slate-400">
                          {q.sym}
                        </div>
                        <div className="formula-ltr text-xl font-black theme-text my-0.5 tabular-nums">
                          {q.val}
                        </div>
                        <div className="text-[11px] text-slate-600 dark:text-slate-400">{q.title}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SOLVER B: Mole, Mass, Particles, STP & rtp */}
          {solverTool === 'mole' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-5 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
                <h3 className="font-black text-lg text-slate-900 dark:text-slate-100">
                  مُحلّل مسائل المول والغازات (الدرس 01)
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <label className="space-y-1 text-xs font-bold block">
                    <span className="text-slate-600 dark:text-slate-300">الكتلة m (جرام)</span>
                    <input
                      type="number"
                      min="0.01"
                      step="any"
                      value={massInput}
                      onChange={(e) => setMassInput(e.target.value)}
                      className="formula-ltr w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-sm font-bold"
                    />
                  </label>
                  <label className="space-y-1 text-xs font-bold block">
                    <span className="text-slate-600 dark:text-slate-300">الكتلة المولية M (g/mol)</span>
                    <input
                      type="number"
                      min="1"
                      step="any"
                      value={molarMassInput}
                      onChange={(e) => setMolarMassInput(e.target.value)}
                      className="formula-ltr w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-sm font-bold"
                    />
                  </label>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {[
                    { label: 'CO₂ (44 g)', m: '44', M: '44' },
                    { label: 'H₂O (9 g)', m: '9', M: '18' },
                    { label: 'O₂ (16 g)', m: '16', M: '32' },
                    { label: 'NH₃ (34 g)', m: '34', M: '17' },
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => {
                        setMassInput(preset.m);
                        setMolarMassInput(preset.M);
                      }}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-xs font-bold hover:border-cyan-400 cursor-pointer"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                {!moleResult.valid ? (
                  <p className="text-xs font-bold text-rose-600 dark:text-rose-400">{moleResult.error}</p>
                ) : (
                  <div className="grid grid-cols-3 gap-2 text-center pt-1">
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-white/10">
                      <div className="text-[11px] text-slate-500">المولات n</div>
                      <div className="formula-ltr text-base font-black theme-text tabular-nums">
                        {moleResult.moles} mol
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-white/10">
                      <div className="text-[11px] text-slate-500">حجم STP</div>
                      <div className="formula-ltr text-base font-black theme-text tabular-nums">
                        {moleResult.volumeSTP} L
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-white/10">
                      <div className="text-[11px] text-slate-500">حجم rtp</div>
                      <div className="formula-ltr text-base font-black theme-text tabular-nums">
                        {moleResult.volumeRTP} L
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
                <h4 className="font-extrabold text-sm theme-text">خطوات الحل النموذجي بالشرح</h4>
                {moleResult.valid && (
                  <>
                    <div className="space-y-3">
                      {moleResult.steps.map((step) => (
                        <div
                          key={step.stepNumber}
                          className="p-4 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.03] space-y-1.5"
                        >
                          <div className="text-xs font-black text-slate-900 dark:text-slate-100">
                            الخطوة {step.stepNumber}: {step.title}
                          </div>
                          {step.formula && (
                            <div className="formula-ltr text-xs sm:text-sm font-extrabold theme-text bg-white dark:bg-slate-950/70 px-3 py-2 rounded-lg border border-slate-200/80 dark:border-white/10">
                              {step.formula}
                            </div>
                          )}
                          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                            {step.explanation}
                          </p>
                        </div>
                      ))}
                    </div>
                    <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 text-xs font-semibold text-amber-800 dark:text-amber-200">
                      {moleResult.examTrap}
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* SOLVER C: Dilution & Molarity */}
          {solverTool === 'dilution' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-5 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
                <h3 className="font-black text-lg text-slate-900 dark:text-slate-100">
                  مُحلّل التخفيف والمولارية (الدرس 04)
                </h3>
                <div className="grid grid-cols-3 gap-2.5">
                  <label className="space-y-1 text-xs font-bold block">
                    <span className="text-slate-600 dark:text-slate-300">M₁ (مولاري)</span>
                    <input
                      type="number"
                      min="0.05"
                      step="0.1"
                      value={m1Input}
                      onChange={(e) => setM1Input(e.target.value)}
                      className="formula-ltr w-full px-2.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-sm font-bold"
                    />
                  </label>
                  <label className="space-y-1 text-xs font-bold block">
                    <span className="text-slate-600 dark:text-slate-300">V₁ (mL)</span>
                    <input
                      type="number"
                      min="1"
                      step="10"
                      value={v1Input}
                      onChange={(e) => setV1Input(e.target.value)}
                      className="formula-ltr w-full px-2.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-sm font-bold"
                    />
                  </label>
                  <label className="space-y-1 text-xs font-bold block">
                    <span className="text-slate-600 dark:text-slate-300">M₂ (الهدف)</span>
                    <input
                      type="number"
                      min="0.01"
                      step="0.05"
                      value={m2Input}
                      onChange={(e) => setM2Input(e.target.value)}
                      className="formula-ltr w-full px-2.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-sm font-bold"
                    />
                  </label>
                </div>

                {!dilutionResult.valid ? (
                  <p className="text-xs font-bold text-rose-600 dark:text-rose-400">
                    {dilutionResult.error}
                  </p>
                ) : (
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-white/10">
                      <div className="text-[11px] text-slate-500">الحجم النهائي V₂</div>
                      <div className="formula-ltr text-lg font-black theme-text tabular-nums">
                        {dilutionResult.v2Ml} mL
                      </div>
                    </div>
                    <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
                      <div className="text-[11px] text-emerald-700 dark:text-emerald-300 font-bold">
                        الماء المضاف (V₂ − V₁)
                      </div>
                      <div className="formula-ltr text-lg font-black text-emerald-600 dark:text-emerald-300 tabular-nums">
                        {dilutionResult.waterAddedMl} mL
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
                <h4 className="font-extrabold text-sm theme-text">خطوات الحل النموذجي لقانون التخفيف</h4>
                {dilutionResult.valid && (
                  <>
                    <div className="space-y-3">
                      {dilutionResult.steps.map((step) => (
                        <div
                          key={step.stepNumber}
                          className="p-4 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.03] space-y-1.5"
                        >
                          <div className="text-xs font-black text-slate-900 dark:text-slate-100">
                            الخطوة {step.stepNumber}: {step.title}
                          </div>
                          {step.formula && (
                            <div className="formula-ltr text-xs sm:text-sm font-extrabold theme-text bg-white dark:bg-slate-950/70 px-3 py-2 rounded-lg border border-slate-200/80 dark:border-white/10">
                              {step.formula}
                            </div>
                          )}
                          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                            {step.explanation}
                          </p>
                        </div>
                      ))}
                    </div>
                    <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 text-xs font-semibold text-amber-800 dark:text-amber-200">
                      {dilutionResult.examTrap}
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* SOLVER D: Oxidation Number Worked Cases */}
          {solverTool === 'oxidation' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-5 grid grid-cols-2 gap-2.5">
                {OXIDATION_WORKED_CASES.map((item) => {
                  const selected = item.id === activeOxCase.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setSelectedOxId(item.id)}
                      className={`p-4 rounded-2xl border text-right transition cursor-pointer ${
                        selected
                          ? 'theme-border theme-bg-soft shadow-sm'
                          : 'border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04]'
                      }`}
                    >
                      <div className="formula-ltr text-lg font-black text-slate-900 dark:text-slate-100">
                        {item.formula}
                      </div>
                      <div className="text-xs font-bold theme-text mt-1">
                        {item.targetElement} = {item.result}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                        {item.category}
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-white/10">
                  <div>
                    <div className="text-xs font-bold theme-text">{activeOxCase.category}</div>
                    <h4 className="text-xl font-black text-slate-900 dark:text-slate-100 mt-0.5">
                      حساب عدد تأكسد ({activeOxCase.targetElement}) في المركب{' '}
                      <span className="formula-ltr">{activeOxCase.formula}</span>
                    </h4>
                  </div>
                  <div className="formula-ltr text-2xl font-black theme-text px-4 py-2 rounded-2xl theme-bg-soft">
                    {activeOxCase.targetElement} = {activeOxCase.result}
                  </div>
                </div>

                <div className="space-y-2.5">
                  {activeOxCase.equationSteps.map((step, i) => (
                    <div
                      key={i}
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-900/60 flex items-center gap-3"
                    >
                      <span className="w-7 h-7 rounded-lg theme-grad-btn text-white text-xs font-black flex items-center justify-center shrink-0 tabular-nums">
                        {i + 1}
                      </span>
                      <span className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                        {step}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-xs font-semibold text-emerald-800 dark:text-emerald-200">
                  القاعدة الذهبية: {activeOxCase.ruleSummary}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Concept Clarifiers & Exam Trap Breakers */}
      {subTab === 'compare' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {CONCEPT_COMPARISON_DECKS.map((deck) => {
            const chosen = compareAnswers[deck.id];
            const answered = chosen !== undefined;
            const isCorrect = chosen === deck.quickCheck.correctIndex;

            return (
              <article
                key={deck.id}
                className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-black text-base sm:text-lg text-slate-900 dark:text-slate-100">
                      {deck.title}
                    </h3>
                    <button
                      type="button"
                      onClick={() => onJumpToLesson(deck.lessonId)}
                      className="shrink-0 text-xs font-bold theme-text hover:underline cursor-pointer"
                    >
                      افتح الدرس
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-white/10 space-y-2">
                      <div className="text-xs font-black theme-text">{deck.leftTitle}</div>
                      <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                        {deck.leftPoints.map((pt, idx) => (
                          <li key={idx}>• {pt}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-white/10 space-y-2">
                      <div className="text-xs font-black text-cyan-600 dark:text-cyan-400">
                        {deck.rightTitle}
                      </div>
                      <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                        {deck.rightPoints.map((pt, idx) => (
                          <li key={idx}>• {pt}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-xs font-bold text-amber-800 dark:text-amber-200">
                    خلاصة الفهم: {deck.goldenRule}
                  </div>
                </div>

                {/* Mini Instant Understanding Check */}
                <div className="pt-3 border-t border-slate-200 dark:border-white/10 space-y-2.5">
                  <div className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
                    اختبر فهمك السريع: {deck.quickCheck.question}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {deck.quickCheck.options.map((opt, idx) => {
                      const picked = chosen === idx;
                      const right = idx === deck.quickCheck.correctIndex;
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setCompareAnswers((prev) => ({ ...prev, [deck.id]: idx }));
                            onNotify(
                              idx === deck.quickCheck.correctIndex
                                ? 'إجابة صحيحة! أحسنت الفهم'
                                : 'راجع الملاحظة العلمية أسفل السؤال',
                              idx === deck.quickCheck.correctIndex ? 'success' : 'info'
                            );
                          }}
                          className={`px-3 py-2 rounded-xl border text-xs font-bold transition cursor-pointer ${
                            answered && right
                              ? 'border-emerald-500 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                              : answered && picked && !right
                                ? 'border-rose-500 bg-rose-500/15 text-rose-700 dark:text-rose-300'
                                : 'border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:border-cyan-400'
                          }`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                  {answered && (
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p
                        className={`text-xs font-bold flex-1 min-w-0 ${
                          isCorrect
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {deck.quickCheck.feedback}
                      </p>
                      {!isCorrect && (
                        <WrongAnswerExplainButton
                          questionId={`mastery-check-${deck.id}`}
                          questionText={deck.quickCheck.question}
                          lessonId={deck.lessonId}
                          sectionIndex={0}
                          onJumpToExplanation={onJumpToExplanation}
                        />
                      )}
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* TAB 4: Live Readiness Diagnostic & Smart Study Plan */}
      {subTab === 'roadmap' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-extrabold theme-text">تقرير الجاهزية الفعلي</div>
                <h3 className="text-xl font-black text-slate-900 dark:text-slate-100 mt-0.5">
                  مستوى إتقانك للمنهج الآن
                </h3>
              </div>
              <div className="formula-ltr text-3xl font-black theme-text tabular-nums">
                {diagnostic.overallPercent}%
              </div>
            </div>

            <div className="h-3 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full theme-grad-btn transition-all duration-500"
                style={{ width: `${Math.max(4, diagnostic.overallPercent)}%` }}
              />
            </div>

            {/* Single Highest-Priority Next Action */}
            <div className="p-4 rounded-2xl border theme-border theme-bg-soft space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-extrabold theme-text">
                <BrainCircuit className="w-4 h-4" />
                <span>الخطوة الأهم لك الآن</span>
              </div>
              <div className="font-black text-sm sm:text-base text-slate-900 dark:text-slate-100">
                {diagnostic.priorityAction.title}
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                {diagnostic.priorityAction.reason}
              </p>
              <button
                type="button"
                onClick={() =>
                  diagnostic.priorityAction.mode === 'mistakes'
                    ? onOpenMistakes()
                    : onJumpToLesson(diagnostic.priorityAction.lessonId)
                }
                className="theme-grad-btn px-4 py-2.5 rounded-xl text-white text-xs sm:text-sm font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <span>
                  {diagnostic.priorityAction.mode === 'mistakes'
                    ? 'افتح سجل أخطائي للمعالجة'
                    : 'ابدأ هذا الدرس الآن'}
                </span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-4">
            {diagnostic.byUnit.map((u) => (
              <div
                key={u.unitId}
                className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h4 className="font-black text-base text-slate-900 dark:text-slate-100">
                      {u.unitName}
                    </h4>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                      دروس مكتملة: {u.completedCount}/{u.totalLessons} · أخطاء تحتاج معالجة:{' '}
                      {u.unresolvedMistakes}
                    </div>
                  </div>
                  <span className="formula-ltr text-lg font-black theme-text tabular-nums">
                    {u.readinessPercent}%
                  </span>
                </div>
                <div className="h-2.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full theme-grad-btn transition-all duration-500"
                    style={{ width: `${Math.max(3, u.readinessPercent)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
