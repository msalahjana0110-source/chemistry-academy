import React, { useMemo } from 'react';
import katex from 'katex';
import 'katex/contrib/mhchem';
import 'katex/dist/katex.min.css';

interface CurriculumMathTextProps {
  text: string;
  className?: string;
}

const SUB_TO_ASCII: Record<string, string> = {
  '₀': '0', '₁': '1', '₂': '2', '₃': '3', '₄': '4',
  '₅': '5', '₆': '6', '₇': '7', '₈': '8', '₉': '9',
  '⁰': '^0', '¹': '^1', '²': '^2', '³': '^3', '⁴': '^4',
  '⁵': '^5', '⁶': '^6', '⁷': '^7', '⁸': '^8', '⁹': '^9',
  '⁺': '^+', '⁻': '^-',
};

function renderKatexHtml(expr: string, displayMode: boolean): string {
  try {
    return katex.renderToString(expr.trim(), {
      displayMode,
      throwOnError: false,
      strict: false,
      trust: false,
    });
  } catch {
    return expr;
  }
}

export function KatexFormula({
  expression,
  displayMode = false,
  className = '',
}: {
  expression: string;
  displayMode?: boolean;
  className?: string;
}) {
  const html = useMemo(
    () => renderKatexHtml(expression, displayMode),
    [expression, displayMode]
  );

  if (displayMode) {
    return (
      <div
        dir="ltr"
        className={`katex-ltr-block custom-scrollbar bg-slate-100/90 dark:bg-slate-900/90 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-slate-100 ${className}`}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }

  return (
    <span
      dir="ltr"
      className={`katex-ltr-inline custom-scrollbar ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}

function splitChemicalEquationLine(line: string): { prefix?: string; equation: string } | null {
  const trimmed = line.trim();
  if (trimmed.length < 7 || trimmed.length > 220) return null;
  if (!/[→⇌]|->/.test(trimmed)) return null;

  // Check if line has an Arabic prefix separated by a colon (e.g. "- في الماء والأكسجين: 4NO₂(g) + ...")
  const colonIdx = trimmed.indexOf(':');
  let prefix: string | undefined;
  let candidate = trimmed;
  if (colonIdx > 0 && colonIdx < trimmed.length - 6) {
    const left = trimmed.slice(0, colonIdx).replace(/^[-*•]\s*/, '').trim();
    const right = trimmed.slice(colonIdx + 1).trim();
    if (/[\u0621-\u064A]/.test(left) && /[→⇌]|->/.test(right)) {
      prefix = left;
      candidate = right;
    }
  }

  // Strip known arrow condition annotations before checking for leftover Arabic prose
  const withoutArrowNote = candidate
    .replace(/--\(ضوء الشمس \/ كلوروفيل\)-->/g, '->')
    .replace(/\([^)]*[\u0621-\u064A][^)]*\)/g, '');
  const hasChem = /[A-Z][a-z]?(?:[₀-₉0-9]|[(+\s→⇌])/.test(withoutArrowNote);
  const leftoverArabic = /[\u0621-\u064A]{2,}/.test(withoutArrowNote);

  if (!hasChem || leftoverArabic) return null;
  return { prefix, equation: candidate };
}

function plainChemToMhchem(line: string): string {
  const cleaned = line
    .trim()
    .replace(/\(([^)]*[\u0621-\u064A][^)]*)\)/g, '')
    .replace(/[₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]/g, (ch) => SUB_TO_ASCII[ch] ?? ch)
    .replace(/⇌/g, '<=>')
    .replace(/--\(ضوء الشمس \/ كلوروفيل\)-->/g, '->[\\text{Sunlight / Chlorophyll}]')
    .replace(/→/g, '->')
    .replace(/↑/g, '^')
    .replace(/UV\s*\(<\s*240\s*nm\)/gi, '\\text{UV (< 240 nm)}')
    .trim();
  return `\\ce{${cleaned}}`;
}

function renderInlineSegments(line: string, keyPrefix: string): React.ReactNode[] {
  // Tokenize explicit LaTeX ($...$, \(...\), \ce{...}) and bold (**...**)
  const pattern = /(\$\$[\s\S]+?\$\$|\$[^$\n]+?\$|\\\([\s\S]+?\\\)|\\ce\{[^}]+\}|\*\*[^*\n]+?\*\*)/g;
  const parts = line.split(pattern);

  return parts.map((part, idx) => {
    const key = `${keyPrefix}-${idx}`;
    if (!part) return null;
    if (part.startsWith('$$') && part.endsWith('$$')) {
      return <KatexFormula key={key} expression={part.slice(2, -2)} displayMode />;
    }
    if (part.startsWith('$') && part.endsWith('$') && part.length > 2) {
      return <KatexFormula key={key} expression={part.slice(1, -1)} displayMode={false} />;
    }
    if (part.startsWith('\\(') && part.endsWith('\\)')) {
      return <KatexFormula key={key} expression={part.slice(2, -2)} displayMode={false} />;
    }
    if (part.startsWith('\\ce{') && part.endsWith('}')) {
      return <KatexFormula key={key} expression={part} displayMode={false} />;
    }
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={key} className="font-extrabold text-slate-900 dark:text-white">
          {part.slice(2, -2)}
        </strong>
      );
    }

    // Isolate inline chemical formulas & numeric units like H₂SO₄, CaCO₃, 1.013×10⁵ N/m², V_rms < V_e
    const sciRegex =
      /((?:[A-Z][a-z]?[₀-₉0-9⁰-⁹⁺⁻]*){2,}(?:\((?:aq|s|l|g)\))?|pH\s*=\s*\d+(?:\.\d+)?|1\.013×10⁵\s*N\/m²|V_rms\s*[<>≤≥]\s*V_e|T_K\s*=\s*t_C\s*\+\s*273|t_F\s*=\s*\(1\.8\s*×\s*t_C\)\s*\+\s*32|Q\s*=\s*m\s*×\s*c\s*×\s*Δt|F\s*=\s*P\s*×\s*A|P_total\s*=\s*1\s*\+\s*\(h\s*\/\s*10\))/g;
    const subParts = part.split(sciRegex);
    return (
      <React.Fragment key={key}>
        {subParts.map((sp, sIdx) => {
          if (!sp) return null;
          if (sciRegex.test(sp)) {
            sciRegex.lastIndex = 0;
            // Render clean LTR isolated formula badge
            if (/=|<|>|≤|≥/.test(sp)) {
              const latex = sp
                .replace(/×/g, ' \\times ')
                .replace(/Δ/g, '\\Delta ')
                .replace(/≤/g, '\\le ')
                .replace(/≥/g, '\\ge ');
              return <KatexFormula key={`${key}-s-${sIdx}`} expression={latex} />;
            }
            if (/^1\.013/.test(sp)) {
              return (
                <KatexFormula
                  key={`${key}-s-${sIdx}`}
                  expression="1.013 \times 10^5\ \text{N/m}^2"
                />
              );
            }
            if (/[₀-₉⁰-⁹⁺⁻]/.test(sp)) {
              const mh = `\\ce{${sp.replace(/[₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]/g, (c) => SUB_TO_ASCII[c] ?? c)}}`;
              return <KatexFormula key={`${key}-s-${sIdx}`} expression={mh} />;
            }
            return (
              <span key={`${key}-s-${sIdx}`} dir="ltr" className="formula-ltr font-semibold mx-0.5">
                {sp}
              </span>
            );
          }
          return <React.Fragment key={`${key}-t-${sIdx}`}>{sp}</React.Fragment>;
        })}
      </React.Fragment>
    );
  });
}

export function CurriculumMathText({ text, className = '' }: CurriculumMathTextProps) {
  const blocks = useMemo(() => {
    const normalized = (text || '').replace(/\r\n/g, '\n');
    // Split out display math blocks $$...$$ and \[...\] first
    return normalized.split(/(\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\])/g);
  }, [text]);

  return (
    <div className={`space-y-2 leading-relaxed break-words ${className}`}>
      {blocks.map((block, bIdx) => {
        if (!block) return null;
        if (block.startsWith('$$') && block.endsWith('$$')) {
          return <KatexFormula key={`blk-${bIdx}`} expression={block.slice(2, -2)} displayMode />;
        }
        if (block.startsWith('\\[') && block.endsWith('\\]')) {
          return <KatexFormula key={`blk-${bIdx}`} expression={block.slice(2, -2)} displayMode />;
        }

        const lines = block.split('\n');
        return (
          <React.Fragment key={`blk-${bIdx}`}>
            {lines.map((rawLine, lIdx) => {
              const line = rawLine.trim();
              if (!line) return null;
              if (/^-{3,}$/.test(line) || /^={10,}$/.test(line)) {
                return (
                  <hr
                    key={`hr-${bIdx}-${lIdx}`}
                    className="border-slate-200 dark:border-white/10 my-2"
                  />
                );
              }
              if (line.startsWith('### ')) {
                return (
                  <h4
                    key={`h4-${bIdx}-${lIdx}`}
                    className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white pt-1"
                  >
                    {renderInlineSegments(line.slice(4), `h4-${bIdx}-${lIdx}`)}
                  </h4>
                );
              }
              if (line.startsWith('## ')) {
                return (
                  <h3
                    key={`h3-${bIdx}-${lIdx}`}
                    className="font-extrabold text-base text-slate-900 dark:text-white pt-1"
                  >
                    {renderInlineSegments(line.slice(3), `h3-${bIdx}-${lIdx}`)}
                  </h3>
                );
              }
              const chemSplit = splitChemicalEquationLine(line);
              if (chemSplit) {
                return (
                  <div key={`chem-${bIdx}-${lIdx}`} className="space-y-1">
                    {chemSplit.prefix && (
                      <p className="text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300">
                        {renderInlineSegments(chemSplit.prefix, `chem-pre-${bIdx}-${lIdx}`)}:
                      </p>
                    )}
                    <KatexFormula
                      expression={plainChemToMhchem(chemSplit.equation)}
                      displayMode
                    />
                  </div>
                );
              }
              if (/^[-*•]\s+/.test(line)) {
                return (
                  <div
                    key={`li-${bIdx}-${lIdx}`}
                    className="flex items-start gap-2 pr-1 text-sm leading-7"
                  >
                    <span className="mt-2.5 w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                    <div className="min-w-0 flex-1">
                      {renderInlineSegments(line.replace(/^[-*•]\s+/, ''), `li-${bIdx}-${lIdx}`)}
                    </div>
                  </div>
                );
              }
              return (
                <p key={`p-${bIdx}-${lIdx}`} className="text-sm leading-7">
                  {renderInlineSegments(line, `p-${bIdx}-${lIdx}`)}
                </p>
              );
            })}
          </React.Fragment>
        );
      })}
    </div>
  );
}
