import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Atom,
  Calculator,
  CheckCircle2,
  Droplets,
  FlaskConical,
  Layers,
  Play,
  RotateCcw,
  Sparkles,
  XCircle,
  Zap,
} from 'lucide-react';
import { calculateMolarMass } from '../utils/chemistryEngine';
import {
  CONFIG_ELEMENTS_CATALOG,
  HYDROGEN_VISIBLE_SPECTRUM,
  LIMITING_REACTIONS,
  OXIDATION_CHALLENGES,
  OXIDE_SAMPLES,
  buildElectronConfiguration,
  evaluateHydrogenTransition,
  simulateRutherfordBurst,
  solveDilution,
  solveLimitingReactant,
  testOxideWithReagent,
  type LimitingReactionPreset,
  type ReagentId,
} from '../utils/grade2LabEngine';

interface Grade2LabProps {
  onNotify: (msg: string) => void;
}

// ============================================================================
// LAB 1: STOICHIOMETRY, LIMITING REACTANT & DILUTION (M1V1 = M2V2)
// ============================================================================
export function StoichiometryLab({ onNotify }: Grade2LabProps) {
  const [mode, setMode] = useState<'molar' | 'limiting' | 'dilution'>('molar');

  // Sub-mode A: Molar Mass, Moles & Gas Volume (STP / rtp)
  const [formula, setFormula] = useState('CuSO4');
  const [grams, setGrams] = useState('159.5');
  const molarResult = useMemo(() => calculateMolarMass(formula), [formula]);
  const parsedGrams = Number.parseFloat(grams);
  const moles =
    molarResult.valid && Number.isFinite(parsedGrams) && parsedGrams >= 0
      ? parsedGrams / molarResult.molarMass
      : null;

  // Sub-mode B: Limiting Reactant
  const [reactionId, setReactionId] = useState<LimitingReactionPreset['id']>('h2-f2');
  const [molA, setMolA] = useState(6);
  const [molB, setMolB] = useState(4);
  const limitingResult = useMemo(
    () => solveLimitingReactant(reactionId, molA, molB),
    [molA, molB, reactionId]
  );

  // Sub-mode C: Dilution M1V1 = M2V2
  const [m1, setM1] = useState(2.0);
  const [v1Ml, setV1Ml] = useState(100);
  const [m2, setM2] = useState(0.5);
  const dilution = useMemo(() => solveDilution(m1, v1Ml, m2), [m1, m2, v1Ml]);

  return (
    <div className="space-y-5">
      {/* Sub-mode Switcher */}
      <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 w-fit">
        {[
          { id: 'molar', label: 'المول والكتلة وحجم الغاز (STP/rtp)', icon: Calculator },
          { id: 'limiting', label: 'العامل المحدد للتفاعل', icon: FlaskConical },
          { id: 'dilution', label: 'تخفيف المحاليل (M₁V₁ = M₂V₂)', icon: Droplets },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setMode(item.id as typeof mode)}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 transition cursor-pointer ${
                mode === item.id
                  ? 'theme-grad-btn text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Mode A: Molar Mass + STP/rtp */}
      {mode === 'molar' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
            <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">
              حاسبة المول والكتلة المولية وحجم الغاز
            </h3>
            <div className="space-y-1.5">
              <label htmlFor="g2-formula" className="text-xs font-bold block">
                الصيغة الكيميائية (تدعم الأقواس مثل Ca(OH)2 و Fe2(SO4)3)
              </label>
              <input
                id="g2-formula"
                type="text"
                dir="ltr"
                lang="en"
                value={formula}
                onChange={(e) => setFormula(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-950/70 formula-ltr text-base font-bold"
              />
            </div>
            <div className="flex flex-wrap gap-1.5">
              {['Na2CO3', 'CH4', 'CO2', 'H2SO4', 'Ca(OH)2', 'KNO3'].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setFormula(preset)}
                  className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-white/15 bg-slate-100 dark:bg-white/5 hover:theme-border formula-ltr text-xs font-bold cursor-pointer"
                >
                  {preset}
                </button>
              ))}
            </div>
            <div className="space-y-1.5 pt-2 border-t border-slate-200 dark:border-white/10">
              <label htmlFor="g2-grams" className="text-xs font-bold block">
                كتلة العينة بالجرام (g)
              </label>
              <input
                id="g2-grams"
                type="number"
                dir="ltr"
                lang="en"
                min="0"
                step="0.1"
                value={grams}
                onChange={(e) => setGrams(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-950/70 formula-ltr text-base font-bold"
              />
            </div>
          </div>

          <div className="lg:col-span-7 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            {!molarResult.valid ? (
              <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-sm font-bold text-rose-600 dark:text-rose-300">
                {molarResult.error}
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                    <div className="text-[11px] font-bold text-slate-500">الكتلة المولية (M)</div>
                    <div className="formula-ltr text-lg font-black theme-text tabular-nums mt-0.5">
                      {molarResult.molarMass} g/mol
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                    <div className="text-[11px] font-bold text-slate-500">عدد المولات (n)</div>
                    <div className="formula-ltr text-lg font-black theme-text tabular-nums mt-0.5">
                      {moles !== null ? `${moles.toFixed(3)} mol` : '—'}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                    <div className="text-[11px] font-bold text-slate-500">حجم الغاز (STP)</div>
                    <div className="formula-ltr text-lg font-black text-slate-900 dark:text-cyan-300 tabular-nums mt-0.5">
                      {moles !== null ? `${(moles * 22.4).toFixed(2)} L` : '—'}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                    <div className="text-[11px] font-bold text-slate-500">حجم الغاز (rtp)</div>
                    <div className="formula-ltr text-lg font-black text-slate-900 dark:text-cyan-300 tabular-nums mt-0.5">
                      {moles !== null ? `${(moles * 24).toFixed(2)} L` : '—'}
                    </div>
                  </div>
                </div>

                {moles !== null && (
                  <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950/60 border border-slate-200 dark:border-white/10 text-xs sm:text-sm space-y-1">
                    <div className="font-extrabold theme-text">خطوات الحساب وعدد الجسيمات (أفوجادرو):</div>
                    <div className="formula-ltr text-slate-700 dark:text-slate-200 font-bold">
                      n = {parsedGrams} / {molarResult.molarMass} = {moles.toFixed(3)} mol  |  N = {(moles * 6.02).toFixed(2)} × 10²³ particle
                    </div>
                    <div className="formula-ltr text-xs text-slate-500 dark:text-slate-400">
                      Density (STP) = {molarResult.molarMass} / 22.4 = {(molarResult.molarMass / 22.4).toFixed(2)} g/L
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <div className="text-xs font-extrabold text-slate-500">التحليل الكتلي لعناصر الصيغة:</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {molarResult.breakdown.map((item) => (
                      <div
                        key={item.symbol}
                        className="p-3 rounded-xl border border-slate-200 dark:border-white/10 flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-extrabold text-slate-900 dark:text-white">
                            {item.nameAr} ({item.symbol})
                          </span>
                          <span className="text-slate-500 mr-1.5">× {item.count}</span>
                        </div>
                        <div className="formula-ltr font-bold theme-text tabular-nums">
                          {item.subtotalMass} g ({item.percentage}%)
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Mode B: Limiting Reactant Visualizer */}
      {mode === 'limiting' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">
              مختبر العامل المحدد للتفاعل
            </h3>

            <div className="space-y-2">
              {LIMITING_REACTIONS.map((rxn) => (
                <button
                  key={rxn.id}
                  type="button"
                  onClick={() => setReactionId(rxn.id)}
                  className={`w-full p-3 rounded-xl border text-right transition cursor-pointer ${
                    reactionId === rxn.id
                      ? 'theme-border theme-bg-soft'
                      : 'border-slate-200 dark:border-white/10 hover:border-slate-300'
                  }`}
                >
                  <div className="text-xs font-extrabold text-slate-900 dark:text-white">
                    {rxn.titleAr}
                  </div>
                  <div className="formula-ltr text-xs font-bold theme-text mt-0.5 text-right">
                    {rxn.equationDisplay}
                  </div>
                </button>
              ))}
            </div>

            <div className="space-y-4 pt-2 border-t border-slate-200 dark:border-white/10">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <label htmlFor="mol-a-slider">
                    مولات {limitingResult.reaction.reactantA.nameAr} ({limitingResult.reaction.reactantA.formula})
                  </label>
                  <span className="formula-ltr theme-text tabular-nums">{molA} mol</span>
                </div>
                <input
                  id="mol-a-slider"
                  type="range"
                  min={1}
                  max={12}
                  step={1}
                  value={molA}
                  onChange={(e) => setMolA(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <label htmlFor="mol-b-slider">
                    مولات {limitingResult.reaction.reactantB.nameAr} ({limitingResult.reaction.reactantB.formula})
                  </label>
                  <span className="formula-ltr theme-text tabular-nums">{molB} mol</span>
                </div>
                <input
                  id="mol-b-slider"
                  type="range"
                  min={1}
                  max={12}
                  step={1}
                  value={molB}
                  onChange={(e) => setMolB(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="font-extrabold text-base text-slate-900 dark:text-white">
                نتيجة التفاعل وتوزيع الاستهلاك والفائض
              </div>
              <code className="formula-ltr text-xs font-black theme-text">
                {limitingResult.reaction.equationDisplay}
              </code>
            </div>

            {/* Visual Ratio Bars */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div
                className={`p-4 rounded-xl border ${
                  limitingResult.limiting === 'A'
                    ? 'border-rose-500 bg-rose-500/10'
                    : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/60'
                }`}
              >
                <div className="text-xs font-bold text-slate-500">
                  {limitingResult.reaction.reactantA.formula} (المعامل {limitingResult.reaction.reactantA.coeff})
                </div>
                <div className="formula-ltr text-lg font-black mt-1 tabular-nums">
                  نسبة: {limitingResult.ratioA}
                </div>
                <div className="text-xs font-bold mt-1">
                  {limitingResult.limiting === 'A'
                    ? 'العامل المحدد (يُستهلك 100%)'
                    : `يتبقى فائض: ${limitingResult.remainingA} mol`}
                </div>
              </div>

              <div
                className={`p-4 rounded-xl border ${
                  limitingResult.limiting === 'B'
                    ? 'border-rose-500 bg-rose-500/10'
                    : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/60'
                }`}
              >
                <div className="text-xs font-bold text-slate-500">
                  {limitingResult.reaction.reactantB.formula} (المعامل {limitingResult.reaction.reactantB.coeff})
                </div>
                <div className="formula-ltr text-lg font-black mt-1 tabular-nums">
                  نسبة: {limitingResult.ratioB}
                </div>
                <div className="text-xs font-bold mt-1">
                  {limitingResult.limiting === 'B'
                    ? 'العامل المحدد (يُستهلك 100%)'
                    : `يتبقى فائض: ${limitingResult.remainingB} mol`}
                </div>
              </div>

              <div className="p-4 rounded-xl border border-emerald-500/40 bg-emerald-500/10">
                <div className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
                  الناتج المتكوّن ({limitingResult.reaction.product.formula})
                </div>
                <div className="formula-ltr text-xl font-black text-emerald-700 dark:text-emerald-300 mt-1 tabular-nums">
                  {limitingResult.productMoles} mol
                </div>
                <div className="formula-ltr text-[11px] font-bold text-slate-600 dark:text-slate-300 mt-1 tabular-nums">
                  STP: {limitingResult.productVolumeStpL} L
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950/60 border border-slate-200 dark:border-white/10 text-sm font-bold text-slate-800 dark:text-slate-200 leading-relaxed">
              {limitingResult.summaryAr}
            </div>
          </div>
        </div>
      )}

      {/* Mode C: Dilution Visualizer */}
      {mode === 'dilution' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">
              محاكي تخفيف المحاليل (M₁V₁ = M₂V₂)
            </h3>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <label htmlFor="dil-m1">التركيز الابتدائي M₁</label>
                  <span className="formula-ltr theme-text tabular-nums">{m1.toFixed(1)} M</span>
                </div>
                <input
                  id="dil-m1"
                  type="range"
                  min={0.5}
                  max={3.0}
                  step={0.1}
                  value={m1}
                  onChange={(e) => {
                    const nextM1 = Number(e.target.value);
                    setM1(nextM1);
                    if (m2 > nextM1) setM2(Number((nextM1 / 2).toFixed(1)));
                  }}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <label htmlFor="dil-v1">الحجم الابتدائي V₁</label>
                  <span className="formula-ltr theme-text tabular-nums">{v1Ml} mL</span>
                </div>
                <input
                  id="dil-v1"
                  type="range"
                  min={50}
                  max={400}
                  step={25}
                  value={v1Ml}
                  onChange={(e) => setV1Ml(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <label htmlFor="dil-m2">التركيز المطلوب بعد التخفيف M₂</label>
                  <span className="formula-ltr theme-text tabular-nums">{m2.toFixed(2)} M</span>
                </div>
                <input
                  id="dil-m2"
                  type="range"
                  min={0.1}
                  max={m1}
                  step={0.05}
                  value={m2}
                  onChange={(e) => setM2(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setM1(2.0);
                setV1Ml(100);
                setM2(0.5);
                onNotify('تمت إعادة ضبط تجربة التخفيف');
              }}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة الضبط</span>
            </button>
          </div>

          <div className="lg:col-span-7 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            {!dilution.valid ? (
              <div className="p-4 rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-300 text-sm font-bold">
                {dilution.error}
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-6 items-end justify-items-center py-2">
                  {/* Beaker Before */}
                  <div className="flex flex-col items-center gap-2">
                    <svg viewBox="0 0 140 160" className="w-32 h-36">
                      <rect
                        x="22"
                        y="20"
                        width="96"
                        height="126"
                        rx="10"
                        fill="rgba(148,163,184,0.1)"
                        stroke="currentColor"
                        strokeOpacity="0.4"
                        strokeWidth="2.5"
                      />
                      <rect
                        x="25"
                        y={142 - Math.min(105, Math.max(24, (v1Ml / Math.max(v1Ml, dilution.v2Ml)) * 105))}
                        width="90"
                        height={Math.min(105, Math.max(24, (v1Ml / Math.max(v1Ml, dilution.v2Ml)) * 105))}
                        rx="6"
                        fill={`rgba(14, 165, 233, ${dilution.beforeIntensity})`}
                        style={{ transition: 'all 300ms ease' }}
                      />
                    </svg>
                    <div className="text-xs font-extrabold">قبل التخفيف</div>
                    <div className="formula-ltr text-xs font-bold theme-text tabular-nums">
                      {m1.toFixed(1)} M · {v1Ml} mL
                    </div>
                  </div>

                  {/* Beaker After */}
                  <div className="flex flex-col items-center gap-2">
                    <svg viewBox="0 0 140 160" className="w-32 h-36">
                      <rect
                        x="22"
                        y="20"
                        width="96"
                        height="126"
                        rx="10"
                        fill="rgba(148,163,184,0.1)"
                        stroke="currentColor"
                        strokeOpacity="0.4"
                        strokeWidth="2.5"
                      />
                      <rect
                        x="25"
                        y={142 - Math.min(115, Math.max(36, 110))}
                        width="90"
                        height={Math.min(115, Math.max(36, 110))}
                        rx="6"
                        fill={`rgba(14, 165, 233, ${dilution.afterIntensity})`}
                        style={{ transition: 'all 300ms ease' }}
                      />
                    </svg>
                    <div className="text-xs font-extrabold">بعد إضافة الماء</div>
                    <div className="formula-ltr text-xs font-bold theme-text tabular-nums">
                      {m2.toFixed(2)} M · {dilution.v2Ml} mL
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                    <div className="text-[11px] font-bold text-slate-500">الحجم النهائي V₂</div>
                    <div className="formula-ltr text-base font-black theme-text tabular-nums">
                      {dilution.v2Ml} mL
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
                    <div className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
                      حجم الماء المضاف
                    </div>
                    <div className="formula-ltr text-base font-black text-emerald-700 dark:text-emerald-300 tabular-nums">
                      {dilution.waterAddedMl} mL
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                    <div className="text-[11px] font-bold text-slate-500">مولات المذاب (ثابتة)</div>
                    <div className="formula-ltr text-base font-black tabular-nums">
                      {dilution.soluteMoles} mol
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// LAB 2: RUTHERFORD GOLD FOIL SIMULATOR (LESSON 06)
// ============================================================================
export function RutherfordLab({ onNotify }: Grade2LabProps) {
  const [burstCount, setBurstCount] = useState(100);
  const [seed, setSeed] = useState(0);
  const [activeFilter, setActiveFilter] = useState<'all' | 'passed' | 'deflected' | 'bounced'>('all');

  const burst = useMemo(
    () => simulateRutherfordBurst(burstCount, seed),
    [burstCount, seed]
  );

  const visibleRays =
    activeFilter === 'all'
      ? burst.rays
      : burst.rays.filter((r) => r.outcome === activeFilter);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
      {/* Interactive SVG Chamber (7 cols) */}
      <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#070b18] text-slate-100 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="font-extrabold text-base sm:text-lg text-white">
              محاكي تجربة رذرفورد ورقيقة الذهب (جسيمات ألفا He²⁺)
            </h3>
            <p className="text-xs text-slate-400">
              شاهد نفاذ معظم الجسيمات، انحراف القليل قرب النواة الموجبة، وارتداد نسبة ضئيلة مع ومضات لوح ZnS
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setSeed((s) => s + 1);
              onNotify(`تم إطلاق حزمة جديدة من ${burstCount} جسيم ألفا (He²⁺)`);
            }}
            className="theme-grad-btn px-3.5 py-2 rounded-xl text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>إطلاق حزمة ألفا</span>
          </button>
        </div>

        <svg viewBox="0 0 420 240" className="w-full h-64 rounded-xl bg-slate-950/90 border border-white/10">
          {/* ZnS Circular Detector Screen */}
          <path
            d="M 105 32 A 118 104 0 1 1 105 208"
            fill="none"
            stroke="#22c55e"
            strokeOpacity="0.45"
            strokeWidth="7"
            strokeLinecap="round"
          />
          <text x="348" y="24" fill="#86efac" fontSize="9" fontWeight="700">
            لوح ZnS (ومضات)
          </text>

          {/* Lead Source Box */}
          <rect x="14" y="96" width="54" height="48" rx="6" fill="#334155" stroke="#94a3b8" strokeWidth="1.5" />
          <text x="41" y="117" textAnchor="middle" fill="#f8fafc" fontSize="9" fontWeight="800">
            مصدر α
          </text>
          <text x="41" y="131" textAnchor="middle" fill="#38bdf8" fontSize="8" fontWeight="700">
            He²⁺
          </text>

          {/* Gold Foil Thin Vertical Strip */}
          <line x1="212" y1="26" x2="212" y2="214" stroke="#facc15" strokeWidth="3.5" strokeOpacity="0.85" />
          <text x="212" y="18" textAnchor="middle" fill="#fde047" fontSize="9" fontWeight="800">
            رقيقة الذهب (Au)
          </text>

          {/* Enlarged Gold Atom & Positive Dense Nucleus */}
          <circle cx="212" cy="120" r="68" fill="rgba(250,204,21,0.06)" stroke="#facc15" strokeOpacity="0.28" strokeDasharray="4 4" />
          <circle cx="212" cy="120" r="11" fill="#f59e0b" stroke="#fef08a" strokeWidth="2" />
          <text x="212" y="123" textAnchor="middle" fill="#0f172a" fontSize="10" fontWeight="900">
            +
          </text>

          {/* Alpha Particle Rays */}
          {visibleRays.map((ray) => {
            const stroke =
              ray.outcome === 'passed'
                ? '#38bdf8'
                : ray.outcome === 'deflected'
                  ? '#f59e0b'
                  : '#f43f5e';
            const pathD =
              ray.outcome === 'passed'
                ? `M 68 ${ray.startY} L ${ray.endX} ${ray.endY}`
                : ray.outcome === 'deflected'
                  ? `M 68 ${ray.startY} L 200 ${ray.startY} Q 222 ${ray.startY} ${ray.endX} ${ray.endY}`
                  : `M 68 ${ray.startY} L 198 120 L ${ray.endX} ${ray.endY}`;
            return (
              <g key={`${seed}-${ray.id}`}>
                <path
                  d={pathD}
                  fill="none"
                  stroke={stroke}
                  strokeWidth={ray.outcome === 'passed' ? '1.35' : '2.2'}
                  strokeOpacity={ray.outcome === 'passed' ? '0.68' : '0.95'}
                  strokeDasharray={ray.outcome === 'passed' ? '6 4' : undefined}
                />
                {/* ZnS Flash Point */}
                <circle
                  cx={ray.endX}
                  cy={ray.endY}
                  r={ray.outcome === 'passed' ? '2.8' : '4.5'}
                  fill="#4ade80"
                  opacity="0.9"
                />
              </g>
            );
          })}
        </svg>

        {/* Ray Filter Chips */}
        <div className="flex flex-wrap gap-2 text-xs">
          {[
            { id: 'all', label: `كل الأشعة (${burst.total})` },
            { id: 'passed', label: `نافذة على استقامتها (${burst.passed})` },
            { id: 'deflected', label: `منحرفة (${burst.deflected})` },
            { id: 'bounced', label: `مرتدة للخلف (${burst.bounced})` },
          ].map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setActiveFilter(f.id as typeof activeFilter)}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                activeFilter === f.id
                  ? 'theme-grad-btn text-white'
                  : 'bg-white/10 text-slate-300 hover:bg-white/15'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Scientific Conclusions Deck (5 cols) */}
      <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold">
            <label htmlFor="alpha-burst-slider">عدد جسيمات ألفا المطلقة في التجربة</label>
            <span className="formula-ltr theme-text tabular-nums">{burstCount} جسيم</span>
          </div>
          <input
            id="alpha-burst-slider"
            type="range"
            min={50}
            max={500}
            step={50}
            value={burstCount}
            onChange={(e) => setBurstCount(Number(e.target.value))}
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        <div className="space-y-3 text-xs sm:text-sm">
          <div className="p-3.5 rounded-xl border border-sky-500/30 bg-sky-500/10 space-y-1">
            <div className="font-extrabold text-sky-700 dark:text-sky-300">
              1) نفاذ المعظم على استقامته ({Math.round((burst.passed / burst.total) * 100)}%)
            </div>
            <p className="text-slate-700 dark:text-slate-300 text-xs leading-relaxed">
              الاستنتاج: معظم حجم الذرة فراغ وليست كرة مصمتة كما تصور دالتون وطومسون.
            </p>
          </div>
          <div className="p-3.5 rounded-xl border border-rose-500/30 bg-rose-500/10 space-y-1">
            <div className="font-extrabold text-rose-700 dark:text-rose-300">
              2) ارتداد نسبة ضئيلة جداً للخلف ({Math.round((burst.bounced / burst.total) * 100)}%)
            </div>
            <p className="text-slate-700 dark:text-slate-300 text-xs leading-relaxed">
              الاستنتاج: وجود جزء صغير جداً كثافته عالية وتتركز فيه معظم كتلة الذرة (النواة).
            </p>
          </div>
          <div className="p-3.5 rounded-xl border border-amber-500/30 bg-amber-500/10 space-y-1">
            <div className="font-extrabold text-amber-700 dark:text-amber-300">
              3) انحراف بعض الجسيمات على الجانبين ({Math.round((burst.deflected / burst.total) * 100)}%)
            </div>
            <p className="text-slate-700 dark:text-slate-300 text-xs leading-relaxed">
              الاستنتاج: شحنة النواة موجبة مشابهة لشحنة جسيمات ألفا الموجبة (He²⁺) فتنافرت معها.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// LAB 3: BOHR HYDROGEN EMISSION SPECTRUM SIMULATOR (LESSON 07)
// ============================================================================
export function BohrSpectrumLab() {
  const [nInitial, setNInitial] = useState(3);
  const [nFinal, setNFinal] = useState(2);

  const result = useMemo(
    () => evaluateHydrogenTransition(nInitial, nFinal),
    [nInitial, nFinal]
  );

  const levelRadius = (n: number) => 22 + n * 16;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
      {/* Bohr Levels & Spectrometer Stage (7 cols) */}
      <div className="lg:col-span-7 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-[#070b18] text-slate-100 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="font-extrabold text-base sm:text-lg text-white">
              محاكي طيف الانبعاث الخطي لذرة الهيدروجين (نموذج بور)
            </h3>
            <p className="text-xs text-slate-400">
              اختر انتقال الإلكترون بين مستويات الطاقة n=1..7 وراقب المطياف الخطي
            </p>
          </div>
          <span
            className="formula-ltr px-3 py-1 rounded-lg text-xs font-black border"
            style={{
              borderColor: result.hexColor,
              color: result.hexColor,
              backgroundColor: `${result.hexColor}22`,
            }}
          >
            n={nInitial} → n={nFinal} {result.wavelengthNm ? `· ${result.wavelengthNm} nm` : ''}
          </span>
        </div>

        {/* Concentric Bohr Energy Levels SVG */}
        <div className="flex justify-center">
          <svg viewBox="0 0 320 290" className="w-full max-w-sm h-64">
            {[7, 6, 5, 4, 3, 2, 1].map((lvl) => {
              const r = levelRadius(lvl);
              const isStart = lvl === nInitial;
              const isEnd = lvl === nFinal;
              return (
                <g key={lvl}>
                  <circle
                    cx="160"
                    cy="145"
                    r={r}
                    fill="none"
                    stroke={isStart || isEnd ? result.hexColor : 'rgba(148,163,184,0.28)'}
                    strokeWidth={isStart || isEnd ? '2.2' : '1'}
                    strokeDasharray={isStart ? '5 3' : undefined}
                  />
                  <text
                    x={160 + r + 3}
                    y="148"
                    fill={isStart || isEnd ? '#f8fafc' : '#94a3b8'}
                    fontSize="8.5"
                    fontWeight="700"
                  >
                    {lvl}
                  </text>
                </g>
              );
            })}
            {/* Nucleus */}
            <circle cx="160" cy="145" r="9" fill="#f59e0b" />
            <text x="160" y="148" textAnchor="middle" fill="#0f172a" fontSize="9" fontWeight="900">
              H⁺
            </text>

            {/* Electron Transition Arrow (Top vertical axis) */}
            {nInitial !== nFinal && (
              <>
                <line
                  x1="160"
                  y1={145 - levelRadius(nInitial)}
                  x2="160"
                  y2={145 - levelRadius(nFinal)}
                  stroke={result.hexColor}
                  strokeWidth="3"
                />
                <circle
                  cx="160"
                  cy={145 - levelRadius(nInitial)}
                  r="4.5"
                  fill="#ffffff"
                  stroke={result.hexColor}
                  strokeWidth="2"
                />
                <circle
                  cx="160"
                  cy={145 - levelRadius(nFinal)}
                  r="5.5"
                  fill={result.hexColor}
                />
              </>
            )}
          </svg>
        </div>

        {/* Hydrogen Visible Emission Spectrometer Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300">
            <span>لوحة المطياف الخطي المرئي (العودة إلى n=2)</span>
            <span className="formula-ltr text-slate-400">410 nm ← 656 nm</span>
          </div>
          <div className="relative h-14 rounded-xl bg-black border border-white/15 overflow-hidden">
            {HYDROGEN_VISIBLE_SPECTRUM.map((line) => {
              const lit =
                result.region === 'visible' &&
                result.nInitial === line.nInitial &&
                result.nFinal === line.nFinal;
              return (
                <button
                  key={line.nm}
                  type="button"
                  onClick={() => {
                    setNInitial(line.nInitial);
                    setNFinal(2);
                  }}
                  title={`${line.nameAr} (${line.nm} nm)`}
                  style={{
                    left: `${line.posPct}%`,
                    backgroundColor: line.hex,
                    opacity: lit ? 1 : 0.28,
                    boxShadow: lit ? `0 0 18px ${line.hex}, 0 0 6px #ffffff` : 'none',
                  }}
                  className="absolute top-0 bottom-0 w-2 -translate-x-1/2 transition-all duration-300 cursor-pointer"
                />
              );
            })}
          </div>
          <div className="grid grid-cols-4 gap-2 text-center text-[11px] font-bold">
            {HYDROGEN_VISIBLE_SPECTRUM.map((line) => (
              <button
                key={line.nm}
                type="button"
                onClick={() => {
                  setNInitial(line.nInitial);
                  setNFinal(2);
                }}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 cursor-pointer"
              >
                <div style={{ color: line.hex }}>{line.nameAr}</div>
                <div className="formula-ltr text-slate-300">{line.nm} nm (n={line.nInitial}→2)</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Controls & Alerts (5 cols) */}
      <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
        <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">
          اختر مستويات انتقال الإلكترون
        </h3>

        <div className="space-y-4">
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-600 dark:text-slate-300">
              المستوى الابتدائي (<span className="formula-ltr">n<sub>i</sub> = {nInitial}</span>)
            </div>
            <div className="grid grid-cols-7 gap-1.5">
              {[1, 2, 3, 4, 5, 6, 7].map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setNInitial(lvl)}
                  className={`py-2 rounded-lg formula-ltr text-xs font-black border cursor-pointer ${
                    nInitial === lvl
                      ? 'theme-grad-btn text-white border-transparent'
                      : 'border-slate-200 dark:border-white/15'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-600 dark:text-slate-300">
              المستوى النهائي (<span className="formula-ltr">n<sub>f</sub> = {nFinal}</span>)
            </div>
            <div className="grid grid-cols-7 gap-1.5">
              {[1, 2, 3, 4, 5, 6, 7].map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setNFinal(lvl)}
                  className={`py-2 rounded-lg formula-ltr text-xs font-black border cursor-pointer ${
                    nFinal === lvl
                      ? 'theme-grad-btn text-white border-transparent'
                      : 'border-slate-200 dark:border-white/15'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Non-Visible Presets */}
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => {
              setNInitial(3);
              setNFinal(1);
            }}
            className="px-3 py-1.5 rounded-xl border border-purple-500/35 bg-purple-500/10 text-purple-700 dark:text-purple-300 text-xs font-bold cursor-pointer"
          >
            العودة إلى n=1 (فوق بنفسجية UV)
          </button>
          <button
            type="button"
            onClick={() => {
              setNInitial(5);
              setNFinal(3);
            }}
            className="px-3 py-1.5 rounded-xl border border-orange-500/35 bg-orange-500/10 text-orange-700 dark:text-orange-300 text-xs font-bold cursor-pointer"
          >
            العودة إلى n=3 (تحت حمراء IR)
          </button>
        </div>

        {/* Live Result Card */}
        <div
          className="p-4 rounded-xl border space-y-2"
          style={{
            borderColor: `${result.hexColor}66`,
            backgroundColor: `${result.hexColor}14`,
          }}
        >
          <div className="flex items-center justify-between text-xs font-extrabold">
            <span>{result.seriesNameAr}</span>
            <span className="formula-ltr tabular-nums">ΔE = {result.deltaEev} eV</span>
          </div>
          <div className="text-base font-black text-slate-900 dark:text-white">
            {result.colorNameAr}
            {result.wavelengthNm ? ` — ${result.wavelengthNm} nm` : ''}
          </div>
          <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
            {result.alertAr}
          </p>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// LAB 4: ELECTRON CONFIGURATION, ORBITAL BOXES & 4 QUANTUM NUMBERS (Z=1..36)
// ============================================================================
export function OrbitalsQuantumLab() {
  const [atomicNumber, setAtomicNumber] = useState(24); // Start on Cr to showcase anomaly!
  const report = useMemo(() => buildElectronConfiguration(atomicNumber), [atomicNumber]);

  return (
    <div className="space-y-5">
      {/* Element Selector Bar */}
      <div className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">
              مُنشئ التوزيع الإلكتروني ومربعات الأوربيتالات وأعداد الكم الأربعة (Z = 1..36)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              يطبّق مبدأ البناء التصاعدي (أوفباو) وقاعدة هوند ومبدأ باولي مع تنبيه شذوذ الكروم والنحاس
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {[7, 8, 17, 24, 26, 29, 36].map((z) => {
              const el = CONFIG_ELEMENTS_CATALOG[z - 1];
              return (
                <button
                  key={z}
                  type="button"
                  onClick={() => setAtomicNumber(z)}
                  className={`px-2.5 py-1.5 rounded-lg formula-ltr text-xs font-extrabold border cursor-pointer ${
                    atomicNumber === z
                      ? 'theme-grad-btn text-white border-transparent'
                      : 'border-slate-200 dark:border-white/15'
                  }`}
                >
                  {z} {el.symbol}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-8 space-y-1.5">
            <div className="flex justify-between text-xs font-bold">
              <label htmlFor="z-slider">اختر العدد الذري (Z)</label>
              <span className="theme-text font-extrabold">
                {report.nameAr} ({report.symbol}) · Z = {report.atomicNumber}
              </span>
            </div>
            <input
              id="z-slider"
              type="range"
              min={1}
              max={36}
              step={1}
              value={atomicNumber}
              onChange={(e) => setAtomicNumber(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>
          <div className="md:col-span-4">
            <select
              aria-label="اختر عنصراً من Z=1 إلى 36"
              value={atomicNumber}
              onChange={(e) => setAtomicNumber(Number(e.target.value))}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
            >
              {CONFIG_ELEMENTS_CATALOG.map((el) => (
                <option key={el.z} value={el.z}>
                  {el.z} — {el.nameAr} ({el.symbol})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Anomaly Alert for Cr (24) & Cu (29) */}
      {report.isAnomaly && report.anomalyNoteAr && (
        <div className="p-4 rounded-2xl border border-amber-500/40 bg-amber-500/10 flex items-start gap-3 text-xs sm:text-sm font-bold text-amber-800 dark:text-amber-200">
          <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-amber-500" />
          <span>{report.anomalyNoteAr}</span>
        </div>
      )}

      {/* Configuration & 4 Quantum Numbers Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-500">التوزيع الإلكتروني الكامل (مبدأ البناء التصاعدي):</div>
            <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-950/70 formula-ltr text-sm sm:text-base font-black theme-text overflow-x-auto">
              {report.fullConfig}
            </div>
            <div className="text-xs font-bold text-slate-600 dark:text-slate-300 flex flex-wrap gap-4">
              <span>
                الاختصار لأقرب غاز خامل: <code className="formula-ltr theme-text font-black">{report.shorthandConfig}</code>
              </span>
              <span>
                عدد الإلكترونات المفردة: <strong className="theme-text tabular-nums">{report.unpairedCount}</strong>
              </span>
            </div>
          </div>

          {/* Hund & Pauli Orbital Boxes */}
          <div className="space-y-3">
            <div className="text-xs font-extrabold text-slate-600 dark:text-slate-300">
              توزيع الأوربيتالات والغزل المغناطيسي (قاعدة هوند ومبدأ باولي):
            </div>
            <div className="flex flex-wrap gap-4">
              {report.subshells.map((sub) => (
                <div
                  key={sub.label}
                  className="p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/50 space-y-2"
                >
                  <div className="flex items-center justify-between gap-2 text-xs font-black">
                    <span className="formula-ltr theme-text">{sub.label}</span>
                    <span className="formula-ltr text-[10px] text-slate-500">
                      {sub.electrons}/{sub.capacity}
                    </span>
                  </div>
                  <div className="flex gap-1.5" dir="ltr">
                    {sub.orbitals.map((orb) => (
                      <div key={orb.ml} className="flex flex-col items-center gap-1">
                        <div className="w-9 h-9 rounded-lg border border-slate-300 dark:border-white/20 bg-white dark:bg-slate-900 flex items-center justify-center font-mono text-sm font-black">
                          {orb.hasUp && (
                            <span className="text-emerald-600 dark:text-emerald-400">↑</span>
                          )}
                          {orb.hasDown && (
                            <span className="text-rose-600 dark:text-rose-400">↓</span>
                          )}
                        </div>
                        <span className="font-mono text-[10px] text-slate-500">
                          {orb.ml > 0 ? `+${orb.ml}` : orb.ml}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 4 Quantum Numbers of Last Electron */}
        <div className="lg:col-span-4 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
          <div className="flex items-center gap-2 font-extrabold text-base text-slate-900 dark:text-white">
            <Atom className="w-5 h-5 theme-text" />
            <span>أعداد الكم الأربعة للإلكترون الأخير</span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            يقع آخر إلكترون مضاف في المستوى الفرعي{' '}
            <strong className="formula-ltr theme-text">{report.lastElectronQuantum.subshellLabel}</strong>
          </p>

          <div className="grid grid-cols-2 gap-3">
            {[
              { sym: 'n', label: 'الرئيسي', val: String(report.lastElectronQuantum.n) },
              { sym: 'l', label: 'الثانوي', val: String(report.lastElectronQuantum.l) },
              {
                sym: 'mₗ',
                label: 'المغناطيسي',
                val:
                  report.lastElectronQuantum.ml > 0
                    ? `+${report.lastElectronQuantum.ml}`
                    : String(report.lastElectronQuantum.ml),
              },
              { sym: 'mₛ', label: 'المغزلي', val: report.lastElectronQuantum.ms },
            ].map((q) => (
              <div
                key={q.sym}
                className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-950/60 border border-slate-200/80 dark:border-white/10 text-center space-y-1"
              >
                <div className="text-[11px] font-bold text-slate-500">
                  {q.label} (<span className="formula-ltr">{q.sym}</span>)
                </div>
                <div className="formula-ltr text-2xl font-black theme-text tabular-nums">
                  {q.val}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// LAB 6: OXIDES TEST-TUBE LAB & OXIDATION STATE / REDOX TRAINER (LESSONS 13-14)
// ============================================================================
export function OxidesRedoxLab({ onNotify }: Grade2LabProps) {
  const [subTab, setSubTab] = useState<'oxides' | 'oxidation'>('oxides');

  // Oxides state
  const [oxideId, setOxideId] = useState(OXIDE_SAMPLES[2].id); // Start with Al2O3 amphoteric
  const [reagent, setReagent] = useState<ReagentId>('NaOH');
  const testResult = useMemo(() => testOxideWithReagent(oxideId, reagent), [oxideId, reagent]);

  // Oxidation trainer state
  const [challengeIdx, setChallengeIdx] = useState(0);
  const [pickedOption, setPickedOption] = useState<string | null>(null);
  const challenge = OXIDATION_CHALLENGES[challengeIdx];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 w-fit">
        <button
          type="button"
          onClick={() => setSubTab('oxides')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 cursor-pointer ${
            subTab === 'oxides'
              ? 'theme-grad-btn text-white'
              : 'text-slate-700 dark:text-slate-300'
          }`}
        >
          <FlaskConical className="w-4 h-4" />
          <span>مختبر الأكاسيد وأنابيب الاختبار (الدرس 13)</span>
        </button>
        <button
          type="button"
          onClick={() => setSubTab('oxidation')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 cursor-pointer ${
            subTab === 'oxidation'
              ? 'theme-grad-btn text-white'
              : 'text-slate-700 dark:text-slate-300'
          }`}
        >
          <Zap className="w-4 h-4" />
          <span>مدرب أعداد التأكسد والأكسدة والاختزال (الدرس 14)</span>
        </button>
      </div>

      {/* Sub-tab A: Oxides Test-Tube Lab */}
      {subTab === 'oxides' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] flex flex-col items-center justify-center gap-4">
            <svg viewBox="0 0 220 230" className="w-48 h-52">
              {/* Test Tube */}
              <path
                d="M78 24 L134 24 L134 168 A28 28 0 0 1 78 168 Z"
                fill="rgba(148,163,184,0.1)"
                stroke="currentColor"
                strokeOpacity="0.45"
                strokeWidth="2.5"
              />
              {/* Liquid */}
              <path
                d="M81 92 L131 92 L131 168 A25 25 0 0 1 81 168 Z"
                fill={testResult.solutionHex}
                style={{ transition: 'fill 300ms ease' }}
              />
              {/* Solid powder if no reaction */}
              {!testResult.reacts && (
                <ellipse cx="106" cy="182" rx="18" ry="8" fill={testResult.oxide.powderColor} />
              )}
              {/* Litmus Paper Strip */}
              <rect
                x="152"
                y="46"
                width="16"
                height="96"
                rx="4"
                fill={testResult.litmusHex}
                stroke="#ffffff"
                strokeWidth="1.5"
                style={{ transition: 'fill 300ms ease' }}
              />
              <text x="160" y="158" textAnchor="middle" fill="currentColor" fontSize="9" fontWeight="700">
                عباد الشمس
              </text>
            </svg>

            <div className="text-center space-y-1">
              <div className="text-xs font-extrabold theme-text">
                أكسيد {testResult.oxide.kind} · {testResult.oxide.formula} ({testResult.oxide.nameAr})
              </div>
              <div className="text-xs font-bold text-slate-600 dark:text-slate-300">
                {testResult.litmusLabelAr}
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            <div className="space-y-2">
              <div className="text-xs font-extrabold text-slate-600 dark:text-slate-300">
                1. اختر الأكسيد الكيميائي للاختبار:
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {OXIDE_SAMPLES.map((ox) => (
                  <button
                    key={ox.id}
                    type="button"
                    onClick={() => setOxideId(ox.id)}
                    className={`p-2.5 rounded-xl border text-right transition cursor-pointer ${
                      oxideId === ox.id
                        ? 'theme-border theme-bg-soft'
                        : 'border-slate-200 dark:border-white/15'
                    }`}
                  >
                    <div className="formula-ltr text-sm font-black text-right">{ox.formula}</div>
                    <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                      {ox.kind}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-extrabold text-slate-600 dark:text-slate-300">
                2. اختر الكاشف المضاف إلى أنبوبة الاختبار:
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {(
                  [
                    { id: 'H2O', label: 'ماء مقطر (H₂O)' },
                    { id: 'HCl', label: 'حمض (HCl)' },
                    { id: 'NaOH', label: 'قلوي (NaOH)' },
                  ] as Array<{ id: ReagentId; label: string }>
                ).map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      setReagent(r.id);
                      onNotify(`تمت إضافة ${r.label} إلى ${testResult.oxide.formula}`);
                    }}
                    className={`py-2.5 px-3 rounded-xl border text-xs sm:text-sm font-extrabold transition cursor-pointer ${
                      reagent === r.id
                        ? 'theme-grad-btn text-white border-transparent'
                        : 'border-slate-200 dark:border-white/15'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950/70 border border-slate-200 dark:border-white/10 space-y-2">
              <div className="flex items-center justify-between text-xs font-extrabold">
                <span className="text-slate-500">المعادلة الموزونة:</span>
                <span
                  className={
                    testResult.reacts
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-slate-500'
                  }
                >
                  {testResult.reacts ? 'يحدث تفاعل كيميائي ✓' : 'لا يحدث تفاعل'}
                </span>
              </div>
              <code className="formula-ltr block text-sm sm:text-base font-black text-slate-900 dark:text-cyan-300">
                {testResult.equation}
              </code>
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {testResult.observationAr}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab B: Oxidation State & Redox Trainer */}
      {subTab === 'oxidation' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 p-4 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-2">
            <div className="text-xs font-extrabold text-slate-500 px-1 pb-1">
              المركبات القياسية والشاذة بالمنهج ({OXIDATION_CHALLENGES.length}):
            </div>
            {OXIDATION_CHALLENGES.map((item, idx) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setChallengeIdx(idx);
                  setPickedOption(null);
                }}
                className={`w-full p-3 rounded-xl border text-right flex items-center justify-between gap-2 transition cursor-pointer ${
                  idx === challengeIdx
                    ? 'theme-border theme-bg-soft'
                    : 'border-slate-200/80 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/5'
                }`}
              >
                <div>
                  <div className="formula-ltr text-sm font-black text-right">{item.formula}</div>
                  <div className="text-[11px] font-bold text-slate-500">{item.nameAr}</div>
                </div>
                {item.isAnomaly && (
                  <span className="text-[10px] font-extrabold text-amber-600 dark:text-amber-400">
                    شاذ
                  </span>
                )}
              </button>
            ))}
          </div>

          <div className="lg:col-span-8 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 theme-text" />
                <span className="formula-ltr text-2xl font-black theme-text">{challenge.formula}</span>
                <span className="text-sm font-bold text-slate-500">({challenge.nameAr})</span>
              </div>
              <span className="text-xs font-bold text-slate-500">
                العنصر المستهدف: <strong className="formula-ltr theme-text">{challenge.targetElement}</strong>
              </span>
            </div>

            <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
              {challenge.promptAr}
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {challenge.options.map((opt) => {
                const answered = pickedOption !== null;
                const isRight = opt === challenge.correctOption;
                const isPicked = pickedOption === opt;
                let cls =
                  'border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:theme-border';
                if (answered && isRight) {
                  cls = 'border-emerald-500 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300';
                } else if (answered && isPicked && !isRight) {
                  cls = 'border-rose-500 bg-rose-500/15 text-rose-700 dark:text-rose-300';
                }
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setPickedOption(opt)}
                    className={`p-3.5 rounded-xl border formula-ltr text-base font-black flex items-center justify-center gap-2 transition cursor-pointer ${cls}`}
                  >
                    <span>{opt}</span>
                    {answered && isRight && <CheckCircle2 className="w-4 h-4 shrink-0" />}
                    {answered && isPicked && !isRight && <XCircle className="w-4 h-4 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {pickedOption !== null && (
              <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950/70 border border-slate-200 dark:border-white/10 space-y-2 text-xs sm:text-sm">
                <div className="font-extrabold theme-text flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>طريقة الحساب والتفسير العلمي:</span>
                </div>
                <div className="font-bold text-slate-800 dark:text-slate-100">{challenge.stepsAr}</div>
                <div className="text-slate-600 dark:text-slate-300 pt-1 border-t border-slate-200 dark:border-white/10">
                  <strong>السلوك في الأكسدة والاختزال:</strong> {challenge.redoxRoleAr}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
