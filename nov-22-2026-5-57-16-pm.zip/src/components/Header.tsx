import { Bot, BrainCircuit, Moon, Search, Sun } from 'lucide-react';
import type { ACADEMY_DATA } from '../data/academyData';
import {
  NAV_ITEMS,
  type AcademyViewId,
  type PaletteId,
} from '../utils/academyState';
import type { SiteSettings } from '../utils/siteSettings';
import { SiteSettingsMenu } from './SiteSettingsMenu';

interface HeaderProps {
  brand: (typeof ACADEMY_DATA)['brand'];
  activeView: AcademyViewId;
  settings: SiteSettings;
  settingsOpen: boolean;
  completedLessonsCount: number;
  totalLessonsCount: number;
  unresolvedMistakesCount: number;
  savedCertificatesCount: number;
  onSwitchView: (view: AcademyViewId) => void;
  onSelectPalette: (palette: PaletteId) => void;
  onToggleTheme: () => void;
  onToggleSettings: () => void;
  onCloseSettings: () => void;
  onUpdateSettings: (patch: Partial<SiteSettings>) => void;
  onResetSettings: () => void;
  onReopenSplash: () => void;
  onOpenCommand: () => void;
}

export function Header({
  brand,
  activeView,
  settings,
  settingsOpen,
  completedLessonsCount,
  totalLessonsCount,
  unresolvedMistakesCount,
  savedCertificatesCount,
  onSwitchView,
  onSelectPalette,
  onToggleTheme,
  onToggleSettings,
  onCloseSettings,
  onUpdateSettings,
  onResetSettings,
  onReopenSplash,
  onOpenCommand,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 dark:border-white/10 glass-panel transition-colors">
      <div className="academy-container mx-auto px-3 sm:px-6 lg:px-8 h-14 lg:h-16 flex items-center justify-between gap-2 sm:gap-3 font-bold text-[22px]">
        <button
          type="button"
          onClick={() => onSwitchView('home')}
          className="flex items-center gap-2.5 text-right shrink-0 cursor-pointer group min-w-0"
        >
          <div className="w-9 h-9 lg:w-10 lg:h-10 rounded-xl bg-black border border-cyan-400/45 shadow-[0_0_16px_rgba(6,182,212,0.28)] overflow-hidden flex items-center justify-center transition-transform duration-300 group-hover:scale-105 group-hover:border-cyan-300 shrink-0">
            <img
              src={brand.logoUrl}
              alt={`شعار ${brand.name}`}
              className="w-full h-full object-contain p-0.5"
            />
          </div>
          <div className="hidden sm:block">
            <div className="font-extrabold text-sm lg:text-[15px] whitespace-nowrap text-slate-900 dark:text-slate-100 leading-tight">
              {brand.name}
            </div>
            <div className="hidden 2xl:block text-[11px] text-slate-500 dark:text-slate-400 whitespace-nowrap">
              {brand.credits}
            </div>
          </div>
          <div className="sm:hidden font-extrabold text-xs whitespace-nowrap text-slate-900 dark:text-slate-100">
            {brand.name}
          </div>
        </button>

        {/* أزرار التنقل الرئيسية (كمبيوتر) */}
        <nav
          aria-label="التنقل الرئيسي"
          className="hidden lg:flex items-center gap-0.5 xl:gap-1 overflow-x-auto custom-scrollbar"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeView === item.id;
            const showMistakeBadge = item.id === 'mistakes' && unresolvedMistakesCount > 0;
            const isMasteryTab = item.id === 'mastery';
            const isAssistantTab = item.id === 'assistant';
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSwitchView(item.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`nav-btn relative px-2 xl:px-2.5 py-1.5 xl:py-2 rounded-xl text-[11px] xl:text-xs font-bold whitespace-nowrap shrink-0 inline-flex items-center gap-1 transition-colors cursor-pointer ${
                  isActive
                    ? 'theme-bg-soft theme-text'
                    : isAssistantTab
                      ? 'border border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/20'
                      : isMasteryTab
                        ? 'text-slate-700 dark:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-white/10 theme-border/40'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-white/10 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {isMasteryTab && <BrainCircuit className="w-3.5 h-3.5 theme-text shrink-0" />}
                {isAssistantTab && <Bot className="w-3.5 h-3.5 text-emerald-500 shrink-0" />}
                <span>{item.label}</span>
                {showMistakeBadge && (
                  <span
                    aria-label={`${unresolvedMistakesCount} أخطاء قيد المراجعة`}
                    className="px-1.5 py-0.5 rounded-md bg-rose-500 text-white text-[10px] font-black leading-none tabular-nums"
                  >
                    {unresolvedMistakesCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* أدوات الشريط العلوي: البحث السريع + زر التنسيق والإعداد + زر الوضع الداكن */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenCommand}
            aria-label="فتح البحث السريع"
            title="البحث السريع (Ctrl+K)"
            className="min-h-[40px] min-w-[40px] sm:min-h-[38px] sm:min-w-0 inline-flex items-center justify-center gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-100/80 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200/80 dark:hover:bg-white/10 text-xs font-bold transition-colors cursor-pointer"
          >
            <Search className="w-4 h-4 sm:w-3.5 sm:h-3.5" />
            <span className="hidden 2xl:inline whitespace-nowrap">بحث سريع</span>
            <kbd className="hidden 2xl:inline font-mono text-[10px] opacity-70">Ctrl+K</kbd>
          </button>

          {/* زر صغير موحّد للتحكم في إعداد وتنسيق الموقع بجوار زر الوضع الداكن مباشرة */}
          <SiteSettingsMenu
            open={settingsOpen}
            settings={settings}
            completedLessonsCount={completedLessonsCount}
            totalLessonsCount={totalLessonsCount}
            unresolvedMistakesCount={unresolvedMistakesCount}
            savedCertificatesCount={savedCertificatesCount}
            onToggleOpen={onToggleSettings}
            onClose={onCloseSettings}
            onUpdateSettings={onUpdateSettings}
            onSelectPalette={onSelectPalette}
            onResetSettings={onResetSettings}
            onReopenSplash={onReopenSplash}
          />

          <button
            type="button"
            onClick={onToggleTheme}
            className="min-h-[40px] min-w-[40px] sm:min-h-[38px] sm:min-w-[38px] p-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-100/80 dark:bg-white/5 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors flex items-center justify-center cursor-pointer"
            title={settings.isDark ? 'التبديل إلى الوضع النهاري' : 'التبديل إلى الوضع الداكن'}
            aria-label="تبديل الوضع"
          >
            {settings.isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
}
