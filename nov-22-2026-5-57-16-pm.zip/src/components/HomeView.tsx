import { useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  Atom,
  BookMarked,
  BookOpen,
  BrainCircuit,
  ChevronDown,
  ClipboardCheck,
  ExternalLink,
  FlaskConical,
  Layers,
  MessageCircle,
  MessageSquare,
  Phone,
  PhoneCall,
  Scale,
  Users,
} from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import {
  ACADEMY_DATA,
  CURRICULUM_UNIT_META,
  HERO_LAB_IMAGE,
} from '../data/academyData';
import { PERIODIC_ELEMENTS } from '../data/periodicTableData';
import type { AcademyViewId, PaletteId } from '../utils/academyState';
import type { LabToolTab } from './LabView';
import { BohrAtomVisual } from './BohrAtomVisual';
import { HeroParticles } from './HeroParticles';
import { HomeCreditsShowcase } from './HomeCreditsShowcase';
import { InteractiveTiltCard } from './InteractiveTiltCard';

interface HomeViewProps {
  active: boolean;
  palette: PaletteId;
  completedLessonsCount: number;
  masteredCardsCount: number;
  bestQuizScore: number | null;
  onSwitchView: (view: AcademyViewId) => void;
  onJumpToLesson: (lessonId: string) => void;
  onOpenLabTool: (tool: LabToolTab, elementSymbol?: string) => void;
  onNotify: (text: string, tone?: 'success' | 'info') => void;
}

interface HeroAtomPreset {
  symbol: string;
  nameAr: string;
  atomicNumber: number;
  config: string;
  shells: number[];
  note: string;
}

const HERO_ATOM_PRESETS: HeroAtomPreset[] = [
  {
    symbol: 'Cr',
    nameAr: 'الكروم',
    atomicNumber: 24,
    config: '[Ar] 4s¹ 3d⁵',
    shells: [2, 8, 13, 1],
    note: 'شذوذ التوزيع نصف الممتلئ (الدرس 08)',
  },
  {
    symbol: 'Cu',
    nameAr: 'النحاس',
    atomicNumber: 29,
    config: '[Ar] 4s¹ 3d¹⁰',
    shells: [2, 8, 18, 1],
    note: 'امتلاء تام لمستوى 3d (الدرس 08)',
  },
  {
    symbol: 'Fe',
    nameAr: 'الحديد',
    atomicNumber: 26,
    config: '[Ar] 4s² 3d⁶',
    shells: [2, 8, 14, 2],
    note: 'تطبيق قاعدة هوند ومبدأ أوفباو',
  },
  {
    symbol: 'C',
    nameAr: 'الكربون',
    atomicNumber: 6,
    config: '1s² 2s² 2p²',
    shells: [2, 4],
    note: 'أساس حساب الصيغ الأولية والكتلة المولية',
  },
];

export function HomeView({
  active,
  palette,
  completedLessonsCount,
  masteredCardsCount,
  bestQuizScore,
  onSwitchView,
  onJumpToLesson,
  onOpenLabTool,
  onNotify,
}: HomeViewProps) {
  const prefersReducedMotion = useReducedMotion();
  const [heroAtomIndex, setHeroAtomIndex] = useState(0);
  const [unitsTabOpen, setUnitsTabOpen] = useState(false);
  const [creditsTabOpen, setCreditsTabOpen] = useState(false);

  const { home, brand, lessons, studio, quiz } = ACADEMY_DATA;
  const totalLessons = lessons.items.length;
  const progressPct = Math.round((completedLessonsCount / Math.max(1, totalLessons)) * 100);
  const currentAtom = HERO_ATOM_PRESETS[heroAtomIndex];

  const handleScrollToCredits = () => {
    setCreditsTabOpen(true);
    window.setTimeout(() => {
      const el = document.getElementById('home-credits-bottom-tab');
      if (el) {
        el.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth', block: 'start' });
      }
    }, 80);
  };

  const unitSpotlights = CURRICULUM_UNIT_META.map((u) => ({
    id: u.id,
    lessonId: u.firstLessonId,
    kicker: u.kicker,
    title: u.title,
    summary: u.summary,
    image: u.image,
    alt: u.alt,
  }));

  const quickTools = [
    {
      title: 'منهج الـ 14 وأطلس المعادلات',
      desc: 'الشرح الكامل للـ 14 درساً مع 18 معادلة موزونة و6 ثوابت و21 كتلة ذرية قياسية',
      icon: BookOpen,
      onClick: () => onSwitchView('syllabus'),
    },
    {
      title: '6 مختبرات افتراضية للصف الثاني',
      desc: 'المادة المحددة والتخفيف، رذرفورد، طيف بور (656–410 nm)، الأوربيتالات، والأكاسيد',
      icon: FlaskConical,
      onClick: () => onOpenLabTool('experiments'),
    },
    {
      title: 'الجدول الدوري والخريطة الحرارية',
      desc: `${PERIODIC_ELEMENTS.length} عنصراً منهجياً مع تدرج نصف القطر وجهد التأين والميل والسالبية والشواذ`,
      icon: Atom,
      onClick: () => onOpenLabTool('periodic'),
    },
    {
      title: 'موازن المعادلات الكيميائية',
      desc: 'تدريب تفاعلي بميزان ذري فوري للمتفاعلات والنواتج مع التحقق المباشر',
      icon: Scale,
      onClick: () => onOpenLabTool('balancer'),
    },
    {
      title: 'الكتاب المفتوح وأهم 93 نقطة',
      desc: '14 ورقة مفاهيم وقوانين + 93 نقطة مراجعة نهائية + محولات وحدات بالأرقام الإنجليزية',
      icon: BookMarked,
      onClick: () => onSwitchView('openbook'),
    },
    {
      title: 'استوديو الـ 70 بطاقة وبومودورو',
      desc: '5 بطاقات مراجعة لكل درس من الدروس الـ 14 مع تقليب ثلاثي الأبعاد وتتبع الإتقان',
      icon: Layers,
      onClick: () => onSwitchView('studio'),
    },
    {
      title: 'مُعلّم الفهم ومُحلّل المسائل',
      desc: 'خريطة ترابط الدروس + حل مسائل المول والتخفيف وأعداد الكم والأكسدة خطوة بخطوة',
      icon: BrainCircuit,
      onClick: () => onSwitchView('mastery'),
    },
    {
      title: 'بنك 1,560 سؤالاً والشهادات',
      desc: 'اختيار من متعدد ومقالي ومتفوقين + اختبار تكيّفي + ورقة طباعة + شهادة تقدير معتمدة',
      icon: ClipboardCheck,
      onClick: () => onSwitchView('quiz'),
    },
  ];

  return (
    <section id="view-home" className={`app-view ${active ? 'view-reveal' : 'hidden'}`}>
      {/* Hero Banner */}
      <div className="relative overflow-hidden bg-[#040714] text-slate-100">
        <img
          src={HERO_LAB_IMAGE}
          alt=""
          aria-hidden="true"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-35"
        />
        <HeroParticles palette={palette} active={active} />
        <div className="absolute inset-0 bg-gradient-to-t from-[#040714] via-[#040714]/82 to-[#040714]/55" />

        <div className="relative academy-container mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12 lg:py-16 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          {/* Primary Hero Copy & Interactive CTAs */}
          <motion.div
            initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 space-y-5"
          >
            <p className="text-xs sm:text-sm font-bold theme-text tracking-wide">
              {home.badge}
            </p>
            <h1 className="text-3xl sm:text-5xl lg:text-[3.35rem] font-black leading-[1.18] aurora-text max-w-2xl">
              {home.title}
            </h1>
            <p className="text-slate-300 text-base sm:text-lg leading-relaxed max-w-2xl">
              {home.description}
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <motion.button
                type="button"
                onClick={() => onSwitchView('lessons')}
                whileHover={prefersReducedMotion ? undefined : { y: -3, scale: 1.02 }}
                whileTap={prefersReducedMotion ? undefined : { scale: 0.98 }}
                transition={{ type: 'spring', stiffness: 380, damping: 24 }}
                className="theme-grad-btn px-6 py-3 rounded-2xl text-white font-bold inline-flex items-center gap-2 cursor-pointer"
              >
                <BookOpen className="w-4 h-4" />
                <span>{home.primaryCta}</span>
              </motion.button>
              <motion.button
                type="button"
                onClick={() => onSwitchView('lab')}
                whileHover={prefersReducedMotion ? undefined : { y: -3, scale: 1.02 }}
                whileTap={prefersReducedMotion ? undefined : { scale: 0.98 }}
                transition={{ type: 'spring', stiffness: 380, damping: 24 }}
                className="px-6 py-3 rounded-2xl border border-white/20 bg-white/5 text-slate-100 font-bold hover:bg-white/12 hover:border-white/35 transition inline-flex items-center gap-2 cursor-pointer"
              >
                <FlaskConical className="w-4 h-4 theme-text" />
                <span>{home.secondaryCta}</span>
              </motion.button>
              <motion.button
                type="button"
                onClick={() => onSwitchView('quiz')}
                whileHover={prefersReducedMotion ? undefined : { y: -3, scale: 1.02 }}
                whileTap={prefersReducedMotion ? undefined : { scale: 0.98 }}
                transition={{ type: 'spring', stiffness: 380, damping: 24 }}
                className="px-5 py-3 rounded-2xl border border-white/15 bg-transparent text-slate-300 font-bold hover:bg-white/8 hover:text-white transition inline-flex items-center gap-2 cursor-pointer"
              >
                <ClipboardCheck className="w-4 h-4" />
                <span>مركز الاختبارات</span>
              </motion.button>
            </div>
          </motion.div>

          {/* Interactive Bento Dashboard, Live Bohr Switcher & Above-the-Fold Credits */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-3.5">
            {/* Interactive Bohr Atom Switcher Card */}
            <InteractiveTiltCard
              enableEntrance={false}
              maxTilt={3.5}
              glowStrength={0.28}
              className="glass-panel p-5 rounded-2xl border border-white/12 bg-white/[0.06] col-span-2"
            >
              <div className="relative z-20 flex items-center justify-between gap-4">
                <div className="space-y-2 flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {HERO_ATOM_PRESETS.map((preset, idx) => {
                      const isSelected = idx === heroAtomIndex;
                      return (
                        <button
                          key={preset.symbol}
                          type="button"
                          onClick={() => setHeroAtomIndex(idx)}
                          aria-pressed={isSelected}
                          className={`formula-ltr px-2.5 py-1 rounded-lg text-[11px] font-extrabold transition cursor-pointer ${
                            isSelected
                              ? 'theme-grad-btn text-white'
                              : 'border border-white/15 bg-white/5 text-slate-300 hover:bg-white/12 hover:text-white'
                          }`}
                        >
                          {preset.symbol}
                        </button>
                      );
                    })}
                  </div>

                  <AnimatePresence mode="wait">
                    <motion.div
                      key={currentAtom.symbol}
                      initial={prefersReducedMotion ? false : { opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={prefersReducedMotion ? undefined : { opacity: 0, y: -6 }}
                      transition={{ duration: 0.22 }}
                      className="space-y-1"
                    >
                      <div className="text-xs font-bold text-slate-400">
                        ذرة {currentAtom.nameAr} التفاعلية · {currentAtom.atomicNumber}
                        {currentAtom.symbol}
                      </div>
                      <div className="font-extrabold text-base text-white">
                        {currentAtom.note}
                      </div>
                      <div className="formula-ltr text-xs font-bold theme-text text-right">
                        {currentAtom.config} · {currentAtom.shells.join(', ')}
                      </div>
                    </motion.div>
                  </AnimatePresence>

                  <button
                    type="button"
                    onClick={() => onOpenLabTool('periodic', currentAtom.symbol)}
                    className="pt-1 inline-flex items-center gap-1.5 text-xs font-bold text-slate-200 hover:theme-text transition cursor-pointer group"
                  >
                    <span>استكشف في الجدول الدوري</span>
                    <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:-translate-x-1" />
                  </button>
                </div>

                <div className="shrink-0 text-slate-200">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={currentAtom.symbol}
                      initial={prefersReducedMotion ? false : { opacity: 0, scale: 0.88, rotate: -10 }}
                      animate={{ opacity: 1, scale: 1, rotate: 0 }}
                      exit={prefersReducedMotion ? undefined : { opacity: 0, scale: 0.88, rotate: 10 }}
                      transition={{ type: 'spring', stiffness: 280, damping: 22 }}
                    >
                      <BohrAtomVisual
                        symbol={currentAtom.symbol}
                        atomicNumber={currentAtom.atomicNumber}
                        shells={currentAtom.shells}
                        size={126}
                      />
                    </motion.div>
                  </AnimatePresence>
                </div>
              </div>
            </InteractiveTiltCard>

            {/* Progress KPI Card */}
            <InteractiveTiltCard
              enableEntrance={false}
              maxTilt={5}
              glowStrength={0.25}
              className="glass-panel p-4 sm:p-5 rounded-2xl border border-white/12 bg-white/[0.06]"
            >
              <div className="relative z-20">
                <div className="text-xs font-bold text-slate-400">{home.lessonsCountLabel}</div>
                <div className="text-2xl font-black theme-text mt-1 tabular-nums">
                  {completedLessonsCount} / {totalLessons}
                </div>
                <div className="mt-2 h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <motion.div
                    initial={prefersReducedMotion ? false : { scaleX: 0 }}
                    animate={{ scaleX: Math.max(0.04, progressPct / 100) }}
                    transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                    style={{ transformOrigin: 'right center' }}
                    className="h-full w-full rounded-full theme-grad-btn"
                  />
                </div>
              </div>
            </InteractiveTiltCard>

            {/* Quiz Bank KPI Card */}
            <InteractiveTiltCard
              enableEntrance={false}
              maxTilt={5}
              glowStrength={0.25}
              className="glass-panel p-4 sm:p-5 rounded-2xl border border-white/12 bg-white/[0.06]"
            >
              <div className="relative z-20">
                <div className="text-xs font-bold text-slate-400">{home.questionsCountLabel}</div>
                <div className="text-2xl font-black theme-text mt-1 tabular-nums">
                  {quiz.questions.length + quiz.essayQuestions.length} سؤال
                </div>
                <div className="text-xs text-slate-400 mt-1 tabular-nums">
                  {bestQuizScore !== null
                    ? `أعلى نتيجة: ${bestQuizScore}%`
                    : `البطاقات: ${masteredCardsCount}/${studio.flashcards.length}`}
                </div>
              </div>
            </InteractiveTiltCard>

            {/* Above-the-Fold Interactive Preparation & Design Signature Panel */}
            <InteractiveTiltCard
              enableEntrance={false}
              maxTilt={3}
              glowStrength={0.24}
              className="glass-panel p-4 rounded-2xl border border-white/14 bg-white/[0.05] col-span-2"
            >
              <div className="relative z-20 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-extrabold text-slate-200">
                    {home.creditsCardTitle} والتواصل
                  </span>
                  <button
                    type="button"
                    onClick={handleScrollToCredits}
                    className="inline-flex items-center gap-1 text-[11px] font-bold theme-text hover:underline cursor-pointer"
                  >
                    <span>بطاقة الفريق</span>
                    <ArrowDown className="w-3 h-3" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {brand.creators.map((creator) => {
                    const whatsappHref = `https://wa.me/2${creator.phone.replace(/\D/g, '')}`;
                    return (
                      <div
                        key={creator.id}
                        className="rounded-xl border border-white/10 bg-slate-950/45 px-3 py-2.5 flex items-center justify-between gap-2 hover:border-white/25 transition"
                      >
                        <div className="min-w-0">
                          <div className="text-[10px] font-bold theme-text">
                            {creator.id === 'author' ? 'إعداد علمي' : 'تصميم وتطوير'}
                          </div>
                          <div className="text-xs font-extrabold text-white truncate">
                            {creator.name}
                          </div>
                          <a
                            href={creator.telHref}
                            className="formula-ltr inline-flex items-center gap-1 text-[11px] font-bold text-slate-300 hover:text-white transition mt-0.5"
                          >
                            <Phone className="w-3 h-3 theme-text shrink-0" />
                            <span>{creator.phone}</span>
                          </a>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <a
                            href={creator.telHref}
                            aria-label={`اتصال مباشر بـ ${creator.name}`}
                            title={`اتصال مباشر بـ ${creator.name}`}
                            className="w-8 h-8 rounded-lg theme-grad-btn text-white flex items-center justify-center hover:brightness-110 hover:scale-105 active:scale-95 transition-all cursor-pointer"
                          >
                            <PhoneCall className="w-3.5 h-3.5" />
                          </a>
                          <a
                            href={whatsappHref}
                            target="_blank"
                            rel="noopener noreferrer"
                            aria-label={`مراسلة ${creator.name} عبر واتساب`}
                            title={`مراسلة ${creator.name} عبر واتساب`}
                            className="w-8 h-8 rounded-lg border border-emerald-400/35 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 hover:text-emerald-200 flex items-center justify-center hover:scale-105 active:scale-95 transition-all cursor-pointer"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </InteractiveTiltCard>
          </div>
        </div>
      </div>

      {/* Main Interactive Home Content */}
      <div className="academy-container mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12 space-y-12 sm:space-y-14">
        {/* Interactive Scientific Tools Grid */}
        <div className="space-y-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-black aurora-text">
                أدوات الأكاديمية التفاعلية
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                أدوات علمية حقيقية جاهزة للاستخدام المباشر أثناء المذاكرة والمراجعة
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-5">
            {quickTools.map((tool, idx) => {
              const Icon = tool.icon;
              return (
                <InteractiveTiltCard
                  key={tool.title}
                  delay={idx * 0.05}
                  maxTilt={4.5}
                  glowStrength={0.22}
                  className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] hover:border-[var(--p-primary)]/45 shadow-sm dark:shadow-none transition-colors group"
                >
                  <button
                    type="button"
                    onClick={tool.onClick}
                    className="relative z-20 w-full h-full text-right p-6 flex flex-col justify-between gap-4 cursor-pointer"
                  >
                    <div className="space-y-3">
                      <div className="w-11 h-11 rounded-xl theme-bg-soft flex items-center justify-center transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6">
                        <Icon className="w-5 h-5 theme-text" />
                      </div>
                      <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100">
                        {tool.title}
                      </h3>
                      <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                        {tool.desc}
                      </p>
                    </div>
                    <div className="inline-flex items-center gap-1.5 text-xs font-bold theme-text">
                      <span>افتح الأداة</span>
                      <ArrowLeft className="w-3.5 h-3.5 transition-transform duration-300 group-hover:-translate-x-1.5" />
                    </div>
                  </button>
                </InteractiveTiltCard>
              );
            })}
          </div>
        </div>

        {/* Collapsible Visual Curriculum Units Tab */}
        <div
          id="home-units-tab"
          className="scroll-mt-24 rounded-3xl border border-slate-200 dark:border-white/12 bg-white/90 dark:bg-white/[0.03] shadow-sm dark:shadow-none overflow-hidden transition-colors"
        >
          <button
            type="button"
            onClick={() => setUnitsTabOpen((prev) => !prev)}
            aria-expanded={unitsTabOpen}
            aria-controls="home-units-panel"
            className="group w-full px-5 py-4 sm:px-6 sm:py-5 hover:bg-slate-50/80 dark:hover:bg-white/[0.04] transition-colors flex flex-wrap sm:flex-nowrap items-center justify-between gap-4 text-right cursor-pointer"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-11 h-11 rounded-2xl theme-bg-soft flex items-center justify-center shrink-0 transition-transform duration-300 group-hover:scale-105">
                <Layers className="w-5 h-5 theme-text" />
              </div>
              <div className="min-w-0">
                <h2 className="text-lg sm:text-xl font-black aurora-text leading-snug">
                  الأبواب الدراسية المصوّرة
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
                  اختر أي باب للانتقال مباشرة إلى الشرح التفصيلي والمعادلات والتدريب السريع
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0 mr-auto sm:mr-0">
              <span className="hidden md:inline-block text-xs font-bold text-slate-500 dark:text-slate-400 tabular-nums">
                {unitSpotlights.length} أبواب · {totalLessons} درساً
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/12 bg-slate-50 dark:bg-white/[0.05] px-3 py-1.5 text-xs font-bold theme-text">
                <span>{unitsTabOpen ? 'إخفاء الأبواب' : 'عرض الأبواب'}</span>
                <ChevronDown
                  className={`w-4 h-4 transition-transform duration-300 ${
                    unitsTabOpen ? 'rotate-180' : ''
                  }`}
                />
              </span>
            </div>
          </button>

          <AnimatePresence initial={false}>
            {unitsTabOpen && (
              <motion.div
                id="home-units-panel"
                initial={prefersReducedMotion ? false : { opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={prefersReducedMotion ? undefined : { opacity: 0, height: 0 }}
                transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
                className="overflow-hidden border-t border-slate-200/80 dark:border-white/10"
              >
                <div className="p-5 sm:p-6 space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs sm:text-sm font-bold text-slate-600 dark:text-slate-400">
                      تصفّح أبواب الفصل الدراسي الأول وانتقل مباشرة لبداية كل باب
                    </div>
                    <motion.button
                      type="button"
                      onClick={() => onSwitchView('lessons')}
                      whileHover={prefersReducedMotion ? undefined : { x: -3 }}
                      className="inline-flex items-center gap-1.5 text-sm font-bold theme-text hover:underline cursor-pointer"
                    >
                      <span>عرض جميع الدروس ({totalLessons})</span>
                      <ArrowLeft className="w-4 h-4" />
                    </motion.button>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {unitSpotlights.map((unit) => (
                      <InteractiveTiltCard
                        key={unit.id}
                        enableEntrance={false}
                        maxTilt={4}
                        glowStrength={0.2}
                        className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] hover:border-[var(--p-primary)]/45 shadow-sm dark:shadow-none transition-colors group"
                      >
                        <button
                          type="button"
                          onClick={() => onJumpToLesson(unit.lessonId)}
                          className="relative z-20 w-full h-full text-right flex flex-col cursor-pointer"
                        >
                          <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-900">
                            <img
                              src={unit.image}
                              alt={unit.alt}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-transparent to-transparent" />
                          </div>
                          <div className="p-6 flex-1 flex flex-col justify-between gap-3">
                            <div className="space-y-2">
                              <div className="text-xs font-bold theme-text">{unit.kicker}</div>
                              <h3 className="font-extrabold text-lg text-slate-900 dark:text-slate-100 leading-snug">
                                {unit.title}
                              </h3>
                              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                                {unit.summary}
                              </p>
                            </div>
                            <div className="pt-2 inline-flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 group-hover:theme-text">
                              <Layers className="w-3.5 h-3.5" />
                              <span>دخول الباب الدراسي</span>
                              <ArrowLeft className="w-3.5 h-3.5 transition-transform duration-300 group-hover:-translate-x-1.5" />
                            </div>
                          </div>
                        </button>
                      </InteractiveTiltCard>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Compact Collapsible Bottom Credits Tab */}
        <div
          id="home-credits-bottom-tab"
          className="scroll-mt-24 pt-2 border-t border-slate-200/80 dark:border-white/10"
        >
          <div className="flex justify-center">
            <button
              type="button"
              onClick={() => setCreditsTabOpen((prev) => !prev)}
              aria-expanded={creditsTabOpen}
              aria-controls="home-credits-panel"
              className="group w-full max-w-2xl rounded-2xl border border-slate-200 dark:border-white/12 bg-white/90 dark:bg-white/[0.04] hover:border-[var(--p-primary)]/45 hover:bg-white dark:hover:bg-white/[0.07] px-4 py-2.5 sm:px-5 sm:py-3 shadow-sm dark:shadow-none transition-all flex items-center justify-between gap-3 text-right cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-xl theme-bg-soft flex items-center justify-center shrink-0 transition-transform duration-300 group-hover:scale-105">
                  <Users className="w-4 h-4 theme-text" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-slate-100 truncate">
                    فريق الإعداد العلمي والتصميم التفاعلي
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    مستر صلاح عيد · محمد صلاح — الإعداد والتصميم والتواصل المباشر
                  </div>
                </div>
              </div>

              <div className="inline-flex items-center gap-1.5 text-xs font-bold theme-text shrink-0">
                <span>{creditsTabOpen ? 'إخفاء' : 'عرض التفاصيل'}</span>
                <ChevronDown
                  className={`w-4 h-4 transition-transform duration-300 ${
                    creditsTabOpen ? 'rotate-180' : ''
                  }`}
                />
              </div>
            </button>
          </div>

          <AnimatePresence initial={false}>
            {creditsTabOpen && (
              <motion.div
                id="home-credits-panel"
                initial={prefersReducedMotion ? false : { opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={prefersReducedMotion ? undefined : { opacity: 0, height: 0 }}
                transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
                className="overflow-hidden"
              >
                <div className="pt-5">
                  <HomeCreditsShowcase onNotify={onNotify} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Bottom Tab: Open Attached Smart Chemistry Assistant in a New Page */}
        <div
          id="home-smart-assistant-tab"
          className="scroll-mt-24 flex justify-center -mt-6"
        >
          <a
            href="/assets/aistudio/index_4dda41dc.html"
            target="_blank"
            rel="noopener noreferrer"
            data-testid="home-attached-assistant-tab"
            className="group w-full max-w-2xl rounded-2xl border border-slate-200 dark:border-white/12 bg-white/90 dark:bg-white/[0.04] hover:border-[var(--p-primary)]/45 hover:bg-white dark:hover:bg-white/[0.07] px-4 py-2.5 sm:px-5 sm:py-3 shadow-sm dark:shadow-none transition-all flex items-center justify-between gap-3 text-right cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--p-primary)]"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl theme-bg-soft flex items-center justify-center shrink-0 transition-transform duration-200 group-hover:scale-105">
                <MessageSquare className="w-4 h-4 theme-text" />
              </div>
              <div className="min-w-0">
                <div className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-slate-100 truncate">
                  المساعد الذكي للعلوم والكيمياء
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  الشات التفاعلي · مُفسّر الأخطاء · مُوازن المعادلات · لوحة المعلم
                </div>
              </div>
            </div>

            <div className="inline-flex items-center gap-1.5 text-xs font-bold theme-text whitespace-nowrap shrink-0">
              <span>فتح في صفحة جديدة</span>
              <ExternalLink className="w-4 h-4 transition-transform duration-200 group-hover:-translate-x-0.5 group-hover:-translate-y-0.5" />
            </div>
          </a>
        </div>
      </div>
    </section>
  );
}
