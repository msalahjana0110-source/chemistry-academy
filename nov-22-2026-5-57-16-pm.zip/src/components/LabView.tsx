import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Atom,
  Calculator,
  CheckCircle2,
  FlaskConical,
  Layers,
  Minus,
  Plus,
  RotateCcw,
  Scale,
  Search,
  Sparkles,
  Target,
  Zap,
} from 'lucide-react';
import { ACADEMY_DATA } from '../data/academyData';
import {
  ELEMENT_CATEGORY_META,
  PERIODIC_ELEMENTS,
  type ElementCategory,
  type PeriodicElement,
} from '../data/periodicTableData';
import { checkEquationBalance } from '../utils/chemistryEngine';
import { BohrAtomVisual } from './BohrAtomVisual';
import {
  BohrSpectrumLab,
  OrbitalsQuantumLab,
  OxidesRedoxLab,
  RutherfordLab,
  StoichiometryLab,
} from './Grade2LabsStage';

export type LabToolTab =
  | 'experiments'
  | 'rutherford'
  | 'bohr'
  | 'orbitals'
  | 'periodic'
  | 'oxides'
  | 'balancer'
  | 'molar';

type HeatmapMode = 'category' | 'radius' | 'ionization' | 'affinity' | 'electronegativity';

interface LabViewProps {
  active: boolean;
  activeTool: LabToolTab;
  selectedElementSymbol: string;
  onSelectTool: (tool: LabToolTab) => void;
  onSelectElementSymbol: (symbol: string) => void;
  onNotify: (msg: string) => void;
}

const LAB_TOOLS: ReadonlyArray<{
  id: Exclude<LabToolTab, 'molar'>;
  label: string;
  shortUnit: string;
  icon: typeof FlaskConical;
}> = [
  { id: 'experiments', label: '1. الحساب الكيميائي والتخفيف', shortUnit: 'الباب 1', icon: Calculator },
  { id: 'rutherford', label: '2. تجربة رذرفورد', shortUnit: 'الدرس 06', icon: Target },
  { id: 'bohr', label: '3. طيف الهيدروجين (بور)', shortUnit: 'الدرس 07', icon: Sparkles },
  { id: 'orbitals', label: '4. التوزيع وأعداد الكم', shortUnit: '08–09', icon: Layers },
  { id: 'periodic', label: '5. الجدول الدوري والخواص', shortUnit: '10–12', icon: Atom },
  { id: 'oxides', label: '6. الأكاسيد والتأكسد', shortUnit: '13–14', icon: FlaskConical },
  { id: 'balancer', label: 'موازن المعادلات', shortUnit: 'تدريب', icon: Scale },
];

function getHeatBackground(el: PeriodicElement, mode: HeatmapMode): string {
  if (mode === 'radius') {
    const t = Math.min(1, Math.max(0, (el.atomicRadiusPm - 30) / 235));
    return `rgba(14, 165, 233, ${(0.12 + t * 0.58).toFixed(2)})`;
  }
  if (mode === 'ionization') {
    const t = Math.min(1, Math.max(0, (el.firstIonizationKj - 370) / 2000));
    return `rgba(244, 63, 94, ${(0.12 + t * 0.58).toFixed(2)})`;
  }
  if (mode === 'affinity') {
    const val = el.electronAffinityKj ?? 0;
    if (val >= 0) return 'rgba(148, 163, 184, 0.16)';
    const t = Math.min(1, Math.abs(val) / 350);
    return `rgba(16, 185, 129, ${(0.15 + t * 0.6).toFixed(2)})`;
  }
  if (mode === 'electronegativity') {
    const val = el.electronegativity;
    if (val === null) return 'rgba(148, 163, 184, 0.14)';
    const t = Math.min(1, Math.max(0, (val - 0.7) / 3.3));
    return `rgba(139, 92, 246, ${(0.14 + t * 0.6).toFixed(2)})`;
  }
  return '';
}

export function LabView({
  active,
  activeTool,
  selectedElementSymbol,
  onSelectTool,
  onSelectElementSymbol,
  onNotify,
}: LabViewProps) {
  const { heading, subheading, equations } = ACADEMY_DATA.lab;

  // Normalize legacy 'molar' deep-links to 'experiments' (Lab 1 includes Molar Mass!)
  const normalizedTool: Exclude<LabToolTab, 'molar'> =
    activeTool === 'molar' ? 'experiments' : activeTool;

  // --- Periodic Table & Heatmap State ---
  const [elSearch, setElSearch] = useState('');
  const [elCategory, setElCategory] = useState<ElementCategory | 'all'>('all');
  const [heatmapMode, setHeatmapMode] = useState<HeatmapMode>('category');

  // --- Equation Balancer State ---
  const [eqId, setEqId] = useState(equations[0].id);
  const activeEquation = useMemo(
    () => equations.find((e) => e.id === eqId) ?? equations[0],
    [eqId, equations]
  );
  const [coeffs, setCoeffs] = useState<number[]>(() => activeEquation.species.map(() => 1));

  const switchEquation = (nextId: string) => {
    const found = equations.find((e) => e.id === nextId) ?? equations[0];
    setEqId(found.id);
    setCoeffs(found.species.map(() => 1));
  };

  const selectedElement: PeriodicElement =
    PERIODIC_ELEMENTS.find((el) => el.symbol === selectedElementSymbol) ??
    PERIODIC_ELEMENTS.find((el) => el.symbol === 'Cr') ??
    PERIODIC_ELEMENTS[0];

  const filteredElements = useMemo(() => {
    const q = elSearch.trim().toLowerCase();
    return PERIODIC_ELEMENTS.filter((el) => {
      const matchesCat = elCategory === 'all' || el.category === elCategory;
      const matchesQ =
        !q ||
        el.nameAr.includes(q) ||
        el.symbol.toLowerCase().includes(q) ||
        el.nameEn.toLowerCase().includes(q) ||
        String(el.number) === q;
      return matchesCat && matchesQ;
    });
  }, [elCategory, elSearch]);

  const balanceCheck = useMemo(
    () => checkEquationBalance(activeEquation.species, coeffs),
    [activeEquation.species, coeffs]
  );

  const updateCoeff = (idx: number, delta: number) => {
    setCoeffs((prev) =>
      prev.map((c, i) => (i === idx ? Math.max(1, Math.min(12, c + delta)) : c))
    );
  };

  const getMetricValueLabel = (el: PeriodicElement): string => {
    if (heatmapMode === 'radius') return `${el.atomicRadiusPm} pm`;
    if (heatmapMode === 'ionization') return `${el.firstIonizationKj}`;
    if (heatmapMode === 'affinity')
      return el.electronAffinityKj === null ? '—' : `${el.electronAffinityKj}`;
    if (heatmapMode === 'electronegativity')
      return el.electronegativity === null ? 'خامل' : `${el.electronegativity}`;
    return `${el.mass.toFixed(1)}`;
  };

  return (
    <section
      id="view-lab"
      className={`app-view ${
        active ? 'view-reveal' : 'hidden'
      } academy-container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-6`}
    >
      <div>
        <h2 className="text-2xl sm:text-3xl font-black aurora-text">{heading}</h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{subheading}</p>
      </div>

      {/* 7 Grade 2 Term 1 Interactive Lab Selector Bar */}
      <div
        role="tablist"
        aria-label="أدوات المختبر التفاعلي للصف الثاني الثانوي"
        className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10"
      >
        {LAB_TOOLS.map((tool) => {
          const Icon = tool.icon;
          const isSelected = normalizedTool === tool.id;
          return (
            <button
              key={tool.id}
              type="button"
              role="tab"
              aria-selected={isSelected}
              onClick={() => onSelectTool(tool.id)}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer ${
                isSelected
                  ? 'theme-grad-btn text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{tool.label}</span>
            </button>
          );
        })}
      </div>

      {/* LAB 1: STOICHIOMETRY, LIMITING REACTANT & DILUTION */}
      {normalizedTool === 'experiments' && <StoichiometryLab onNotify={onNotify} />}

      {/* LAB 2: RUTHERFORD GOLD FOIL SIMULATOR */}
      {normalizedTool === 'rutherford' && <RutherfordLab onNotify={onNotify} />}

      {/* LAB 3: BOHR HYDROGEN EMISSION SPECTRUM */}
      {normalizedTool === 'bohr' && <BohrSpectrumLab />}

      {/* LAB 4: ELECTRON CONFIGURATION, HUND/PAULI ORBITALS & 4 QUANTUM NUMBERS */}
      {normalizedTool === 'orbitals' && <OrbitalsQuantumLab />}

      {/* LAB 5: INTERACTIVE PERIODIC TABLE & PERIODIC TRENDS HEATMAP */}
      {normalizedTool === 'periodic' && (
        <div className="space-y-4">
          {/* Heatmap Mode Bar */}
          <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-extrabold text-slate-600 dark:text-slate-300 ml-1">
                خريطة تدرج الخواص (Heatmap):
              </span>
              {(
                [
                  { id: 'category', label: 'العائلات' },
                  { id: 'radius', label: 'نصف القطر (pm)' },
                  { id: 'ionization', label: 'جهد التأين (kJ/mol)' },
                  { id: 'affinity', label: 'الميل الإلكتروني (kJ/mol)' },
                  { id: 'electronegativity', label: 'السالبية الكهربية' },
                ] as Array<{ id: HeatmapMode; label: string }>
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setHeatmapMode(m.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    heatmapMode === m.id
                      ? 'theme-grad-btn text-white'
                      : 'bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-200/80 dark:hover:bg-white/10'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-bold text-amber-700 dark:text-amber-300">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>الشواذ المميزة: Be &gt; B · Mg &gt; Al · N &gt; O · Cl &gt; F · Cr · Cu</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-8 space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={elSearch}
                    onChange={(e) => setElSearch(e.target.value)}
                    placeholder="ابحث بالاسم أو الرمز أو العدد الذري (مثل Cl أو Cs أو 24)..."
                    aria-label="بحث في الجدول الدوري"
                    className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-sm"
                  />
                </div>
                <select
                  aria-label="تصفية حسب عائلة العنصر"
                  value={elCategory}
                  onChange={(e) => setElCategory(e.target.value as ElementCategory | 'all')}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 text-xs font-bold cursor-pointer"
                >
                  <option value="all">جميع العائلات ({PERIODIC_ELEMENTS.length})</option>
                  {Object.entries(ELEMENT_CATEGORY_META).map(([key, meta]) => (
                    <option key={key} value={key}>
                      {meta.labelAr}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2.5">
                {filteredElements.map((el) => {
                  const meta = ELEMENT_CATEGORY_META[el.category];
                  const isSelected = el.symbol === selectedElement.symbol;
                  const heatBg = getHeatBackground(el, heatmapMode);
                  return (
                    <button
                      key={el.symbol}
                      type="button"
                      onClick={() => onSelectElementSymbol(el.symbol)}
                      style={
                        heatmapMode !== 'category' && !isSelected
                          ? { backgroundColor: heatBg }
                          : undefined
                      }
                      className={`p-2.5 rounded-xl border text-center transition-transform hover:-translate-y-0.5 cursor-pointer relative ${
                        isSelected
                          ? 'theme-border ring-2 ring-cyan-400/40 bg-white dark:bg-white/10 text-slate-900 dark:text-white'
                          : heatmapMode === 'category'
                            ? meta.colorClass
                            : 'border-slate-200 dark:border-white/15 text-slate-900 dark:text-slate-100'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[10px] font-mono opacity-85">
                        <span>{el.number}</span>
                        <span className="font-bold uppercase">{el.block}</span>
                      </div>
                      <div className="font-mono text-xl font-black my-0.5">{el.symbol}</div>
                      <div className="text-[11px] font-bold truncate">{el.nameAr}</div>
                      <div className="formula-ltr text-[10px] font-bold opacity-80 tabular-nums mt-0.5">
                        {getMetricValueLabel(el)}
                      </div>
                      {el.anomalyNoteAr && (
                        <span
                          title={el.anomalyNoteAr}
                          className="absolute top-1 left-1 text-[9px] font-black text-amber-500"
                        >
                          ★
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Live Element & Trends Inspector */}
            <div className="lg:col-span-4 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-bold theme-text">
                    {ELEMENT_CATEGORY_META[selectedElement.category].labelAr} · الفئة ({selectedElement.block})
                  </div>
                  <h3 className="text-2xl font-black text-slate-900 dark:text-slate-100 mt-0.5">
                    {selectedElement.nameAr}{' '}
                    <span className="formula-ltr text-lg text-slate-500">
                      ({selectedElement.symbol})
                    </span>
                  </h3>
                  <div className="text-xs text-slate-500">
                    {selectedElement.nameEn} · الدورة {selectedElement.period} · المجموعة {selectedElement.group}
                  </div>
                </div>
                <div className="formula-ltr text-2xl font-black theme-text tabular-nums">
                  {selectedElement.number}
                </div>
              </div>

              <div className="py-1 text-slate-700 dark:text-slate-200">
                <BohrAtomVisual
                  symbol={selectedElement.symbol}
                  atomicNumber={selectedElement.number}
                  shells={selectedElement.shells}
                  size={195}
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5 text-xs">
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                  <div className="text-slate-500 dark:text-slate-400">التوزيع الإلكتروني</div>
                  <div className="formula-ltr font-bold theme-text mt-0.5">{selectedElement.config}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                  <div className="text-slate-500 dark:text-slate-400">نصف القطر الذري</div>
                  <div className="formula-ltr font-bold mt-0.5 tabular-nums">
                    {selectedElement.atomicRadiusPm} pm
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                  <div className="text-slate-500 dark:text-slate-400">جهد التأين الأول</div>
                  <div className="formula-ltr font-bold mt-0.5 tabular-nums">
                    {selectedElement.firstIonizationKj} kJ/mol
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                  <div className="text-slate-500 dark:text-slate-400">الميل الإلكتروني</div>
                  <div className="formula-ltr font-bold mt-0.5 tabular-nums">
                    {selectedElement.electronAffinityKj !== null
                      ? `${selectedElement.electronAffinityKj} kJ/mol`
                      : '—'}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                  <div className="text-slate-500 dark:text-slate-400">السالبية الكهربية</div>
                  <div className="formula-ltr font-bold mt-0.5">
                    {selectedElement.electronegativity ?? 'خامل'}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-950/60">
                  <div className="text-slate-500 dark:text-slate-400">الكتلة الذرية</div>
                  <div className="formula-ltr font-bold mt-0.5">{selectedElement.mass} u</div>
                </div>
              </div>

              {selectedElement.anomalyNoteAr && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/35 text-xs font-bold text-amber-800 dark:text-amber-200 leading-relaxed">
                  ★ {selectedElement.anomalyNoteAr}
                </div>
              )}

              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed border-t border-slate-200 dark:border-white/10 pt-3">
                {selectedElement.highlightAr}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* LAB 6: OXIDES TEST-TUBE LAB & OXIDATION / REDOX TRAINER */}
      {normalizedTool === 'oxides' && <OxidesRedoxLab onNotify={onNotify} />}

      {/* TOOL 7: INTERACTIVE EQUATION BALANCER */}
      {normalizedTool === 'balancer' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-4 p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-2.5">
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white mb-2">
              اختر معادلة منهجية للموازنة ({equations.length})
            </h3>
            {equations.map((eq) => (
              <button
                key={eq.id}
                type="button"
                onClick={() => switchEquation(eq.id)}
                className={`w-full p-3 rounded-xl border text-right transition cursor-pointer ${
                  eq.id === activeEquation.id
                    ? 'theme-border theme-bg-soft'
                    : 'border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/5'
                }`}
              >
                <div className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
                  {eq.title}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {eq.category}
                </div>
              </button>
            ))}
          </div>

          <div className="lg:col-span-8 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-xs font-bold theme-text">{activeEquation.category}</div>
                <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  {activeEquation.title}
                </h3>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setCoeffs([...activeEquation.solution]);
                    onNotify('تم تطبيق المعاملات الموزونة الصحيحة');
                  }}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5 theme-text" />
                  <span>إظهار الحل</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCoeffs(activeEquation.species.map(() => 1))}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>تصفير</span>
                </button>
              </div>
            </div>

            {/* Interactive Species Coefficient Controls */}
            <div
              dir="ltr"
              className="flex flex-wrap items-center justify-center gap-3 p-5 rounded-2xl bg-slate-100 dark:bg-slate-950/70 border border-slate-200 dark:border-white/10"
            >
              {activeEquation.species.map((sp, idx) => {
                const prevSide = idx > 0 ? activeEquation.species[idx - 1].side : null;
                const showArrow = prevSide === 'reactant' && sp.side === 'product';
                const showPlus = prevSide === sp.side;
                return (
                  <div key={`${activeEquation.id}-${idx}`} className="flex items-center gap-2.5">
                    {showPlus && <span className="font-mono text-lg font-black text-slate-400">+</span>}
                    {showArrow && <span className="font-mono text-xl font-black theme-text px-1">→</span>}
                    <div className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 shadow-xs">
                      <button
                        type="button"
                        aria-label={`إنقاص معامل ${sp.formula}`}
                        onClick={() => updateCoeff(idx, -1)}
                        className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-white/10 flex items-center justify-center hover:theme-bg-soft cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="font-mono text-base font-black theme-text w-5 text-center tabular-nums">
                        {coeffs[idx]}
                      </span>
                      <button
                        type="button"
                        aria-label={`زيادة معامل ${sp.formula}`}
                        onClick={() => updateCoeff(idx, 1)}
                        className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-white/10 flex items-center justify-center hover:theme-bg-soft cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <span className="font-mono text-base font-extrabold text-slate-900 dark:text-white pl-1">
                        {sp.formula}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Atom Balance Verification Table */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-slate-500">ميزان الذرات الحي:</span>
                {balanceCheck.balanced ? (
                  <span className="inline-flex items-center gap-1.5 text-xs font-black text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>المعادلة موزونة تماماً!</span>
                  </span>
                ) : (
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                    اضبط المعاملات لتساوي الذرات في الطرفين
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {balanceCheck.elements.map((el) => (
                  <div
                    key={el.symbol}
                    className={`p-3 rounded-xl border text-center ${
                      el.matched
                        ? 'border-emerald-500/40 bg-emerald-500/10'
                        : 'border-amber-500/40 bg-amber-500/10'
                    }`}
                  >
                    <div className="formula-ltr text-base font-black">{el.symbol}</div>
                    <div className="formula-ltr text-xs font-bold tabular-nums mt-0.5">
                      {el.left} ⇄ {el.right}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 border-t border-slate-200 dark:border-white/10 pt-3">
              {activeEquation.note}
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
