import { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Circle,
  ClipboardList,
  Clock,
  Copy,
  FileText,
  Lightbulb,
  Search,
  Sparkles,
  Target,
  X,
} from 'lucide-react';
import {
  ACADEMY_DATA,
  CURRICULUM_UNIT_META,
  type LessonBlock,
  type LessonItem,
} from '../data/academyData';
import {
  buildMistakeFromLessonPracticeMcq,
  type MistakeInput,
} from '../utils/mistakesEngine';
import type { ExplanationJumpTarget } from './MistakesView';
import { WrongAnswerExplainButton } from './WrongAnswerExplainButton';

export interface HighlightedLessonSection {
  lessonId: string;
  sectionIndex: number;
  sectionTitle: string;
  questionText: string;
}

interface LessonsViewProps {
  active: boolean;
  selectedLessonId: string;
  completedLessons: string[];
  highlightedSection: HighlightedLessonSection | null;
  onSelectLesson: (id: string) => void;
  onToggleComplete: (id: string) => void;
  onRecordMistake: (input: MistakeInput) => void;
  onJumpToExplanation: (target: ExplanationJumpTarget) => void;
  onClearHighlightedSection: () => void;
  onReturnToMistakes: () => void;
  onOpenLessonQuestions?: (lessonId: string) => void;
  onNotify: (msg: string) => void;
}

const UNIT_FILTERS = [
  { id: 'all', label: 'جميع الأبواب (12)' },
  ...CURRICULUM_UNIT_META.map((u) => ({
    id: u.id,
    label: u.fullName,
  })),
] as const;

export function LessonsView({
  active,
  selectedLessonId,
  completedLessons,
  highlightedSection,
  onSelectLesson,
  onToggleComplete,
  onRecordMistake,
  onJumpToExplanation,
  onClearHighlightedSection,
  onReturnToMistakes,
  onOpenLessonQuestions,
  onNotify,
}: LessonsViewProps) {
  const { heading, subheading, items } = ACADEMY_DATA.lessons;
  const [unitFilter, setUnitFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [checkAnswers, setCheckAnswers] = useState<Record<string, number>>({});
  const [revealedEssays, setRevealedEssays] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (!active || !highlightedSection) return;
    if (highlightedSection.lessonId !== selectedLessonId) return;
    setUnitFilter('all');
    setSearch('');
    const timer = window.setTimeout(() => {
      const targetEl = document.getElementById(
        `lesson-section-${highlightedSection.lessonId}-${highlightedSection.sectionIndex}`
      );
      targetEl?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 120);
    return () => window.clearTimeout(timer);
  }, [active, highlightedSection, selectedLessonId]);

  const filteredLessons = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items.filter((item) => {
      const matchesUnit = unitFilter === 'all' || item.unitId === unitFilter;
      const matchesSearch =
        !q ||
        item.title.toLowerCase().includes(q) ||
        item.summary.toLowerCase().includes(q) ||
        item.unitName.toLowerCase().includes(q) ||
        item.focusPoints.some((fp) => fp.toLowerCase().includes(q));
      return matchesUnit && matchesSearch;
    });
  }, [items, search, unitFilter]);

  const activeLesson: LessonItem =
    items.find((l) => l.id === selectedLessonId) ?? items[0];

  const lessonQuestionCount = useMemo(() => {
    const mcqs = ACADEMY_DATA.quiz.questions.filter((q) => q.lessonId === activeLesson.id).length;
    const essays = ACADEMY_DATA.quiz.essayQuestions.filter(
      (q) => q.lessonId === activeLesson.id
    ).length;
    return mcqs + essays;
  }, [activeLesson.id]);

  const isCompleted = completedLessons.includes(activeLesson.id);

  const copyText = (txt: string, label = 'المعادلة أو القانون') => {
    navigator.clipboard?.writeText(txt).catch(() => {});
    onNotify(`تم نسخ ${label} إلى الحافظة`);
  };

  const renderBlock = (block: LessonBlock, bIdx: number) => {
    if (block.type === 'formula' && block.content) {
      return (
        <div
          key={bIdx}
          className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950/75 border border-slate-200 dark:border-white/10 space-y-2"
        >
          {block.title && (
            <div className="text-xs font-extrabold theme-text">{block.title}</div>
          )}
          <div className="flex items-start justify-between gap-3">
            <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-cyan-300 whitespace-pre-line leading-relaxed overflow-x-auto flex-1">
              {block.content}
            </div>
            <button
              type="button"
              onClick={() => copyText(block.content!)}
              aria-label="نسخ القانون أو المعادلة"
              title="نسخ القانون"
              className="p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 shrink-0 cursor-pointer"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
        </div>
      );
    }

    if (block.type === 'table' && block.table) {
      return (
        <div
          key={bIdx}
          className="overflow-x-auto rounded-xl border border-slate-200 dark:border-white/12"
        >
          <table className="w-full text-right text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-slate-100 dark:bg-white/[0.08] border-b border-slate-200 dark:border-white/12">
                {block.table.headers.map((h, hIdx) => (
                  <th
                    key={hIdx}
                    className="px-3.5 py-2.5 font-extrabold text-slate-900 dark:text-white whitespace-nowrap"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-white/10">
              {block.table.rows.map((row, rIdx) => (
                <tr
                  key={rIdx}
                  className="bg-white dark:bg-transparent hover:bg-slate-50 dark:hover:bg-white/[0.03]"
                >
                  {row.map((cell, cIdx) => (
                    <td
                      key={cIdx}
                      className={`px-3.5 py-2.5 leading-relaxed ${
                        cIdx === 0
                          ? 'font-bold text-slate-900 dark:text-slate-100'
                          : 'text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }

    if (block.type === 'example' && block.items && block.items.length > 0) {
      return (
        <div
          key={bIdx}
          className="p-4 sm:p-5 rounded-xl border border-emerald-500/25 bg-emerald-500/[0.05] dark:bg-emerald-500/[0.07] space-y-2.5"
        >
          <div className="flex items-center gap-2 text-xs sm:text-sm font-extrabold text-emerald-700 dark:text-emerald-300">
            <FileText className="w-4 h-4 shrink-0" />
            <span>{block.title ?? 'مثال محلول بالخطوات'}</span>
          </div>
          <div className="space-y-2 text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
            {block.items.map((step, sIdx) => (
              <p
                key={sIdx}
                className={
                  step.startsWith('المثال:')
                    ? 'font-extrabold text-slate-900 dark:text-white pb-1 border-b border-emerald-500/15'
                    : 'pr-2 border-r-2 border-emerald-500/35'
                }
              >
                {step}
              </p>
            ))}
          </div>
        </div>
      );
    }

    if (block.type === 'analogy' && block.content) {
      return (
        <div
          key={bIdx}
          className="p-4 rounded-xl border border-cyan-500/25 bg-cyan-500/[0.06] space-y-1"
        >
          <div className="text-xs font-extrabold text-cyan-700 dark:text-cyan-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{block.title ?? 'تقريب للفهم العميق'}</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
            {block.content}
          </p>
        </div>
      );
    }

    if (block.type === 'bullet' && block.items && block.items.length > 0) {
      return (
        <ul key={bIdx} className="space-y-2 pr-1 text-sm text-slate-700 dark:text-slate-300">
          {block.items.map((item, idx) => (
            <li key={idx} className="flex items-start gap-2.5 leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full theme-grad-btn mt-2 shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      );
    }

    if (block.content) {
      return (
        <p
          key={bIdx}
          className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed"
        >
          {block.content}
        </p>
      );
    }

    return null;
  };

  return (
    <section
      id="view-lessons"
      className={`app-view ${
        active ? 'view-reveal' : 'hidden'
      } max-w-[1480px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6`}
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black aurora-text">{heading}</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{subheading}</p>
        </div>
        <div className="text-xs sm:text-sm font-bold text-slate-600 dark:text-slate-300 tabular-nums">
          الإنجاز: <span className="theme-text">{completedLessons.length}</span> / {items.length} دروس مكتملة
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
        <div className="flex flex-wrap gap-1.5 p-1 rounded-xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10">
          {UNIT_FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setUnitFilter(f.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                unitFilter === f.id
                  ? 'theme-grad-btn text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-white/10'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="relative w-full lg:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث داخل الدروس الـ 12..."
            aria-label="ابحث داخل الدروس"
            className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
          />
        </div>
      </div>

      {/* Split Curriculum Grid + Interactive Lesson Reader */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Lessons List (12 Lessons) */}
        <div className="lg:col-span-4 space-y-2.5 lg:sticky lg:top-24 lg:max-h-[calc(100vh-7.5rem)] lg:overflow-y-auto custom-scrollbar lg:pl-1">
          {filteredLessons.length === 0 ? (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/5 text-center text-sm text-slate-500">
              لا توجد دروس مطابقة لبحثك.
            </div>
          ) : (
            filteredLessons.map((lesson) => {
              const selected = lesson.id === activeLesson.id;
              const done = completedLessons.includes(lesson.id);
              return (
                <button
                  key={lesson.id}
                  type="button"
                  onClick={() => onSelectLesson(lesson.id)}
                  className={`bento-card w-full text-right p-4 rounded-2xl border transition-all cursor-pointer ${
                    selected
                      ? 'theme-border bg-white dark:bg-white/[0.08] shadow-md dark:shadow-none'
                      : 'border-slate-200 dark:border-white/10 bg-white/80 dark:bg-white/[0.03] hover:border-slate-300 dark:hover:border-white/20'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1 min-w-0">
                      <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-1.5">
                        <span className="theme-text font-extrabold">{lesson.numberLabel}</span>
                        <span aria-hidden="true">·</span>
                        <span>{lesson.level}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{lesson.durationMin} د</span>
                      </div>
                      <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 leading-snug">
                        {lesson.title}
                      </h3>
                      <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                        {lesson.summary}
                      </p>
                    </div>
                    {done ? (
                      <CheckCircle2
                        className="w-5 h-5 theme-text shrink-0 mt-0.5"
                        aria-label="درس مكتمل"
                      />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 dark:text-slate-600 shrink-0 mt-0.5" />
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Active Lesson Detailed Reader */}
        <article className="lg:col-span-8 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] overflow-hidden shadow-sm dark:shadow-none">
          <div className="relative h-52 sm:h-64 w-full bg-slate-950 overflow-hidden">
            <img
              src={activeLesson.coverImage}
              alt={activeLesson.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-75"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/65 to-transparent" />
            <div className="absolute bottom-0 inset-x-0 p-6 flex flex-wrap items-end justify-between gap-4">
              <div className="space-y-1.5">
                <div className="text-xs font-bold theme-text flex flex-wrap items-center gap-2">
                  <span>{activeLesson.unitName}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeLesson.numberLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1 tabular-nums">
                    <Clock className="w-3.5 h-3.5" />
                    {activeLesson.durationMin} دقيقة
                  </span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white leading-snug">
                  {activeLesson.title}
                </h3>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {onOpenLessonQuestions && (
                  <button
                    type="button"
                    onClick={() => onOpenLessonQuestions(activeLesson.id)}
                    className="px-4 py-2.5 rounded-xl border border-white/25 bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm inline-flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <ClipboardList className="w-4 h-4" />
                    <span>بنك أسئلة الدرس ({lessonQuestionCount})</span>
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => onToggleComplete(activeLesson.id)}
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm inline-flex items-center gap-2 transition cursor-pointer ${
                    isCompleted
                      ? 'bg-emerald-500/20 border border-emerald-400/50 text-emerald-200'
                      : 'theme-grad-btn text-white'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isCompleted ? 'تم إتمام الدرس' : 'تحديد الدرس كمكتمل'}</span>
                </button>
              </div>
            </div>
          </div>

          <div className="p-6 sm:p-8 space-y-8">
            {/* Core Idea & Curriculum Importance */}
            {(activeLesson.coreIdea || activeLesson.curriculumImportance) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeLesson.coreIdea && (
                  <div className="p-4 rounded-xl border theme-border theme-bg-soft space-y-1.5">
                    <div className="text-xs font-extrabold theme-text flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4" />
                      <span>الفكرة المحورية للدرس</span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                      {activeLesson.coreIdea}
                    </p>
                  </div>
                )}
                {activeLesson.curriculumImportance && (
                  <div className="p-4 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.03] space-y-1.5">
                    <div className="text-xs font-extrabold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Target className="w-4 h-4 theme-text" />
                      <span>موقعه وأهميته في المنهج</span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      {activeLesson.curriculumImportance}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Learning Objectives / Axes Quick Nav */}
            <div className="space-y-3">
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Target className="w-4 h-4 theme-text" />
                <span>محاور الشرح في هذا الدرس</span>
              </h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                {activeLesson.objectives.map((obj, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/70 dark:border-white/10"
                  >
                    <span className="font-mono text-xs font-bold theme-text mt-0.5 tabular-nums">
                      0{idx + 1}.
                    </span>
                    <span className="font-semibold">{obj}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Structured Content Sections (المحاور الكاملة مع الجداول والأمثلة المحلولة) */}
            <div className="space-y-7 border-t border-slate-200 dark:border-white/10 pt-6">
              {activeLesson.sections.map((sec, idx) => {
                const isSpotlit =
                  highlightedSection?.lessonId === activeLesson.id &&
                  highlightedSection.sectionIndex === idx;
                return (
                  <div
                    key={idx}
                    id={`lesson-section-${activeLesson.id}-${idx}`}
                    data-highlighted={isSpotlit ? 'true' : 'false'}
                    className={`space-y-4 transition-all ${
                      isSpotlit
                        ? 'p-5 rounded-2xl border-2 border-amber-500/70 bg-amber-500/[0.08] ring-4 ring-amber-500/15'
                        : 'pb-5 border-b border-slate-200/70 dark:border-white/10 last:border-b-0 last:pb-0'
                    }`}
                  >
                    {isSpotlit && (
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-2 border-b border-amber-500/30">
                        <div className="flex items-center gap-2 text-xs font-extrabold text-amber-700 dark:text-amber-300">
                          <Sparkles className="w-4 h-4 shrink-0" />
                          <span>هذا هو الجزء الخاص بشرح السؤال الذي أخطأت في حله</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={onReturnToMistakes}
                            className="px-3 py-1 rounded-lg bg-amber-500/20 text-amber-900 dark:text-amber-200 text-[11px] font-extrabold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <ArrowRight className="w-3 h-3" />
                            <span>العودة إلى أخطائي</span>
                          </button>
                          <button
                            type="button"
                            aria-label="إخفاء تمييز الشرح"
                            onClick={onClearHighlightedSection}
                            className="p-1 rounded-lg hover:bg-amber-500/20 text-amber-700 dark:text-amber-300 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}

                    <h4 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 theme-text shrink-0" />
                      <span>{sec.title}</span>
                    </h4>

                    {sec.blocks && sec.blocks.length > 0 ? (
                      <div className="space-y-3.5">
                        {sec.blocks.map((block, bIdx) => renderBlock(block, bIdx))}
                      </div>
                    ) : (
                      <>
                        <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
                          {sec.body}
                        </p>
                        {sec.equation && (
                          <div className="flex items-center justify-between gap-3 p-4 rounded-xl bg-slate-100 dark:bg-slate-950/70 border border-slate-200 dark:border-white/10">
                            <code className="formula-ltr text-xs sm:text-sm font-bold text-slate-900 dark:text-cyan-300 overflow-x-auto">
                              {sec.equation}
                            </code>
                            <button
                              type="button"
                              onClick={() => copyText(sec.equation!)}
                              aria-label="نسخ المعادلة"
                              title="نسخ المعادلة"
                              className="p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 shrink-0 cursor-pointer"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                );
              })}
            </div>

            {/* فخاخ الامتحانات والأخطاء الشائعة */}
            {activeLesson.examTraps.length > 0 && (
              <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/35 space-y-3">
                <div className="flex items-center gap-2 text-sm font-extrabold text-amber-800 dark:text-amber-300">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>فخاخ الامتحانات والأخطاء الشائعة</span>
                </div>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                  {activeLesson.examTraps.map((trap, tIdx) => (
                    <li key={tIdx} className="flex items-start gap-2.5">
                      <span className="font-mono text-xs font-black text-amber-700 dark:text-amber-400 mt-0.5 tabular-nums">
                        {tIdx + 1}.
                      </span>
                      <span>{trap}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* أهم النقاط للتركيز أثناء المذاكرة */}
            {activeLesson.focusPoints.length > 0 && (
              <div className="p-5 rounded-2xl border theme-border bg-slate-50 dark:bg-white/[0.03] space-y-3">
                <div className="flex items-center gap-2 text-sm font-extrabold theme-text">
                  <Lightbulb className="w-4 h-4 shrink-0" />
                  <span>أهم النقاط للتركيز أثناء المذاكرة</span>
                </div>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                  {activeLesson.focusPoints.map((fp, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 theme-text shrink-0 mt-0.5" />
                      <span>{fp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* تدريبات التحقق من الفهم - مُجابة ومشروحة (الاختياري + المقالي) */}
            <div className="border-t border-slate-200 dark:border-white/10 pt-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h4 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-slate-100">
                  تدريبات التحقق من الفهم — مُجابة ومشروحة ({activeLesson.practiceChecks.length})
                </h4>
                {onOpenLessonQuestions && (
                  <button
                    type="button"
                    onClick={() => onOpenLessonQuestions(activeLesson.id)}
                    className="text-xs font-extrabold theme-text hover:underline inline-flex items-center gap-1 cursor-pointer"
                  >
                    <span>افتح جميع أسئلة ومسائل الدرس ({lessonQuestionCount} سؤالاً)</span>
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="space-y-5">
                {activeLesson.practiceChecks.map((check, cIdx) => {
                  if (check.kind === 'mcq') {
                    const picked = checkAnswers[check.id];
                    const answered = picked !== undefined;
                    return (
                      <div
                        key={check.id}
                        className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.02] space-y-3.5"
                      >
                        <p className="text-sm sm:text-base font-bold text-slate-800 dark:text-slate-100 leading-relaxed">
                          <span className="theme-text font-black ml-1.5">{cIdx + 1})</span>
                          {check.question}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          {check.options.map((opt, optIdx) => {
                            const isPicked = picked === optIdx;
                            const isRight = optIdx === check.correctIndex;
                            let btnStyle =
                              'border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 hover:border-slate-400 dark:hover:border-white/30 text-slate-800 dark:text-slate-200';
                            if (answered && isRight) {
                              btnStyle =
                                'border-emerald-500 bg-emerald-500/15 text-emerald-800 dark:text-emerald-200';
                            } else if (answered && isPicked && !isRight) {
                              btnStyle =
                                'border-rose-500 bg-rose-500/15 text-rose-800 dark:text-rose-200';
                            }
                            const isWrongPicked = answered && isPicked && !isRight;
                            return (
                              <div key={optIdx} className="flex items-stretch gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setCheckAnswers((prev) => ({ ...prev, [check.id]: optIdx }));
                                    if (optIdx !== check.correctIndex) {
                                      onRecordMistake(
                                        buildMistakeFromLessonPracticeMcq(
                                          activeLesson,
                                          check,
                                          optIdx
                                        )
                                      );
                                    }
                                  }}
                                  className={`flex-1 min-w-0 p-3 rounded-xl border text-right text-xs sm:text-sm font-bold transition cursor-pointer ${btnStyle}`}
                                >
                                  {opt}
                                </button>
                                {isWrongPicked && (
                                  <WrongAnswerExplainButton
                                    questionId={check.id}
                                    questionText={check.question}
                                    lessonId={activeLesson.id}
                                    sectionIndex={0}
                                    onJumpToExplanation={onJumpToExplanation}
                                  />
                                )}
                              </div>
                            );
                          })}
                        </div>
                        {answered && (
                          <div className="p-3.5 rounded-xl bg-white dark:bg-slate-950/60 border border-slate-200 dark:border-white/10 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                            <span className="font-extrabold theme-text ml-1.5">
                              {picked === check.correctIndex
                                ? 'إجابة صحيحة:'
                                : 'التفسير الصحيح:'}
                            </span>
                            {check.explanation}
                          </div>
                        )}
                      </div>
                    );
                  }

                  // Essay / Problem Practice Check
                  const isOpen = Boolean(revealedEssays[check.id]);
                  return (
                    <div
                      key={check.id}
                      className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.02] space-y-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <p className="text-sm sm:text-base font-bold text-slate-800 dark:text-slate-100 leading-relaxed">
                          <span className="theme-text font-black ml-1.5">{cIdx + 1})</span>
                          <span className="inline-block px-2 py-0.5 rounded-md theme-bg-soft theme-text text-[11px] font-extrabold ml-2">
                            مسألة / مقالي
                          </span>
                          {check.question}
                        </p>
                      </div>
                      <button
                        type="button"
                        aria-expanded={isOpen}
                        onClick={() =>
                          setRevealedEssays((prev) => ({ ...prev, [check.id]: !prev[check.id] }))
                        }
                        className="px-4 py-2 rounded-xl border theme-border theme-bg-soft theme-text text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        {isOpen ? (
                          <>
                            <ChevronUp className="w-3.5 h-3.5" />
                            <span>إخفاء نموذج الإجابة</span>
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-3.5 h-3.5" />
                            <span>عرض نموذج الإجابة وخطوات الحل</span>
                          </>
                        )}
                      </button>
                      {isOpen && (
                        <div className="p-4 rounded-xl bg-white dark:bg-slate-950/70 border border-emerald-500/30 text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line">
                          <span className="font-extrabold text-emerald-600 dark:text-emerald-400 block mb-1">
                            نموذج الإجابة والحل:
                          </span>
                          {check.modelAnswer}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </article>
      </div>
    </section>
  );
}
