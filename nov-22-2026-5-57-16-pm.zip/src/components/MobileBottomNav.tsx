import { useState } from 'react';
import {
  AlertTriangle,
  Award,
  BookMarked,
  BookOpen,
  Bot,
  BrainCircuit,
  ClipboardCheck,
  FlaskConical,
  Home,
  Layers,
  Library,
  Menu,
  X,
} from 'lucide-react';
import type { AcademyViewId } from '../utils/academyState';

interface MobileBottomNavProps {
  activeView: AcademyViewId;
  unresolvedMistakesCount: number;
  onSwitchView: (view: AcademyViewId) => void;
}

const PRIMARY_MOBILE_TABS: ReadonlyArray<{
  id: AcademyViewId;
  label: string;
  icon: typeof Home;
}> = [
  { id: 'home', label: 'الرئيسية', icon: Home },
  { id: 'lessons', label: 'الدروس', icon: BookOpen },
  { id: 'lab', label: 'المختبر', icon: FlaskConical },
  { id: 'quiz', label: 'الاختبارات', icon: ClipboardCheck },
];

const MORE_DRAWER_ITEMS: ReadonlyArray<{
  id: AcademyViewId;
  label: string;
  desc: string;
  icon: typeof Home;
}> = [
  { id: 'assistant', label: 'المساعد الذكي للمنهج', desc: 'صفحة مستقلة · شات مجاني + معادلات KaTeX + بطاقات 3D + جدول مراجعة', icon: Bot },
  { id: 'syllabus', label: 'منهج الـ 14', desc: 'الشرح الكامل للـ 14 درساً + أطلس المعادلات الـ 18', icon: BookMarked },
  { id: 'mastery', label: 'مُعلّم الفهم', desc: 'خريطة المنهج ومُحلّل المسائل بالخطوات', icon: BrainCircuit },
  { id: 'mistakes', label: 'أخطائي', desc: 'سجل الأخطاء والرجوع الفوري للشرح', icon: AlertTriangle },
  { id: 'openbook', label: 'الكتاب المفتوح', desc: '14 ورقة مفاهيم + 93 نقطة مراجعة + الثوابت', icon: Library },
  { id: 'studio', label: 'الاستوديو', desc: '70 بطاقة مراجعة ثلاثية الأبعاد وبومودورو', icon: Layers },
  { id: 'certificates', label: 'الشهادات', desc: 'تحدي المتفوقين وإصدار شهادة التقدير', icon: Award },
];

export function MobileBottomNav({
  activeView,
  unresolvedMistakesCount,
  onSwitchView,
}: MobileBottomNavProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const isMoreActive = MORE_DRAWER_ITEMS.some((item) => item.id === activeView);

  const handleSelect = (view: AcademyViewId) => {
    setDrawerOpen(false);
    onSwitchView(view);
  };

  return (
    <>
      {/* Slide-Up Mobile Sheet for Secondary Views */}
      {drawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50 no-print">
          <div
            aria-hidden="true"
            onClick={() => setDrawerOpen(false)}
            className="absolute inset-0 bg-black/55 backdrop-blur-xs"
          />
          <div
            role="dialog"
            aria-label="أقسام المنصة الإضافية"
            className="absolute bottom-0 inset-x-0 rounded-t-3xl border-t border-slate-200 dark:border-white/15 bg-white dark:bg-slate-950 p-4 pb-6 shadow-2xl space-y-3"
          >
            <div className="w-10 h-1 rounded-full bg-slate-300 dark:bg-slate-700 mx-auto" />
            <div className="flex items-center justify-between px-1">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
                أقسام الأكاديمية
              </h3>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                aria-label="إغلاق القائمة"
                className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 gap-2">
              {MORE_DRAWER_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = activeView === item.id;
                const showBadge = item.id === 'mistakes' && unresolvedMistakesCount > 0;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelect(item.id)}
                    className={`w-full min-h-[56px] px-3.5 py-2.5 rounded-2xl border flex items-center justify-between gap-3 text-right transition cursor-pointer ${
                      active
                        ? 'theme-border theme-bg-soft'
                        : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.03]'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-10 h-10 rounded-xl theme-bg-soft theme-text flex items-center justify-center shrink-0">
                        <Icon className="w-5 h-5" />
                      </span>
                      <div className="min-w-0">
                        <div className={`font-extrabold text-sm ${active ? 'theme-text' : 'text-slate-900 dark:text-slate-100'}`}>
                          {item.label}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {item.desc}
                        </div>
                      </div>
                    </div>
                    {showBadge && (
                      <span className="px-2 py-0.5 rounded-lg bg-rose-500 text-white text-xs font-black tabular-nums shrink-0">
                        {unresolvedMistakesCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Fixed Thumb-Zone Bottom Tab Bar (h-16 = 64px) */}
      <nav
        aria-label="التنقل السريع للهاتف"
        className="lg:hidden no-print fixed bottom-0 left-0 right-0 z-40 h-16 border-t border-slate-200 dark:border-white/10 bg-white/92 dark:bg-slate-950/92 glass-panel"
      >
        <div className="grid grid-cols-5 h-full max-w-lg mx-auto px-1">
          {PRIMARY_MOBILE_TABS.map((tab) => {
            const Icon = tab.icon;
            const active = activeView === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => handleSelect(tab.id)}
                aria-current={active ? 'page' : undefined}
                className={`flex flex-col items-center justify-center gap-0.5 min-h-[44px] rounded-xl transition cursor-pointer ${
                  active
                    ? 'theme-text font-extrabold'
                    : 'text-slate-500 dark:text-slate-400 font-semibold'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] leading-tight whitespace-nowrap">{tab.label}</span>
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => setDrawerOpen((prev) => !prev)}
            aria-expanded={drawerOpen}
            aria-label="المزيد من أقسام المنصة"
            className={`relative flex flex-col items-center justify-center gap-0.5 min-h-[44px] rounded-xl transition cursor-pointer ${
              drawerOpen || isMoreActive
                ? 'theme-text font-extrabold'
                : 'text-slate-500 dark:text-slate-400 font-semibold'
            }`}
          >
            <Menu className="w-5 h-5" />
            <span className="text-[10px] leading-tight whitespace-nowrap">المزيد</span>
            {unresolvedMistakesCount > 0 && (
              <span className="absolute top-1.5 left-3 px-1 min-w-[16px] h-4 rounded-md bg-rose-500 text-white text-[9px] font-black flex items-center justify-center tabular-nums">
                {unresolvedMistakesCount}
              </span>
            )}
          </button>
        </div>
      </nav>
    </>
  );
}
