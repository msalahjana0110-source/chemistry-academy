import { useMemo, useState } from 'react';
import {
  Bookmark,
  BookmarkCheck,
  BookMarked,
  Copy,
  ListChecks,
  Search,
  Sparkles,
  Thermometer,
} from 'lucide-react';
import { ACADEMY_DATA, CURRICULUM_UNIT_META } from '../data/academyData';

interface OpenBookViewProps {
  active: boolean;
  initialQuery: string;
  pinnedIds: string[];
  onTogglePin: (id: string) => void;
  onNotify: (msg: string) => void;
}

const LAW_CATEGORIES = [
  'الكل',
  'المثبتة',
  'الباب الأول: الحساب الكيميائي',
  'الباب الثاني: بنية الذرة',
  'الباب الثالث: الجدول الدوري وتصنيف العناصر',
  'المعادلات والثوابت',
] as const;

export function OpenBookView({
  active,
  initialQuery,
  pinnedIds,
  onTogglePin,
  onNotify,
}: OpenBookViewProps) {
  const { heading, subheading, entries, constants, atomicMasses, equations, revisionLessons } =
    ACADEMY_DATA.openBook;
  const [subMode, setSubMode] = useState<'laws' | 'revision'>('laws');

  // Laws & Formulas filters
  const [category, setCategory] = useState<string>('الكل');
  const [query, setQuery] = useState(initialQuery);

  // Final Revision Key Points filters
  const [revUnitFilter, setRevUnitFilter] = useState<'all' | 'pinned' | 'unit1' | 'unit2' | 'unit3'>('all');
  const [revLessonFilter, setRevLessonFilter] = useState<string>('all');

  // Live Unit Converter state (strictly English digits as requested)
  const [celsius, setCelsius] = useState<string>('25');
  const [atm, setAtm] = useState<string>('1');

  const effectiveQuery = query || initialQuery;

  const totalRevisionPointsCount = useMemo(
    () => revisionLessons.reduce((sum, l) => sum + l.points.length, 0),
    [revisionLessons]
  );

  const filteredLaws = useMemo(() => {
    if (category === 'المعادلات والثوابت') return [];
    const q = effectiveQuery.trim().toLowerCase();
    return entries.filter((entry) => {
      if (category === 'المثبتة' && !pinnedIds.includes(entry.id)) return false;
      if (category !== 'الكل' && category !== 'المثبتة' && entry.category !== category) {
        return false;
      }
      if (!q) return true;
      return (
        entry.title.toLowerCase().includes(q) ||
        entry.formula.toLowerCase().includes(q) ||
        entry.variables.toLowerCase().includes(q) ||
        entry.note.toLowerCase().includes(q)
      );
    });
  }, [category, effectiveQuery, entries, pinnedIds]);

  const filteredEquations = useMemo(() => {
    const q = effectiveQuery.trim().toLowerCase();
    if (!q) return equations;
    return equations.filter(
      (eq) =>
        eq.equation.toLowerCase().includes(q) || eq.tag.toLowerCase().includes(q)
    );
  }, [effectiveQuery, equations]);

  const availableRevisionLessons = useMemo(() => {
    if (revUnitFilter === 'all' || revUnitFilter === 'pinned') return revisionLessons;
    return revisionLessons.filter((l) => l.unitId === revUnitFilter);
  }, [revUnitFilter, revisionLessons]);

  const filteredRevisionBlocks = useMemo(() => {
    const q = effectiveQuery.trim().toLowerCase();
    return revisionLessons
      .filter((block) => {
        if (revUnitFilter !== 'all' && revUnitFilter !== 'pinned' && block.unitId !== revUnitFilter) {
          return false;
        }
        if (revLessonFilter !== 'all' && block.lessonId !== revLessonFilter) {
          return false;
        }
        return true;
      })
      .map((block) => {
        const matchedPoints = block.points.filter((pt) => {
          if (revUnitFilter === 'pinned' && !pinnedIds.includes(pt.id)) return false;
          if (!q) return true;
          return (
            pt.text.toLowerCase().includes(q) ||
            pt.subPoints.some((sp) => sp.toLowerCase().includes(q)) ||
            block.lessonTitle.toLowerCase().includes(q) ||
            block.unitName.toLowerCase().includes(q)
          );
        });
        return { ...block, points: matchedPoints };
      })
      .filter((block) => block.points.length > 0);
  }, [effectiveQuery, pinnedIds, revLessonFilter, revUnitFilter, revisionLessons]);

  const visibleRevisionCount = useMemo(
    () => filteredRevisionBlocks.reduce((sum, b) => sum + b.points.length, 0),
    [filteredRevisionBlocks]
  );

  const parsedC = Number.parseFloat(celsius);
  const kelvinVal = Number.isFinite(parsedC) ? (parsedC + 273.15).toFixed(2) : '—';
  const parsedAtm = Number.parseFloat(atm);
  const kpaVal = Number.isFinite(parsedAtm) ? (parsedAtm * 101.325).toFixed(2) : '—';
  const mmhgVal = Number.isFinite(parsedAtm) ? (parsedAtm * 760).toFixed(1) : '—';

  const copyContent = (text: string, label = 'المحتوى') => {
    navigator.clipboard?.writeText(text).catch(() => {});
    onNotify(`تم نسخ ${label} إلى الحافظة`);
  };

  return (
    <section
      id="view-openbook"
      className={`app-view ${
        active ? 'view-reveal' : 'hidden'
      } academy-container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-6`}
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black aurora-text">{heading}</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{subheading}</p>
        </div>
        <div className="text-xs font-bold text-slate-600 dark:text-slate-400 tabular-nums">
          العناصر المثبتة للمراجعة: <span className="theme-text">{pinnedIds.length}</span>
        </div>
      </div>

      {/* Primary Open Book Mode Switcher */}
      <div
        role="tablist"
        aria-label="أقسام الكتاب المفتوح"
        className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 w-fit"
      >
        <button
          type="button"
          role="tab"
          aria-selected={subMode === 'laws'}
          onClick={() => setSubMode('laws')}
          className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm inline-flex items-center gap-2 transition cursor-pointer ${
            subMode === 'laws'
              ? 'theme-grad-btn text-white'
              : 'text-slate-700 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10'
          }`}
        >
          <BookMarked className="w-4 h-4" />
          <span>أوراق المفاهيم والقوانين والمعادلات ({entries.length} + {equations.length})</span>
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={subMode === 'revision'}
          onClick={() => setSubMode('revision')}
          className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm inline-flex items-center gap-2 transition cursor-pointer ${
            subMode === 'revision'
              ? 'theme-grad-btn text-white'
              : 'text-slate-700 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10'
          }`}
        >
          <ListChecks className="w-4 h-4" />
          <span>أهم النقاط الجوهرية للمراجعة النهائية ({totalRevisionPointsCount} نقطة)</span>
        </button>
      </div>

      {/* ================================================================= */}
      {/* MODE A: 14 FORMULA & CONCEPT SHEETS + 18 EQUATIONS (FILE 17)      */}
      {/* ================================================================= */}
      {subMode === 'laws' && (
        <div className="space-y-5">
          {/* Category Filter + Instant Search */}
          <div className="flex flex-col xl:flex-row gap-3 items-stretch xl:items-center justify-between">
            <div className="flex flex-wrap gap-1.5 p-1 rounded-xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10">
              {LAW_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                    category === cat
                      ? 'theme-grad-btn text-white'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-white/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="relative w-full xl:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث في القوانين والمعادلات..."
                aria-label="ابحث في الكتاب المفتوح"
                className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
              />
            </div>
          </div>

          {category !== 'المعادلات والثوابت' && (
            <>
              {filteredLaws.length === 0 ? (
                <div className="p-8 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/5 text-center text-sm text-slate-500">
                  {category === 'المثبتة'
                    ? 'لم تقم بتثبيت أي قانون بعد — اضغط على أيقونة التثبيت بجوار أي قانون لإضافته إلى ورقتك.'
                    : 'لا توجد قوانين مطابقة للتصفية الحالية.'}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {filteredLaws.map((entry) => {
                    const pinned = pinnedIds.includes(entry.id);
                    const displayLines = entry.lines && entry.lines.length > 0 ? entry.lines : [entry.formula];
                    return (
                      <div
                        key={entry.id}
                        className="bento-card glass-panel p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] shadow-sm dark:shadow-none flex flex-col justify-between gap-4"
                      >
                        <div className="space-y-3">
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <div className="text-xs font-bold theme-text mb-1">{entry.category}</div>
                              <h3 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-slate-100">
                                {entry.title}
                              </h3>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => copyContent(displayLines.join('\n'), entry.title)}
                                aria-label={`نسخ ${entry.title}`}
                                title="نسخ القانون"
                                className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 text-slate-500 dark:text-slate-300 cursor-pointer"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => onTogglePin(entry.id)}
                                aria-label={
                                  pinned ? `إلغاء تثبيت ${entry.title}` : `تثبيت ${entry.title}`
                                }
                                title={pinned ? 'إلغاء التثبيت' : 'تثبيت في ورقتي'}
                                className={`p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer ${
                                  pinned ? 'theme-text' : 'text-slate-400'
                                }`}
                              >
                                {pinned ? (
                                  <BookmarkCheck className="w-4 h-4" />
                                ) : (
                                  <Bookmark className="w-4 h-4" />
                                )}
                              </button>
                            </div>
                          </div>

                          <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-950/70 border border-slate-200 dark:border-white/10 space-y-2">
                            {displayLines.map((line, idx) => (
                              <div
                                key={idx}
                                className="text-xs sm:text-sm font-bold text-slate-900 dark:text-cyan-300 leading-relaxed"
                              >
                                {line}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* 18 Balanced Curriculum Equations Card (shown in الكل or المعادلات والثوابت) */}
          {(category === 'الكل' || category === 'المعادلات والثوابت') && (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 dark:border-white/10 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-slate-100">
                    أهم المعادلات الكيميائية الموزونة بالمنهج ({filteredEquations.length} معادلة)
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    بطاقة مرجعية شاملة للنسخ والبحث السريع أثناء المراجعة وحل المسائل
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    copyContent(
                      filteredEquations.map((e) => `${e.number}- ${e.equation}`).join('\n'),
                      'المعادلات الموزونة'
                    )
                  }
                  className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold inline-flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 theme-text" />
                  <span>نسخ الكل</span>
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:gap-px bg-slate-200/70 dark:bg-white/10">
                {filteredEquations.map((eq) => (
                  <div
                    key={eq.id}
                    className="bg-white dark:bg-slate-950/80 px-4 py-3 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="font-mono text-xs font-black theme-text tabular-nums w-5 shrink-0">
                        {eq.number}
                      </span>
                      <code className="formula-ltr text-xs sm:text-sm font-bold text-slate-900 dark:text-cyan-300 truncate">
                        {eq.equation}
                      </code>
                    </div>
                    <button
                      type="button"
                      onClick={() => copyContent(eq.equation, `المعادلة #${eq.number}`)}
                      aria-label={`نسخ المعادلة رقم ${eq.number}`}
                      className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 text-slate-400 hover:theme-text cursor-pointer shrink-0"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================================================================= */}
      {/* MODE B: FINAL REVISION KEY POINTS (ALL 12 LESSONS / 93 POINTS)     */}
      {/* ================================================================= */}
      {subMode === 'revision' && (
        <div className="space-y-5">
          {/* Filters + Search */}
          <div className="flex flex-col xl:flex-row gap-3 items-stretch xl:items-center justify-between">
            <div className="flex flex-wrap gap-1.5 p-1 rounded-xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10">
              {(
                [
                  { id: 'all', label: `الكل (${totalRevisionPointsCount})` },
                  { id: 'pinned', label: 'المثبتة' },
                  ...CURRICULUM_UNIT_META.map((u) => ({
                    id: u.id,
                    label: u.fullName,
                  })),
                ] as Array<{ id: 'all' | 'pinned' | 'unit1' | 'unit2' | 'unit3'; label: string }>
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setRevUnitFilter(tab.id);
                    setRevLessonFilter('all');
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                    revUnitFilter === tab.id
                      ? 'theme-grad-btn text-white'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-white/10'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5">
              <select
                aria-label="اختر درساً من نقاط المراجعة"
                value={revLessonFilter}
                onChange={(e) => setRevLessonFilter(e.target.value)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 text-xs font-bold cursor-pointer max-w-full sm:max-w-[270px]"
              >
                <option value="all">جميع الدروس ({availableRevisionLessons.length} درساً)</option>
                {availableRevisionLessons.map((l) => (
                  <option key={l.lessonId} value={l.lessonId}>
                    {l.numberLabel}: {l.lessonTitle} ({l.points.length})
                  </option>
                ))}
              </select>

              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="ابحث في أهم النقاط والقوانين..."
                  aria-label="ابحث في أهم نقاط المراجعة النهائية"
                  className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
                />
              </div>
            </div>
          </div>

          <div className="text-xs font-bold text-slate-500 dark:text-slate-400 tabular-nums">
            عدد النقاط الجوهرية المعروضة: {visibleRevisionCount} نقطة مركّزة
          </div>

          {filteredRevisionBlocks.length === 0 ? (
            <div className="p-8 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/5 text-center text-sm text-slate-500">
              لا توجد نقاط مراجعة مطابقة للتصفية الحالية.
            </div>
          ) : (
            <div className="space-y-6">
              {filteredRevisionBlocks.map((block) => (
                <div
                  key={block.lessonId}
                  className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] overflow-hidden shadow-sm dark:shadow-none"
                >
                  <div className="px-5 py-4 bg-slate-100/80 dark:bg-white/[0.04] border-b border-slate-200 dark:border-white/10 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-[11px] font-extrabold theme-text">{block.unitName}</div>
                      <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                        <Sparkles className="w-4 h-4 theme-text shrink-0" />
                        <span>
                          {block.numberLabel} — {block.lessonTitle}
                        </span>
                      </h3>
                    </div>
                    <span className="text-xs font-extrabold theme-text tabular-nums">
                      {block.points.length} نقطة جوهرية
                    </span>
                  </div>

                  <div className="divide-y divide-slate-200/80 dark:divide-white/10">
                    {block.points.map((pt) => {
                      const pinned = pinnedIds.includes(pt.id);
                      const fullText =
                        pt.subPoints.length > 0
                          ? `${pt.text}\n${pt.subPoints.map((s) => `- ${s}`).join('\n')}`
                          : pt.text;
                      return (
                        <div
                          key={pt.id}
                          className="p-4 sm:p-5 flex items-start justify-between gap-4 hover:bg-slate-50/70 dark:hover:bg-white/[0.02] transition-colors"
                        >
                          <div className="space-y-2 flex-1 min-w-0">
                            <p className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100 leading-relaxed">
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-lg theme-bg-soft theme-text text-xs font-black ml-2 tabular-nums">
                                {pt.index}
                              </span>
                              {pt.text}
                            </p>
                            {pt.subPoints.length > 0 && (
                              <ul className="space-y-1.5 pr-8 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                                {pt.subPoints.map((sp, spIdx) => (
                                  <li key={spIdx} className="flex items-start gap-2">
                                    <span className="w-1.5 h-1.5 rounded-full theme-grad-btn mt-2 shrink-0" />
                                    <span>{sp}</span>
                                  </li>
                                ))}
                              </ul>
                            )}
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => copyContent(fullText, 'نقطة المراجعة')}
                              aria-label={`نسخ النقطة رقم ${pt.index}`}
                              title="نسخ النقطة"
                              className="p-2 rounded-lg hover:bg-slate-200/70 dark:hover:bg-white/10 text-slate-500 dark:text-slate-300 cursor-pointer"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onTogglePin(pt.id)}
                              aria-label={pinned ? 'إلغاء تثبيت النقطة' : 'تثبيت النقطة للمراجعة'}
                              title={pinned ? 'إلغاء التثبيت' : 'تثبيت في المراجعة'}
                              className={`p-2 rounded-lg hover:bg-slate-200/70 dark:hover:bg-white/10 cursor-pointer ${
                                pinned ? 'theme-text' : 'text-slate-400'
                              }`}
                            >
                              {pinned ? (
                                <BookmarkCheck className="w-4 h-4" />
                              ) : (
                                <Bookmark className="w-4 h-4" />
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Scientific Constants (6 items), 21 Atomic Masses & Live Unit Converter Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-2">
        <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
          <div className="flex items-center gap-2 font-extrabold text-base text-slate-900 dark:text-slate-100">
            <Thermometer className="w-4 h-4 theme-text" />
            <span>محوّل الوحدات الفوري (الحرارة والضغط)</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label
                htmlFor="celsius-input"
                className="text-xs font-bold text-slate-600 dark:text-slate-400 block"
              >
                درجة الحرارة (°C)
              </label>
              <input
                id="celsius-input"
                type="number"
                dir="ltr"
                lang="en"
                value={celsius}
                onChange={(e) => setCelsius(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-950/60 formula-ltr text-sm font-bold"
              />
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300 tabular-nums">
                الكلفن (K): <span className="theme-text formula-ltr">{kelvinVal} K</span>
              </div>
            </div>

            <div className="space-y-2">
              <label
                htmlFor="atm-input"
                className="text-xs font-bold text-slate-600 dark:text-slate-400 block"
              >
                الضغط الجوي (atm)
              </label>
              <input
                id="atm-input"
                type="number"
                dir="ltr"
                lang="en"
                step="0.1"
                value={atm}
                onChange={(e) => setAtm(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-950/60 formula-ltr text-sm font-bold"
              />
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300 tabular-nums">
                <span className="theme-text formula-ltr">{kpaVal} kPa</span> ·{' '}
                <span className="formula-ltr">{mmhgVal} mmHg</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-white/10 space-y-2">
            <div className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
              الكتل الذرية النسبية الجرامية القياسية بالكتاب ({atomicMasses.length} عنصراً · g/mol):
            </div>
            <div className="flex flex-wrap gap-1.5">
              {atomicMasses.map((am) => (
                <span
                  key={am.symbol}
                  className="formula-ltr px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-950/70 text-[11px] font-bold text-slate-800 dark:text-slate-200 tabular-nums"
                >
                  {am.symbol}={am.mass}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-3">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100">
            الثوابت الفيزيائية والكيميائية القياسية (الصف الثاني الثانوي — الترم الأول)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {constants.map((c) => (
              <div
                key={c.id}
                className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-950/60 space-y-1"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-slate-700 dark:text-slate-300">{c.label}</span>
                  <span className="formula-ltr font-black theme-text tabular-nums">{c.value}</span>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">{c.detail}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
