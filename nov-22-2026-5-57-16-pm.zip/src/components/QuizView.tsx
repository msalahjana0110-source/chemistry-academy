import { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Copy,
  Eye,
  EyeOff,
  FileText,
  Flame,
  ListChecks,
  Printer,
  Search,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { ACADEMY_DATA } from '../data/academyData';
import { QUIZ_SUB_TABS, type QuizSubTabId } from '../utils/academyState';
import {
  buildMistakeFromQuizQuestion,
  type MistakeInput,
} from '../utils/mistakesEngine';
import { AdaptiveQuizPanel } from './AdaptiveQuizPanel';
import type { ExplanationJumpTarget } from './MistakesView';
import { WrongAnswerExplainButton } from './WrongAnswerExplainButton';

interface QuizViewProps {
  active: boolean;
  activeSubTab: QuizSubTabId;
  initialLessonId?: string | null;
  initialSubTopicId?: string | null;
  onSwitchSubTab: (sub: QuizSubTabId) => void;
  onFinishExamScore: (pct: number) => void;
  onRecordMistake: (input: MistakeInput) => void;
  onJumpToExplanation: (target: ExplanationJumpTarget) => void;
  onOpenStudioLesson?: (lessonNum: number) => void;
  onNotify: (msg: string) => void;
}

type BankMode = 'mcq' | 'essay' | 'elite';
type BankStatusFilter = 'all' | 'unsolved' | 'wrong' | 'elite';
type PrintSheetMode = 'both' | 'questions-only' | 'answers-only';

const PAGE_SIZE = 20;

export function QuizView({
  active,
  activeSubTab,
  initialLessonId,
  initialSubTopicId,
  onSwitchSubTab,
  onFinishExamScore,
  onRecordMistake,
  onJumpToExplanation,
  onOpenStudioLesson,
  onNotify,
}: QuizViewProps) {
  const {
    heading,
    subheading,
    questions,
    essayQuestions,
    paperTitle,
    paperSubtitle,
  } = ACADEMY_DATA.quiz;
  const allLessons = ACADEMY_DATA.lessons.items;
  const syllabus14Lessons = ACADEMY_DATA.syllabus14.lessons;

  // --- Sub 1: Comprehensive Question Bank (1,560 Questions) ---
  const [bankMode, setBankMode] = useState<BankMode>('mcq');
  const [eliteSubType, setEliteSubType] = useState<'mcq' | 'essay'>('mcq');
  const [bankUnit, setBankUnit] = useState('الكل');
  const [bankLessonId, setBankLessonId] = useState('all');
  const [bankSubTopicId, setBankSubTopicId] = useState('all');
  const [bankDiff, setBankDiff] = useState('الكل');
  const [bankSource, setBankSource] = useState('الكل');
  const [bankStatusFilter, setBankStatusFilter] = useState<BankStatusFilter>('all');
  const [bankSearch, setBankSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const [bankAnswers, setBankAnswers] = useState<Record<string, number>>({});
  const [revealedEssays, setRevealedEssays] = useState<Record<string, boolean>>({});

  // Sync deep-link from LessonsView ("بنك أسئلة الدرس") or SyllabusAtlasView ("أسئلة الدرس 01..14")
  useEffect(() => {
    if (initialSubTopicId) {
      const syl = syllabus14Lessons.find((s) => s.subTopicId === initialSubTopicId);
      setBankUnit(syl ? syl.unitName : 'الكل');
      setBankLessonId('all');
      setBankSubTopicId(initialSubTopicId);
      setBankDiff('الكل');
      setBankSource('الكل');
      setBankStatusFilter('all');
      setBankSearch('');
      setCurrentPage(1);
      return;
    }
    if (!initialLessonId) return;
    const lesson = allLessons.find((l) => l.id === initialLessonId);
    if (lesson) {
      setBankUnit(lesson.unitName);
      setBankLessonId(lesson.id);
      setBankSubTopicId('all');
      setBankDiff('الكل');
      setBankSource('الكل');
      setBankStatusFilter('all');
      setBankSearch('');
      setCurrentPage(1);
    }
  }, [allLessons, initialLessonId, initialSubTopicId, syllabus14Lessons]);

  // --- Sub 3: Print Builder (MCQ + Essay + Separate Sheet Modes) ---
  const [customTitle, setCustomTitle] = useState(paperTitle);
  const [printSheetMode, setPrintSheetMode] = useState<PrintSheetMode>('both');
  const [printUnit, setPrintUnit] = useState('الكل');
  const [printLessonId, setPrintLessonId] = useState('all');
  const [printSource, setPrintSource] = useState('الكل');
  const [printMcqCount, setPrintMcqCount] = useState(10);
  const [printEssayCount, setPrintEssayCount] = useState(3);
  const [printIncludeElite, setPrintIncludeElite] = useState(true);
  const [selectedPrintIds, setSelectedPrintIds] = useState<string[]>(() =>
    questions.slice(0, 8).map((q) => q.id)
  );
  const [selectedPrintEssayIds, setSelectedPrintEssayIds] = useState<string[]>(() =>
    essayQuestions.slice(0, 2).map((q) => q.id)
  );

  const units = useMemo(
    () => ['الكل', ...Array.from(new Set(allLessons.map((l) => l.unitName)))],
    [allLessons]
  );

  const bankLessonOptions = useMemo(() => {
    if (bankUnit === 'الكل') return allLessons;
    return allLessons.filter((l) => l.unitName === bankUnit);
  }, [allLessons, bankUnit]);

  const eliteMcqCount = useMemo(
    () => questions.filter((q) => q.sourceTag !== 'بنك الدرس').length,
    [questions]
  );
  const eliteEssayCount = useMemo(
    () => essayQuestions.filter((q) => q.sourceTag !== 'بنك الدرس').length,
    [essayQuestions]
  );

  const isShowingEssay = bankMode === 'essay' || (bankMode === 'elite' && eliteSubType === 'essay');

  const bankSubTopicOptions = useMemo(() => {
    if (bankUnit === 'الكل') return syllabus14Lessons;
    return syllabus14Lessons.filter((s) => s.unitName === bankUnit);
  }, [bankUnit, syllabus14Lessons]);

  const filteredMcqs = useMemo(() => {
    const qStr = bankSearch.trim().toLowerCase();
    return questions.filter((q) => {
      if (bankMode === 'elite' && q.sourceTag === 'بنك الدرس') return false;
      const uOk = bankUnit === 'الكل' || q.unit === bankUnit;
      const lOk = bankLessonId === 'all' || q.lessonId === bankLessonId;
      const subOk = bankSubTopicId === 'all' || q.subTopicId === bankSubTopicId;
      const dOk = bankDiff === 'الكل' || q.difficulty === bankDiff;
      const sOk = bankSource === 'الكل' || q.sourceTag === bankSource;
      const picked = bankAnswers[q.id];
      const statusOk =
        bankStatusFilter === 'all'
          ? true
          : bankStatusFilter === 'unsolved'
          ? picked === undefined
          : bankStatusFilter === 'wrong'
          ? picked !== undefined && picked !== q.correctIndex
          : q.sourceTag !== 'بنك الدرس';
      const tOk =
        !qStr ||
        q.question.toLowerCase().includes(qStr) ||
        q.explanation.toLowerCase().includes(qStr) ||
        q.subTopicTitle.toLowerCase().includes(qStr);
      return uOk && lOk && subOk && dOk && sOk && statusOk && tOk;
    });
  }, [
    bankAnswers,
    bankDiff,
    bankLessonId,
    bankMode,
    bankSearch,
    bankSource,
    bankStatusFilter,
    bankSubTopicId,
    bankUnit,
    questions,
  ]);

  const filteredEssays = useMemo(() => {
    const qStr = bankSearch.trim().toLowerCase();
    return essayQuestions.filter((q) => {
      if (bankMode === 'elite' && q.sourceTag === 'بنك الدرس') return false;
      const uOk = bankUnit === 'الكل' || q.unit === bankUnit;
      const lOk = bankLessonId === 'all' || q.lessonId === bankLessonId;
      const subOk = bankSubTopicId === 'all' || q.subTopicId === bankSubTopicId;
      const dOk = bankDiff === 'الكل' || q.difficulty === bankDiff;
      const sOk = bankSource === 'الكل' || q.sourceTag === bankSource;
      const statusOk =
        bankStatusFilter === 'all'
          ? true
          : bankStatusFilter === 'unsolved'
          ? !revealedEssays[q.id]
          : bankStatusFilter === 'elite'
          ? q.sourceTag !== 'بنك الدرس'
          : true;
      const tOk =
        !qStr ||
        q.question.toLowerCase().includes(qStr) ||
        q.modelAnswer.toLowerCase().includes(qStr) ||
        q.subTopicTitle.toLowerCase().includes(qStr);
      return uOk && lOk && subOk && dOk && sOk && statusOk && tOk;
    });
  }, [
    bankDiff,
    bankLessonId,
    bankMode,
    bankSearch,
    bankSource,
    bankStatusFilter,
    bankSubTopicId,
    bankUnit,
    essayQuestions,
    revealedEssays,
  ]);

  const totalMatching = isShowingEssay ? filteredEssays.length : filteredMcqs.length;
  const totalPages = Math.max(1, Math.ceil(totalMatching / PAGE_SIZE));
  const safePage = Math.min(currentPage, totalPages);
  const pageStart = (safePage - 1) * PAGE_SIZE;

  const pagedMcqs = useMemo(
    () => filteredMcqs.slice(pageStart, pageStart + PAGE_SIZE),
    [filteredMcqs, pageStart]
  );

  const pagedEssays = useMemo(
    () => filteredEssays.slice(pageStart, pageStart + PAGE_SIZE),
    [filteredEssays, pageStart]
  );

  // Reset to page 1 when filters change
  const resetPage = () => setCurrentPage(1);

  const handleToggleAllPageEssays = (reveal: boolean) => {
    setRevealedEssays((prev) => {
      const next = { ...prev };
      pagedEssays.forEach((e) => {
        next[e.id] = reveal;
      });
      return next;
    });
  };

  // --- Print Builder Filtered Pool ---
  const printLessonOptions = useMemo(() => {
    if (printUnit === 'الكل') return allLessons;
    return allLessons.filter((l) => l.unitName === printUnit);
  }, [allLessons, printUnit]);

  const printPool = useMemo(
    () =>
      questions.filter((q) => {
        const uOk = printUnit === 'الكل' || q.unit === printUnit;
        const lOk = printLessonId === 'all' || q.lessonId === printLessonId;
        const sOk =
          printSource === 'الكل' ||
          (printSource === 'متفوقين' ? q.sourceTag !== 'بنك الدرس' : q.sourceTag === printSource);
        return uOk && lOk && sOk;
      }),
    [printLessonId, printSource, printUnit, questions]
  );

  const printEssayPool = useMemo(
    () =>
      essayQuestions.filter((q) => {
        const uOk = printUnit === 'الكل' || q.unit === printUnit;
        const lOk = printLessonId === 'all' || q.lessonId === printLessonId;
        const sOk =
          printSource === 'الكل' ||
          (printSource === 'متفوقين' ? q.sourceTag !== 'بنك الدرس' : q.sourceTag === printSource);
        return uOk && lOk && sOk;
      }),
    [essayQuestions, printLessonId, printSource, printUnit]
  );

  const printableQuestions = useMemo(
    () => questions.filter((q) => selectedPrintIds.includes(q.id)),
    [questions, selectedPrintIds]
  );

  const printableEssays = useMemo(
    () => essayQuestions.filter((q) => selectedPrintEssayIds.includes(q.id)),
    [essayQuestions, selectedPrintEssayIds]
  );

  const togglePrintQuestion = (id: string) => {
    setSelectedPrintIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleGenerateBalancedPaper = () => {
    const eligibleMcq = printIncludeElite
      ? printPool
      : printPool.filter((q) => q.sourceTag === 'بنك الدرس');
    const eligibleEssay = printIncludeElite
      ? printEssayPool
      : printEssayPool.filter((q) => q.sourceTag === 'بنك الدرس');

    const pickedMcqs = eligibleMcq.slice(0, printMcqCount).map((q) => q.id);
    const pickedEssays = eligibleEssay.slice(0, printEssayCount).map((q) => q.id);

    setSelectedPrintIds(pickedMcqs);
    setSelectedPrintEssayIds(pickedEssays);
    onNotify(
      `تم توليد ورقة امتحان تضم ${pickedMcqs.length} اختيار من متعدد + ${pickedEssays.length} أسئلة مقالية`
    );
  };

  const selectQuickPrintBatch = (mode: 'filtered10' | 'elite10' | 'clear') => {
    if (mode === 'clear') {
      setSelectedPrintIds([]);
      setSelectedPrintEssayIds([]);
      onNotify('تم مسح الأسئلة المختارة من ورقة الطباعة');
      return;
    }
    if (mode === 'elite10') {
      const eliteIds = questions
        .filter((q) => q.sourceTag !== 'بنك الدرس')
        .slice(0, 10)
        .map((q) => q.id);
      const eliteEssayIds = essayQuestions
        .filter((q) => q.sourceTag !== 'بنك الدرس')
        .slice(0, 3)
        .map((q) => q.id);
      setSelectedPrintIds(eliteIds);
      setSelectedPrintEssayIds(eliteEssayIds);
      onNotify('تم اختيار 10 اختيار من متعدد + 3 مسائل من بنك المتفوقين');
      return;
    }
    const batch = printPool.slice(0, 10).map((q) => q.id);
    const essayBatch = printEssayPool.slice(0, 3).map((q) => q.id);
    setSelectedPrintIds(batch);
    setSelectedPrintEssayIds(essayBatch);
    onNotify(`تم اختيار ${batch.length} اختيار من متعدد + ${essayBatch.length} مقالي من التصفية`);
  };

  const handleTriggerPrint = (mode: PrintSheetMode) => {
    setPrintSheetMode(mode);
    window.setTimeout(() => {
      window.print();
    }, 60);
  };

  const copyModelAnswer = (text: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    onNotify('تم نسخ الإجابة النموذجية إلى الحافظة');
  };

  return (
    <section
      id="view-quiz"
      className={`app-view ${
        active ? 'view-reveal' : 'hidden'
      } max-w-[1480px] mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6`}
    >
      <div className="no-print">
        <h2 className="text-2xl sm:text-3xl font-black aurora-text">{heading}</h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{subheading}</p>
      </div>

      {/* التبويبات الفرعية للاختبارات */}
      <div
        id="quizSubTabsBar"
        role="tablist"
        className="flex flex-wrap gap-2 no-print p-1.5 rounded-2xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 w-fit"
      >
        {QUIZ_SUB_TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={activeSubTab === tab.id}
            onClick={() => onSwitchSubTab(tab.id)}
            className={`px-4 py-2 rounded-xl font-bold text-sm transition cursor-pointer ${
              activeSubTab === tab.id
                ? 'theme-grad-btn text-white'
                : 'text-slate-700 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ================================================================= */}
      {/* SUB 1: COMPREHENSIVE QUESTION BANK (798 MCQ + 762 ESSAY/PROBLEMS)  */}
      {/* ================================================================= */}
      <div
        id="quizSub-bank"
        className={`quiz-sub ${activeSubTab === 'bank' ? '' : 'hidden'} space-y-5`}
      >
        {/* Bank Mode Tabs: MCQ vs Essay/Problems vs Elite Toppers */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div
            role="tablist"
            aria-label="نوع الأسئلة في البنك"
            className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-white dark:bg-white/[0.04] border border-slate-200 dark:border-white/10"
          >
            <button
              type="button"
              role="tab"
              aria-selected={bankMode === 'mcq'}
              onClick={() => {
                setBankMode('mcq');
                resetPage();
              }}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-extrabold inline-flex items-center gap-1.5 transition cursor-pointer ${
                bankMode === 'mcq'
                  ? 'theme-grad-btn text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10'
              }`}
            >
              <ListChecks className="w-4 h-4" />
              <span>اختيار من متعدد ({questions.length})</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={bankMode === 'essay'}
              onClick={() => {
                setBankMode('essay');
                resetPage();
              }}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-extrabold inline-flex items-center gap-1.5 transition cursor-pointer ${
                bankMode === 'essay'
                  ? 'theme-grad-btn text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>المقالي والمسائل المحلولة ({essayQuestions.length})</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={bankMode === 'elite'}
              onClick={() => {
                setBankMode('elite');
                resetPage();
              }}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-extrabold inline-flex items-center gap-1.5 transition cursor-pointer ${
                bankMode === 'elite'
                  ? 'bg-gradient-to-l from-rose-500 to-amber-500 text-white shadow-sm'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10'
              }`}
            >
              <Flame className="w-4 h-4" />
              <span>المستويات العليا والمتفوقين ({eliteMcqCount + eliteEssayCount})</span>
            </button>
          </div>

          {bankMode === 'elite' && (
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-rose-500/10 border border-rose-500/25">
              <button
                type="button"
                onClick={() => {
                  setEliteSubType('mcq');
                  resetPage();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer ${
                  eliteSubType === 'mcq'
                    ? 'bg-rose-500 text-white'
                    : 'text-rose-700 dark:text-rose-300'
                }`}
              >
                اختيار من متعدد متفوقين ({eliteMcqCount})
              </button>
              <button
                type="button"
                onClick={() => {
                  setEliteSubType('essay');
                  resetPage();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold cursor-pointer ${
                  eliteSubType === 'essay'
                    ? 'bg-rose-500 text-white'
                    : 'text-rose-700 dark:text-rose-300'
                }`}
              >
                مسائل ومقالي متفوقين ({eliteEssayCount})
              </button>
            </div>
          )}
        </div>

        {/* Filter Bar & Live Search */}
        <div className="p-4 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-3">
          <div
            className={`grid grid-cols-1 sm:grid-cols-2 ${
              bankMode === 'elite' ? 'lg:grid-cols-3' : 'lg:grid-cols-5'
            } gap-2.5`}
          >
            <select
              aria-label="تصفية حسب الباب"
              value={bankUnit}
              onChange={(e) => {
                setBankUnit(e.target.value);
                setBankLessonId('all');
                setBankSubTopicId('all');
                resetPage();
              }}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
            >
              {units.map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>

            <select
              aria-label="تصفية حسب الدرس (منهج الـ 14)"
              value={bankSubTopicId}
              onChange={(e) => {
                setBankSubTopicId(e.target.value);
                setBankLessonId('all');
                resetPage();
              }}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
            >
              <option value="all">
                جميع دروس الـ 14 ({bankSubTopicOptions.length})
              </option>
              {bankSubTopicOptions.map((s) => (
                <option key={s.subTopicId} value={s.subTopicId}>
                  {s.numberLabel}: {s.title}
                </option>
              ))}
            </select>

            <select
              aria-label="تصفية حسب المحور المعمّق"
              value={bankLessonId}
              onChange={(e) => {
                setBankLessonId(e.target.value);
                setBankSubTopicId('all');
                resetPage();
              }}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
            >
              <option value="all">
                كل المحاور الـ {bankLessonOptions.length}
              </option>
              {bankLessonOptions.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.numberLabel}: {l.title}
                </option>
              ))}
            </select>

            {bankMode !== 'elite' && (
              <>
                <select
                  aria-label="تصفية حسب الصعوبة"
                  value={bankDiff}
                  onChange={(e) => {
                    setBankDiff(e.target.value);
                    resetPage();
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
                >
                  <option value="الكل">جميع المستويات</option>
                  <option value="سهل">سهل</option>
                  <option value="متوسط">متوسط</option>
                  <option value="متقدم">متقدم</option>
                </select>

                <select
                  aria-label="تصفية حسب مصدر السؤال"
                  value={bankSource}
                  onChange={(e) => {
                    setBankSource(e.target.value);
                    resetPage();
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
                >
                  <option value="الكل">جميع المصادر</option>
                  <option value="بنك الدرس">بنك الدرس الأساسي</option>
                  <option value="استنتاجي فائق">استنتاجي فائق (60 سؤالاً)</option>
                  <option value="متفوقين ومستويات عليا">متفوقين ومستويات عليا (100 سؤال)</option>
                </select>
              </>
            )}
          </div>

          {/* Quick Status Chips */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
              حالة الحل:
            </span>
            {(
              [
                { id: 'all', label: 'الكل' },
                { id: 'unsolved', label: 'لم تُحل' },
                { id: 'wrong', label: 'الأخطاء في هذه الجلسة' },
                { id: 'elite', label: 'متفوقين' },
              ] as Array<{ id: BankStatusFilter; label: string }>
            ).map((chip) => (
              <button
                key={chip.id}
                type="button"
                aria-pressed={bankStatusFilter === chip.id}
                onClick={() => {
                  setBankStatusFilter(chip.id);
                  resetPage();
                }}
                className={`px-3 py-1 rounded-lg border text-xs font-bold transition cursor-pointer ${
                  bankStatusFilter === chip.id
                    ? 'theme-border theme-bg-soft theme-text'
                    : 'border-slate-200 dark:border-white/15 text-slate-600 dark:text-slate-300 hover:border-slate-400'
                }`}
              >
                {chip.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2.5">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={bankSearch}
                onChange={(e) => {
                  setBankSearch(e.target.value);
                  resetPage();
                }}
                placeholder="ابحث داخل الأسئلة والمسائل بالكلمات المفتاحية أو الرموز الكيميائية..."
                aria-label="ابحث داخل بنك الأسئلة"
                className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs sm:text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
              />
            </div>

            {(bankUnit !== 'الكل' ||
              bankLessonId !== 'all' ||
              bankSubTopicId !== 'all' ||
              bankDiff !== 'الكل' ||
              bankSource !== 'الكل' ||
              bankStatusFilter !== 'all' ||
              bankSearch.trim()) && (
              <button
                type="button"
                onClick={() => {
                  setBankUnit('الكل');
                  setBankLessonId('all');
                  setBankSubTopicId('all');
                  setBankDiff('الكل');
                  setBankSource('الكل');
                  setBankStatusFilter('all');
                  setBankSearch('');
                  resetPage();
                }}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
              >
                إعادة ضبط الفلاتر
              </button>
            )}

            {isShowingEssay && pagedEssays.length > 0 && (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleToggleAllPageEssays(true)}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold inline-flex items-center gap-1 hover:border-emerald-500/50 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5 theme-text" />
                  <span>إظهار إجابات الصفحة</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleAllPageEssays(false)}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold inline-flex items-center gap-1 hover:border-slate-400 cursor-pointer"
                >
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>إخفاء</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Summary & Top Pagination Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs font-bold text-slate-500 dark:text-slate-400">
          <span className="tabular-nums">
            إجمالي المطابق: <span className="theme-text font-black">{totalMatching}</span>{' '}
            {isShowingEssay ? 'سؤالاً مقالياً / مسألة' : 'سؤال اختيار من متعدد'} · عرض{' '}
            {totalMatching === 0 ? 0 : pageStart + 1}–{Math.min(pageStart + PAGE_SIZE, totalMatching)}
          </span>
          {totalPages > 1 && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 disabled:opacity-40 inline-flex items-center gap-1 cursor-pointer"
              >
                <ChevronRight className="w-3.5 h-3.5" />
                <span>السابقة</span>
              </button>
              <span className="tabular-nums px-2">
                صفحة {safePage} / {totalPages}
              </span>
              <button
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 disabled:opacity-40 inline-flex items-center gap-1 cursor-pointer"
              >
                <span>التالية</span>
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Empty State */}
        {totalMatching === 0 ? (
          <div className="p-10 rounded-2xl border border-dashed border-slate-300 dark:border-white/15 text-center text-sm font-bold text-slate-500">
            لا توجد أسئلة مطابقة للتصفية أو عبارة البحث الحالية.
          </div>
        ) : !isShowingEssay ? (
          /* MCQ CARDS */
          <div className="space-y-4">
            {pagedMcqs.map((q, idx) => {
              const picked = bankAnswers[q.id];
              const answered = picked !== undefined;
              const globalNum = pageStart + idx + 1;
              return (
                <div
                  key={q.id}
                  className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded-md theme-bg-soft theme-text font-extrabold tabular-nums">
                        سؤال {globalNum}
                      </span>
                      <span>{q.unit}</span>
                      <span aria-hidden="true">·</span>
                      <span>{q.subTopicTitle}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {q.sourceTag !== 'بنك الدرس' && (
                        <span className="px-2.5 py-0.5 rounded-md bg-rose-500/15 text-rose-700 dark:text-rose-300 font-extrabold inline-flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          <span>{q.sourceTag}</span>
                        </span>
                      )}
                      <span className="px-2 py-0.5 rounded-md border border-slate-200 dark:border-white/15">
                        مستوى {q.difficulty}
                      </span>
                    </div>
                  </div>

                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-slate-100 leading-relaxed whitespace-pre-line">
                    {q.question}
                  </h3>

                  {q.formula && (
                    <code className="inline-block formula-ltr px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-950/70 text-xs font-bold theme-text">
                      {q.formula}
                    </code>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {q.options.map((opt, optIdx) => {
                      const isRight = optIdx === q.correctIndex;
                      const isPicked = picked === optIdx;
                      let cls =
                        'border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:border-slate-400 dark:hover:border-white/30';
                      if (answered && isRight) {
                        cls =
                          'border-emerald-500 bg-emerald-500/15 text-emerald-800 dark:text-emerald-200';
                      } else if (answered && isPicked && !isRight) {
                        cls = 'border-rose-500 bg-rose-500/15 text-rose-800 dark:text-rose-200';
                      }
                      const isWrongPicked = answered && isPicked && !isRight;
                      return (
                        <div key={optIdx} className="flex items-stretch gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setBankAnswers((prev) => ({ ...prev, [q.id]: optIdx }));
                              if (optIdx !== q.correctIndex) {
                                onRecordMistake(
                                  buildMistakeFromQuizQuestion(q, optIdx, 'question-bank')
                                );
                              }
                            }}
                            className={`flex-1 min-w-0 p-3.5 rounded-xl border text-right text-xs sm:text-sm font-bold flex items-center justify-between gap-2 transition cursor-pointer ${cls}`}
                          >
                            <span>
                              <span className="opacity-65 ml-1.5">
                                {['أ', 'ب', 'ج', 'د'][optIdx]})
                              </span>
                              {opt}
                            </span>
                            {answered && isRight && <CheckCircle2 className="w-4 h-4 shrink-0" />}
                            {isWrongPicked && <XCircle className="w-4 h-4 shrink-0" />}
                          </button>
                          {isWrongPicked && (
                            <WrongAnswerExplainButton
                              questionId={q.id}
                              questionText={q.question}
                              lessonId={q.lessonId}
                              sectionIndex={q.sectionIndex}
                              onJumpToExplanation={onJumpToExplanation}
                              className="px-2.5"
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {answered && (
                    <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950/60 border border-slate-200 dark:border-white/10 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      <span className="font-extrabold theme-text ml-1.5">التفسير العلمي:</span>
                      {q.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          /* ESSAY & SOLVED PROBLEMS CARDS */
          <div className="space-y-4">
            {pagedEssays.map((q, idx) => {
              const isOpen = Boolean(revealedEssays[q.id]);
              const globalNum = pageStart + idx + 1;
              return (
                <div
                  key={q.id}
                  className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded-md theme-bg-soft theme-text font-extrabold tabular-nums">
                        مسألة / مقالي #{globalNum}
                      </span>
                      <span>{q.unit}</span>
                      <span aria-hidden="true">·</span>
                      <span>{q.subTopicTitle}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {q.sourceTag !== 'بنك الدرس' && (
                        <span className="px-2.5 py-0.5 rounded-md bg-rose-500/15 text-rose-700 dark:text-rose-300 font-extrabold inline-flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          <span>{q.sourceTag}</span>
                        </span>
                      )}
                      <span className="px-2 py-0.5 rounded-md border border-slate-200 dark:border-white/15">
                        مستوى {q.difficulty}
                      </span>
                    </div>
                  </div>

                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-slate-100 leading-relaxed whitespace-pre-line">
                    {q.question}
                  </h3>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      aria-expanded={isOpen}
                      onClick={() =>
                        setRevealedEssays((prev) => ({ ...prev, [q.id]: !prev[q.id] }))
                      }
                      className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold inline-flex items-center gap-1.5 transition cursor-pointer ${
                        isOpen
                          ? 'border border-slate-200 dark:border-white/15 text-slate-700 dark:text-slate-200'
                          : 'theme-grad-btn text-white'
                      }`}
                    >
                      {isOpen ? (
                        <>
                          <ChevronUp className="w-4 h-4" />
                          <span>إخفاء الإجابة النموذجية</span>
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-4 h-4" />
                          <span>عرض الإجابة النموذجية وخطوات الحل</span>
                        </>
                      )}
                    </button>

                    {isOpen && (
                      <button
                        type="button"
                        onClick={() => copyModelAnswer(q.modelAnswer)}
                        className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold inline-flex items-center gap-1.5 hover:border-slate-400 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5 theme-text" />
                        <span>نسخ الحل</span>
                      </button>
                    )}
                  </div>

                  {isOpen && (
                    <div className="p-4 sm:p-5 rounded-xl bg-emerald-500/[0.06] border border-emerald-500/30 text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line">
                      <span className="font-extrabold text-emerald-700 dark:text-emerald-300 block mb-1.5">
                        الإجابة النموذجية وخطوات الحل:
                      </span>
                      {q.modelAnswer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Bottom Pagination */}
        {totalPages > 1 && (
          <div className="flex flex-wrap items-center justify-center gap-2 pt-3">
            <button
              type="button"
              disabled={safePage <= 1}
              onClick={() => {
                setCurrentPage((p) => Math.max(1, p - 1));
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-xs font-bold disabled:opacity-40 inline-flex items-center gap-1 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
              <span>الصفحة السابقة</span>
            </button>
            <span className="px-4 py-2 rounded-xl theme-bg-soft theme-text text-xs font-black tabular-nums">
              صفحة {safePage} من {totalPages}
            </span>
            <button
              type="button"
              disabled={safePage >= totalPages}
              onClick={() => {
                setCurrentPage((p) => Math.min(totalPages, p + 1));
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-xs font-bold disabled:opacity-40 inline-flex items-center gap-1 cursor-pointer"
            >
              <span>الصفحة التالية</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* ================================================================= */}
      {/* SUB 2: ADAPTIVE TIMED EXAM SIMULATOR & ANALYTICS                   */}
      {/* ================================================================= */}
      <div
        id="quizSub-adaptive"
        className={`quiz-sub ${
          activeSubTab === 'adaptive' ? '' : 'hidden'
        } glass-panel p-5 sm:p-8 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04]`}
      >
        <AdaptiveQuizPanel
          onFinishExamScore={onFinishExamScore}
          onRecordMistake={onRecordMistake}
          onJumpToExplanation={onJumpToExplanation}
          onOpenStudioLesson={onOpenStudioLesson}
          onNotify={onNotify}
        />
      </div>

      {/* ================================================================= */}
      {/* SUB 3: CUSTOM PRINTABLE EXAM PAPER BUILDER (MCQ + ESSAY + KEYS)    */}
      {/* ================================================================= */}
      <div
        id="quizSub-print"
        className={`quiz-sub ${activeSubTab === 'print' ? '' : 'hidden'} space-y-5`}
      >
        <div
          id="printBuilderControls"
          className="no-print p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4"
        >
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="flex-1 min-w-[240px] space-y-1.5">
              <label htmlFor="print-title-input" className="text-xs font-bold block">
                عنوان ورقة الامتحان
              </label>
              <input
                id="print-title-input"
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-950/60 text-sm font-bold"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleTriggerPrint('questions-only')}
                className="px-4 py-2.5 rounded-xl border theme-border theme-bg-soft theme-text font-extrabold text-xs sm:text-sm inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة ورقة الأسئلة فقط</span>
              </button>
              <button
                type="button"
                onClick={() => handleTriggerPrint('answers-only')}
                className="px-4 py-2.5 rounded-xl border border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-extrabold text-xs sm:text-sm inline-flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>طباعة نموذج الإجابة فقط</span>
              </button>
              <button
                type="button"
                onClick={() => handleTriggerPrint('both')}
                className="theme-grad-btn px-4 py-2.5 rounded-xl text-white font-bold text-xs sm:text-sm inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة الورقة + النموذج</span>
              </button>
            </div>
          </div>

          {/* Balanced Exam Paper Generator (MCQ + Essay + Elite Toggle) */}
          <div className="pt-3 border-t border-slate-200 dark:border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
            <div className="space-y-1">
              <label htmlFor="print-mcq-count" className="text-[11px] font-bold text-slate-500">
                عدد أسئلة الاختياري
              </label>
              <select
                id="print-mcq-count"
                value={printMcqCount}
                onChange={(e) => setPrintMcqCount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
              >
                {[5, 8, 10, 15, 20].map((n) => (
                  <option key={n} value={n}>
                    {n} أسئلة اختياري
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label htmlFor="print-essay-count" className="text-[11px] font-bold text-slate-500">
                عدد الأسئلة المقالية / المسائل
              </label>
              <select
                id="print-essay-count"
                value={printEssayCount}
                onChange={(e) => setPrintEssayCount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
              >
                {[0, 2, 3, 5, 8].map((n) => (
                  <option key={n} value={n}>
                    {n === 0 ? 'بدون مقالي' : `${n} أسئلة مقالية`}
                  </option>
                ))}
              </select>
            </div>

            <label className="inline-flex items-center gap-2 text-xs font-bold cursor-pointer py-2">
              <input
                type="checkbox"
                checked={printIncludeElite}
                onChange={(e) => setPrintIncludeElite(e.target.checked)}
                className="accent-emerald-500 w-4 h-4"
              />
              <span>تضمين أسئلة المتفوقين</span>
            </label>

            <div className="sm:col-span-2 flex flex-wrap gap-2 justify-end">
              <button
                type="button"
                onClick={handleGenerateBalancedPaper}
                className="theme-grad-btn px-4 py-2 rounded-xl text-white text-xs font-extrabold cursor-pointer"
              >
                توليد الورقة تلقائياً
              </button>
              <button
                type="button"
                onClick={() => selectQuickPrintBatch('elite10')}
                className="px-3 py-2 rounded-xl border border-rose-500/35 bg-rose-500/10 text-rose-700 dark:text-rose-300 text-xs font-extrabold cursor-pointer"
              >
                نموذج متفوقين (10+3)
              </button>
              <button
                type="button"
                onClick={() => selectQuickPrintBatch('clear')}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                مسح ({selectedPrintIds.length + selectedPrintEssayIds.length})
              </button>
            </div>
          </div>

          {/* Filter by Unit / Lesson / Source */}
          <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex flex-wrap gap-2">
              <select
                aria-label="تصفية أسئلة الطباعة حسب الباب"
                value={printUnit}
                onChange={(e) => {
                  setPrintUnit(e.target.value);
                  setPrintLessonId('all');
                }}
                className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
              >
                {units.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
              <select
                aria-label="تصفية أسئلة الطباعة حسب الدرس"
                value={printLessonId}
                onChange={(e) => setPrintLessonId(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer max-w-[240px]"
              >
                <option value="all">جميع الدروس</option>
                {printLessonOptions.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.numberLabel}: {l.title}
                  </option>
                ))}
              </select>
              <select
                aria-label="تصفية أسئلة الطباعة حسب المصدر"
                value={printSource}
                onChange={(e) => setPrintSource(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer"
              >
                <option value="الكل">كل المصادر ({questions.length})</option>
                <option value="بنك الدرس">بنك الدروس الأساسي</option>
                <option value="متفوقين">المستويات العليا والمتفوقين</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 text-xs font-bold">
              <span className="text-slate-500">معاينة العرض:</span>
              {(
                [
                  { id: 'both', label: 'الورقة + الإجابات' },
                  { id: 'questions-only', label: 'الأسئلة فقط' },
                  { id: 'answers-only', label: 'نموذج الإجابة فقط' },
                ] as Array<{ id: PrintSheetMode; label: string }>
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPrintSheetMode(m.id)}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold cursor-pointer ${
                    printSheetMode === m.id
                      ? 'theme-border theme-bg-soft theme-text'
                      : 'border-slate-200 dark:border-white/15 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto custom-scrollbar pt-1">
            {printPool.slice(0, 60).map((q, idx) => {
              const checked = selectedPrintIds.includes(q.id);
              return (
                <button
                  key={q.id}
                  type="button"
                  title={q.question}
                  onClick={() => togglePrintQuestion(q.id)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-bold cursor-pointer tabular-nums ${
                    checked
                      ? 'theme-border theme-bg-soft theme-text'
                      : 'border-slate-200 dark:border-white/15 text-slate-500'
                  }`}
                >
                  س{idx + 1}
                </button>
              );
            })}
            {printPool.length > 60 && (
              <span className="text-[11px] font-bold text-slate-400 self-center px-2">
                +{printPool.length - 60} سؤال آخر (صفِّ حسب الدرس لعرضها)
              </span>
            )}
          </div>
        </div>

        <div
          id="printableExamPaper"
          className="p-8 sm:p-10 rounded-2xl border border-slate-200 dark:border-white/15 bg-white text-slate-900 shadow-lg"
        >
          {/* Official Header with Mr. Salah Eid & Mohamed Salah credits */}
          <div className="border-b-2 border-slate-900 pb-4 mb-6 text-center space-y-1.5">
            <div className="flex flex-wrap items-center justify-between text-[11px] font-extrabold text-slate-600 pb-1">
              <span>إعداد: مستر صلاح عيد · 01007235605</span>
              <span>أكاديمية الكيمياء — الصف الثاني الثانوي (ترم 1)</span>
              <span>تصميم: محمد صلاح · 01113223341</span>
            </div>
            <h3 className="text-2xl font-black">
              {printSheetMode === 'answers-only'
                ? `نموذج الإجابة الرسمي — ${customTitle}`
                : customTitle}
            </h3>
            <p className="text-sm text-slate-600">{paperSubtitle}</p>
            {printSheetMode !== 'answers-only' && (
              <div className="flex flex-wrap justify-between text-xs font-bold text-slate-700 pt-3">
                <span>اسم الطالب: ....................................................</span>
                <span>التاريخ: .... / .... / 2026</span>
                <span>
                  الدرجة: ...... / {printableQuestions.length + printableEssays.length * 2}
                </span>
              </div>
            )}
          </div>

          {printableQuestions.length === 0 && printableEssays.length === 0 ? (
            <p className="text-center text-sm text-slate-500 py-8">
              اختر سؤالاً واحداً على الأقل أو اضغط «توليد الورقة تلقائياً» لبناء ورقة الامتحان.
            </p>
          ) : (
            <>
              {/* Question Sheet Section */}
              {printSheetMode !== 'answers-only' && (
                <div className="space-y-6">
                  {printableQuestions.length > 0 && (
                    <div className="space-y-4">
                      <h4 className="font-black text-base border-b border-slate-300 pb-1.5">
                        أولاً: أسئلة الاختيار من متعدد ({printableQuestions.length} أسئلة)
                      </h4>
                      {printableQuestions.map((q, idx) => (
                        <div
                          key={q.id}
                          className="print-avoid-break pb-4 border-b border-slate-200 space-y-2"
                        >
                          <div className="font-extrabold text-sm sm:text-base whitespace-pre-line">
                            {idx + 1}) {q.question}
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs sm:text-sm text-slate-800 pr-4">
                            {q.options.map((opt, optIdx) => (
                              <div key={optIdx}>
                                ({['أ', 'ب', 'ج', 'د'][optIdx]}) {opt}
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {printableEssays.length > 0 && (
                    <div className="space-y-4 pt-2">
                      <h4 className="font-black text-base border-b border-slate-300 pb-1.5">
                        ثانياً: الأسئلة المقالية والمسائل الكيميائية ({printableEssays.length} أسئلة)
                      </h4>
                      {printableEssays.map((q, idx) => (
                        <div
                          key={q.id}
                          className="print-avoid-break pb-5 border-b border-slate-200 space-y-3"
                        >
                          <div className="font-extrabold text-sm sm:text-base whitespace-pre-line">
                            {idx + 1}) {q.question}
                          </div>
                          <div className="space-y-3 pt-1">
                            <div className="border-b border-dotted border-slate-400 h-5" />
                            <div className="border-b border-dotted border-slate-400 h-5" />
                            <div className="border-b border-dotted border-slate-400 h-5" />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Model Answer Sheet Section */}
              {printSheetMode !== 'questions-only' && (
                <div
                  className={`${
                    printSheetMode === 'both'
                      ? 'print-page-break mt-8 pt-6 border-t-2 border-dashed border-slate-400'
                      : ''
                  } space-y-5`}
                >
                  <h4 className="font-black text-lg text-center">
                    نموذج الإجابة والتفسير العلمي — إعداد مستر صلاح عيد
                  </h4>

                  {printableQuestions.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      {printableQuestions.map((q, idx) => (
                        <div key={q.id} className="p-3 rounded-lg bg-slate-100 print-avoid-break">
                          <span className="font-black">اختياري س{idx + 1}: </span>
                          <span className="font-bold text-emerald-700">
                            {q.options[q.correctIndex]}
                          </span>{' '}
                          — {q.explanation}
                        </div>
                      ))}
                    </div>
                  )}

                  {printableEssays.length > 0 && (
                    <div className="space-y-3">
                      <h5 className="font-black text-sm">إجابات الأسئلة المقالية والمسائل:</h5>
                      {printableEssays.map((q, idx) => (
                        <div
                          key={q.id}
                          className="p-3.5 rounded-lg bg-slate-100 text-xs space-y-1 print-avoid-break"
                        >
                          <div className="font-black">مقالي س{idx + 1}: {q.question}</div>
                          <div className="text-emerald-800 whitespace-pre-line font-semibold">
                            {q.modelAnswer}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </section>
  );
}
