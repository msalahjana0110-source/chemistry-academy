import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import {
  Check,
  Contrast,
  Eye,
  LayoutGrid,
  Monitor,
  Moon,
  Palette,
  RotateCcw,
  SlidersHorizontal,
  Sparkles,
  Sun,
  Type,
  Wind,
  X,
} from 'lucide-react';
import {
  CONTAINER_WIDTH_OPTIONS,
  DENSITY_OPTIONS,
  FONT_SCALE_OPTIONS,
  PALETTE_SWATCHES,
  type ContainerWidthMode,
  type FontScaleOption,
  type LayoutDensity,
  type SiteSettings,
} from '../utils/siteSettings';
import type { PaletteId } from '../utils/academyState';

interface SiteSettingsMenuProps {
  open: boolean;
  settings: SiteSettings;
  completedLessonsCount: number;
  totalLessonsCount: number;
  unresolvedMistakesCount: number;
  savedCertificatesCount: number;
  onToggleOpen: () => void;
  onClose: () => void;
  onUpdateSettings: (patch: Partial<SiteSettings>) => void;
  onSelectPalette: (palette: PaletteId) => void;
  onResetSettings: () => void;
  onReopenSplash: () => void;
}

export function SiteSettingsMenu({
  open,
  settings,
  completedLessonsCount,
  totalLessonsCount,
  unresolvedMistakesCount,
  savedCertificatesCount,
  onToggleOpen,
  onClose,
  onUpdateSettings,
  onSelectPalette,
  onResetSettings,
  onReopenSplash,
}: SiteSettingsMenuProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const dialogRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    const onPointerDown = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        containerRef.current &&
        !containerRef.current.contains(target) &&
        (!dialogRef.current || !dialogRef.current.contains(target))
      ) {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('mousedown', onPointerDown);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('mousedown', onPointerDown);
    };
  }, [open, onClose]);

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={onToggleOpen}
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-label="إعدادات وتنسيق الموقع"
        title="إعدادات وتنسيق الموقع"
        className={`relative min-h-[40px] min-w-[40px] sm:min-h-[38px] sm:min-w-[38px] p-2 rounded-xl border transition-all duration-200 flex items-center justify-center cursor-pointer ${
          open
            ? 'theme-border theme-bg-soft theme-text shadow-sm'
            : 'border-slate-200 dark:border-white/15 bg-slate-100/80 dark:bg-white/5 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-white/10'
        }`}
      >
        <SlidersHorizontal className="w-4 h-4" />
      </button>

      {open &&
        typeof document !== 'undefined' &&
        createPortal(
          <>
            {/* Mobile Backdrop Scrim */}
            <div
              aria-hidden="true"
              onClick={onClose}
              className="sm:hidden fixed inset-0 z-[70] bg-black/55 backdrop-blur-xs"
            />

            <div
              ref={dialogRef}
              role="dialog"
              aria-label="لوحة إعدادات وتنسيق الموقع"
              className="fixed inset-x-3 bottom-3 sm:inset-auto sm:top-[4.5rem] sm:left-4 z-[80] w-auto sm:w-[376px] max-h-[82vh] sm:max-h-[calc(100vh-5.5rem)] overflow-y-auto custom-scrollbar rounded-3xl sm:rounded-2xl border border-slate-200 dark:border-white/15 bg-white/95 dark:bg-slate-950/95 glass-panel shadow-2xl p-4 sm:p-5 space-y-5 text-right"
            >
            {/* Mobile Drag Handle */}
            <div className="sm:hidden w-10 h-1 rounded-full bg-slate-300 dark:bg-slate-700 mx-auto -mt-1 mb-1" />

            {/* Header */}
            <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-white/10">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-xl theme-bg-soft theme-text flex items-center justify-center shrink-0">
                  <SlidersHorizontal className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
                    إعدادات وتنسيق الموقع
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    خصّص الألوان والحجم والمؤثرات للهاتف والكمبيوتر
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="إغلاق لوحة الإعدادات"
                className="min-h-[36px] min-w-[36px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* 1. Light / Dark Mode */}
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-700 dark:text-slate-200">
                {settings.isDark ? <Moon className="w-3.5 h-3.5 theme-text" /> : <Sun className="w-3.5 h-3.5 theme-text" />}
                <span>وضع الإضاءة</span>
              </div>
              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-100 dark:bg-white/5 border border-slate-200/80 dark:border-white/10">
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ isDark: true })}
                  aria-pressed={settings.isDark}
                  className={`py-2 px-3 rounded-lg text-xs font-bold inline-flex items-center justify-center gap-1.5 transition cursor-pointer ${
                    settings.isDark
                      ? 'theme-grad-btn text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-white/5'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5" />
                  <span>الوضع الداكن</span>
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateSettings({ isDark: false })}
                  aria-pressed={!settings.isDark}
                  className={`py-2 px-3 rounded-lg text-xs font-bold inline-flex items-center justify-center gap-1.5 transition cursor-pointer ${
                    !settings.isDark
                      ? 'theme-grad-btn text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-white/5'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5" />
                  <span>الوضع النهاري</span>
                </button>
              </div>
            </div>

            {/* 2. 6 Color Palettes */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-extrabold text-slate-700 dark:text-slate-200">
                <span className="inline-flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 theme-text" />
                  <span>لوحة الألوان</span>
                </span>
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                  {PALETTE_SWATCHES.find((p) => p.id === settings.palette)?.labelAr}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {PALETTE_SWATCHES.map((swatch) => {
                  const selected = settings.palette === swatch.id;
                  return (
                    <button
                      key={swatch.id}
                      type="button"
                      onClick={() => onSelectPalette(swatch.id)}
                      aria-pressed={selected}
                      className={`p-2 rounded-xl border text-right transition flex items-center gap-2 cursor-pointer ${
                        selected
                          ? 'theme-border theme-bg-soft'
                          : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.03] hover:border-slate-300 dark:hover:border-white/25'
                      }`}
                    >
                      <span
                        className="w-5 h-5 rounded-lg shrink-0 flex items-center justify-center shadow-sm"
                        style={{
                          background: `linear-gradient(135deg, ${swatch.primary}, ${swatch.secondary})`,
                        }}
                      >
                        {selected && <Check className="w-3 h-3 text-white stroke-[3]" />}
                      </span>
                      <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200 truncate">
                        {swatch.labelAr}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Font Size Scale */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-extrabold text-slate-700 dark:text-slate-200">
                <span className="inline-flex items-center gap-1.5">
                  <Type className="w-3.5 h-3.5 theme-text" />
                  <span>حجم الخط والقراءة</span>
                </span>
                <span className="formula-ltr text-[11px] font-bold theme-text tabular-nums">
                  {settings.fontScale}%
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {FONT_SCALE_OPTIONS.map((opt) => {
                  const active = settings.fontScale === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => onUpdateSettings({ fontScale: opt.value as FontScaleOption })}
                      aria-pressed={active}
                      className={`py-2 px-1.5 rounded-xl border text-[11px] font-bold transition cursor-pointer ${
                        active
                          ? 'theme-border theme-bg-soft theme-text'
                          : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.03] text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Responsive Density Mode (Phone / Desktop) */}
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-700 dark:text-slate-200">
                <LayoutGrid className="w-3.5 h-3.5 theme-text" />
                <span>تناسب الحجم (هاتف / كمبيوتر)</span>
              </div>
              <div className="grid grid-cols-1 gap-1.5">
                {DENSITY_OPTIONS.map((opt) => {
                  const active = settings.density === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => onUpdateSettings({ density: opt.value as LayoutDensity })}
                      aria-pressed={active}
                      className={`w-full px-3 py-2 rounded-xl border text-right transition flex items-center justify-between gap-2 cursor-pointer ${
                        active
                          ? 'theme-border theme-bg-soft'
                          : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.03] hover:border-slate-300 dark:hover:border-white/25'
                      }`}
                    >
                      <div>
                        <div className={`text-xs font-bold ${active ? 'theme-text' : 'text-slate-800 dark:text-slate-100'}`}>
                          {opt.label}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {opt.hint}
                        </div>
                      </div>
                      {active && <Check className="w-4 h-4 theme-text shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 5. Desktop Container Width */}
            <div className="hidden sm:block space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-700 dark:text-slate-200">
                <Monitor className="w-3.5 h-3.5 theme-text" />
                <span>عرض الصفحة على الكمبيوتر</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {CONTAINER_WIDTH_OPTIONS.map((opt) => {
                  const active = settings.containerWidth === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() =>
                        onUpdateSettings({ containerWidth: opt.value as ContainerWidthMode })
                      }
                      aria-pressed={active}
                      className={`py-2 px-2 rounded-xl border text-[11px] font-bold transition cursor-pointer ${
                        active
                          ? 'theme-border theme-bg-soft theme-text'
                          : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.03] text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 6. Visual & Motion Toggles */}
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-700 dark:text-slate-200">
                <Sparkles className="w-3.5 h-3.5 theme-text" />
                <span>المؤثرات البصرية والوضوح</span>
              </div>
              <div className="space-y-1.5">
                {[
                  {
                    key: 'visualEffects' as const,
                    label: 'المؤثرات البصرية والخلفية الكيميائية',
                    icon: Sparkles,
                    value: settings.visualEffects,
                  },
                  {
                    key: 'showScrollProgress' as const,
                    label: 'شريط التقدم العلوي أثناء القراءة',
                    icon: Eye,
                    value: settings.showScrollProgress,
                  },
                  {
                    key: 'reducedMotion' as const,
                    label: 'تقليل الحركة (وضع التركيز الهادئ)',
                    icon: Wind,
                    value: settings.reducedMotion,
                  },
                  {
                    key: 'highContrast' as const,
                    label: 'تعزيز التباين لوضوح النصوص والحدود',
                    icon: Contrast,
                    value: settings.highContrast,
                  },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      role="switch"
                      aria-checked={item.value}
                      onClick={() => onUpdateSettings({ [item.key]: !item.value })}
                      className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50/80 dark:bg-white/[0.03] hover:bg-slate-100 dark:hover:bg-white/[0.06] flex items-center justify-between gap-2 transition cursor-pointer"
                    >
                      <span className="inline-flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                        <Icon className="w-3.5 h-3.5 theme-text shrink-0" />
                        <span>{item.label}</span>
                      </span>
                      <span
                        className={`w-9 h-5 rounded-full p-0.5 transition-colors flex items-center shrink-0 ${
                          item.value
                            ? 'bg-emerald-500 justify-start'
                            : 'bg-slate-300 dark:bg-slate-700 justify-end'
                        }`}
                      >
                        <span className="w-4 h-4 rounded-full bg-white shadow-sm block" />
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 7. Quick Session Summary & Utility Actions */}
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 space-y-2.5">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 dark:text-slate-400 tabular-nums">
                <span>الدروس: {completedLessonsCount}/{totalLessonsCount}</span>
                <span>·</span>
                <span>أخطاء معلّقة: {unresolvedMistakesCount}</span>
                <span>·</span>
                <span>الشهادات: {savedCertificatesCount}</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onResetSettings();
                  }}
                  className="py-2 px-3 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-xs font-bold inline-flex items-center justify-center gap-1.5 text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>إعدادات افتراضية</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onReopenSplash();
                  }}
                  className="py-2 px-3 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-xs font-bold inline-flex items-center justify-center gap-1.5 text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 theme-text" />
                  <span>الشاشة الافتتاحية</span>
                </button>
              </div>
            </div>
          </div>
          </>,
          document.body
        )}
    </div>
  );
}
