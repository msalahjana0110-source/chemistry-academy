import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Pause,
  Play,
  RefreshCw,
  RotateCcw,
  Shuffle,
  Sparkles,
  Timer,
} from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { ACADEMY_DATA, type UnitId } from '../data/academyData';
import {
  DEFAULT_LESSON_REVIEW_SECONDS,
  LESSON_TIMER_PRESETS,
  createInitialLessonTimers,
  ensureLessonTimer,
  formatCountdownClock,
  getCountdownProgress,
  pauseAllLessonCountdowns,
  resetLessonCountdown,
  setLessonDurationPreset,
  tickLessonCountdown,
  toggleLessonCountdown,
  type LessonTimerMap,
} from '../utils/studioLessonTimer';

interface StudioViewProps {
  active: boolean;
  initialLessonNum?: number | null;
  masteredIds: string[];
  onToggleMastered: (id: string) => void;
  onNotify: (msg: string) => void;
}

const STUDIO_UNITS: ReadonlyArray<{ id: 'all' | UnitId; label: string }> = [
  { id: 'all', label: 'جميع الأبواب' },
  { id: 'unit1', label: 'الباب الأول: الحساب الكيميائي' },
  { id: 'unit2', label: 'الباب الثاني: بنية الذرة' },
  { id: 'unit3', label: 'الباب الثالث: الجدول الدوري' },
];

const RING_RADIUS = 44;
const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

export function StudioView({
  active,
  initialLessonNum,
  masteredIds,
  onToggleMastered,
  onNotify,
}: StudioViewProps) {
  const prefersReducedMotion = useReducedMotion();
  const { heading, subheading, flashcards } = ACADEMY_DATA.studio;
  const [unitFilter, setUnitFilter] = useState<'all' | UnitId>('all');
  const [lessonFilter, setLessonFilter] = useState<number | 'all'>('all');
  const [filterMode, setFilterMode] = useState<'all' | 'review'>('all');
  const [deckOrder, setDeckOrder] = useState<string[]>(() => flashcards.map((f) => f.id));
  const [currentIdx, setCurrentIdx] = useState(0);
  const [slideDir, setSlideDir] = useState<1 | -1>(1);
  const [flipped, setFlipped] = useState(false);
  const [flipCount, setFlipCount] = useState(0);

  // Per-lesson independent review countdown timers (lessons 1..14)
  const allLessonNums = useMemo(
    () => Array.from(new Set(flashcards.map((c) => c.lessonNum))).sort((a, b) => a - b),
    [flashcards]
  );

  const [lessonTimers, setLessonTimers] = useState<LessonTimerMap>(() =>
    createInitialLessonTimers(allLessonNums, DEFAULT_LESSON_REVIEW_SECONDS)
  );
  const notifyRef = useRef(onNotify);
  notifyRef.current = onNotify;

  // Sync deep-link from SyllabusAtlasView or AdaptiveQuizPanel
  useEffect(() => {
    if (!initialLessonNum) return;
    const match = flashcards.find((c) => c.lessonNum === initialLessonNum);
    if (match) {
      setUnitFilter(match.unitId);
      setLessonFilter(initialLessonNum);
      setFilterMode('all');
      setCurrentIdx(0);
      setFlipped(false);
      setLessonTimers((prev) => pauseAllLessonCountdowns(prev));
    }
  }, [flashcards, initialLessonNum]);

  // Pomodoro Focus Study Timer
  const [timerMode, setTimerMode] = useState<'focus' | 'break'>('focus');
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [timerRunning, setTimerRunning] = useState(false);

  useEffect(() => {
    if (!timerRunning) return;
    const id = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          setTimerRunning(false);
          notifyRef.current(
            timerMode === 'focus'
              ? 'انتهت جلسة التركيز! خذ استراحة قصيرة لمدة 5 دقائق.'
              : 'انتهت الاستراحة! مستعد لجلسة مذاكرة جديدة.'
          );
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [timerRunning, timerMode]);

  const lessonOptions = useMemo(() => {
    const seen = new Map<
      number,
      { lessonNum: number; lessonLabel: string; count: number; unitId: UnitId }
    >();
    for (const c of flashcards) {
      if (unitFilter !== 'all' && c.unitId !== unitFilter) continue;
      const existing = seen.get(c.lessonNum);
      if (existing) {
        existing.count += 1;
      } else {
        seen.set(c.lessonNum, {
          lessonNum: c.lessonNum,
          lessonLabel: c.lessonLabel,
          count: 1,
          unitId: c.unitId,
        });
      }
    }
    return Array.from(seen.values()).sort((a, b) => a.lessonNum - b.lessonNum);
  }, [flashcards, unitFilter]);

  const deck = useMemo(() => {
    return deckOrder
      .map((id) => flashcards.find((c) => c.id === id))
      .filter((c): c is (typeof flashcards)[number] => Boolean(c))
      .filter((c) => {
        if (unitFilter !== 'all' && c.unitId !== unitFilter) return false;
        if (lessonFilter !== 'all' && c.lessonNum !== lessonFilter) return false;
        if (filterMode === 'review' && masteredIds.includes(c.id)) return false;
        return true;
      });
  }, [deckOrder, filterMode, flashcards, lessonFilter, masteredIds, unitFilter]);

  const safeIdx = deck.length > 0 ? Math.min(currentIdx, deck.length - 1) : 0;
  const currentCard = deck[safeIdx];

  // Determine the currently active lesson for the per-lesson review countdown
  const activeLessonNum =
    lessonFilter !== 'all'
      ? lessonFilter
      : currentCard?.lessonNum ?? lessonOptions[0]?.lessonNum ?? allLessonNums[0] ?? 1;

  const activeLessonMeta = useMemo(() => {
    const match = flashcards.find((c) => c.lessonNum === activeLessonNum);
    const cardsInLesson = flashcards.filter((c) => c.lessonNum === activeLessonNum);
    const masteredInLesson = cardsInLesson.filter((c) => masteredIds.includes(c.id)).length;
    return {
      lessonNum: activeLessonNum,
      lessonLabel: match?.lessonLabel ?? `الدرس ${String(activeLessonNum).padStart(2, '0')}`,
      unitName: match?.unitName ?? 'المنهج الموحّد',
      totalCards: cardsInLesson.length,
      masteredCards: masteredInLesson,
    };
  }, [activeLessonNum, flashcards, masteredIds]);

  const activeLessonTimer = ensureLessonTimer(lessonTimers, activeLessonNum);
  const activeLessonClock = formatCountdownClock(activeLessonTimer.remainingSec);
  const activeLessonProgress = getCountdownProgress(activeLessonTimer);

  // Tick whichever lesson timer is currently running (pauses automatically when Studio view is hidden)
  const runningLessonNum = useMemo(() => {
    for (const num of allLessonNums) {
      if (lessonTimers[num]?.status === 'running') return num;
    }
    return null;
  }, [allLessonNums, lessonTimers]);

  useEffect(() => {
    if (!active || runningLessonNum === null) return;
    const id = window.setInterval(() => {
      let completedLessonLabel: string | null = null;
      setLessonTimers((prev) => {
        const { nextTimers, justCompleted } = tickLessonCountdown(prev, runningLessonNum);
        if (justCompleted) {
          const match = flashcards.find((c) => c.lessonNum === runningLessonNum);
          completedLessonLabel =
            match?.lessonLabel ?? `الدرس ${String(runningLessonNum).padStart(2, '0')}`;
        }
        return nextTimers;
      });
      if (completedLessonLabel) {
        notifyRef.current(
          `أحسنت! انتهى عداد مراجعة «${completedLessonLabel}». يمكنك الانتقال للدرس التالي.`
        );
      }
    }, 1000);
    return () => window.clearInterval(id);
  }, [active, flashcards, runningLessonNum]);

  const handleFlip = useCallback(() => {
    setFlipped((prev) => !prev);
    setFlipCount((c) => c + 1);
  }, []);

  const handleNext = useCallback(() => {
    if (deck.length === 0) return;
    setSlideDir(1);
    setFlipped(false);
    setCurrentIdx((prev) => (Math.min(prev, deck.length - 1) + 1) % deck.length);
  }, [deck.length]);

  const handlePrev = useCallback(() => {
    if (deck.length === 0) return;
    setSlideDir(-1);
    setFlipped(false);
    setCurrentIdx((prev) => (Math.min(prev, deck.length - 1) - 1 + deck.length) % deck.length);
  }, [deck.length]);

  // Keyboard shortcuts when Studio is active (Space = Flip, Arrows = Navigate)
  useEffect(() => {
    if (!active || !currentCard) return;
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable)
      ) {
        return;
      }
      if (e.code === 'Space') {
        e.preventDefault();
        handleFlip();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        handlePrev();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [active, currentCard, handleFlip, handleNext, handlePrev]);

  const handleSelectLesson = (lessonNum: number | 'all') => {
    setLessonFilter(lessonNum);
    setCurrentIdx(0);
    setFlipped(false);
    setLessonTimers((prev) => pauseAllLessonCountdowns(prev));
  };

  const handleShuffle = () => {
    setDeckOrder((prev) => {
      const next = [...prev];
      for (let i = next.length - 1; i > 0; i -= 1) {
        const j = Math.floor(Math.random() * (i + 1));
        [next[i], next[j]] = [next[j], next[i]];
      }
      return next;
    });
    setCurrentIdx(0);
    setFlipped(false);
    onNotify('تم خلط البطاقات التعليمية الـ 70 عشوائياً');
  };

  const switchTimerPreset = (mode: 'focus' | 'break') => {
    setTimerRunning(false);
    setTimerMode(mode);
    setSecondsLeft(mode === 'focus' ? 25 * 60 : 5 * 60);
  };

  const mins = String(Math.floor(secondsLeft / 60)).padStart(2, '0');
  const secs = String(secondsLeft % 60).padStart(2, '0');
  const validMasteredCount = flashcards.filter((c) => masteredIds.includes(c.id)).length;
  const masteryPct = Math.round((validMasteredCount / Math.max(1, flashcards.length)) * 100);

  const urgencyAccent =
    activeLessonProgress.urgency === 'done'
      ? {
          ring: '#10b981',
          text: 'text-emerald-600 dark:text-emerald-400',
          bar: 'bg-emerald-500',
          badge: 'border-emerald-500/35 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
          statusText: 'اكتملت مراجعة الدرس',
        }
      : activeLessonProgress.urgency === 'critical'
      ? {
          ring: '#f43f5e',
          text: 'text-rose-600 dark:text-rose-400',
          bar: 'bg-rose-500',
          badge: 'border-rose-500/35 bg-rose-500/10 text-rose-700 dark:text-rose-300',
          statusText: 'الثواني الأخيرة!',
        }
      : activeLessonProgress.urgency === 'warning'
      ? {
          ring: '#f59e0b',
          text: 'text-amber-600 dark:text-amber-400',
          bar: 'bg-amber-500',
          badge: 'border-amber-500/35 bg-amber-500/10 text-amber-700 dark:text-amber-300',
          statusText: 'اقترب انتهاء الوقت',
        }
      : {
          ring: 'var(--p-primary)',
          text: 'theme-text',
          bar: 'theme-grad-btn',
          badge: 'border-slate-200 dark:border-white/12 bg-slate-50 dark:bg-white/[0.05] theme-text',
          statusText:
            activeLessonTimer.status === 'running'
              ? 'جارٍ العد التنازلي'
              : activeLessonTimer.status === 'paused'
              ? 'متوقف مؤقتاً'
              : 'جاهز للمراجعة',
        };

  const dashOffset = RING_CIRCUMFERENCE * (1 - activeLessonProgress.remainingRatio);

  return (
    <section
      id="view-studio"
      className={`app-view ${
        active ? 'view-reveal' : 'hidden'
      } academy-container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-6`}
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black aurora-text">{heading}</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{subheading}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex p-1 rounded-xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10">
            <button
              type="button"
              onClick={() => {
                setFilterMode('all');
                setCurrentIdx(0);
                setFlipped(false);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                filterMode === 'all'
                  ? 'theme-grad-btn text-white'
                  : 'text-slate-700 dark:text-slate-300'
              }`}
            >
              جميع البطاقات ({flashcards.length})
            </button>
            <button
              type="button"
              onClick={() => {
                setFilterMode('review');
                setCurrentIdx(0);
                setFlipped(false);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                filterMode === 'review'
                  ? 'theme-grad-btn text-white'
                  : 'text-slate-700 dark:text-slate-300'
              }`}
            >
              تحتاج مراجعة ({flashcards.length - validMasteredCount})
            </button>
          </div>
          <motion.button
            type="button"
            onClick={handleShuffle}
            whileTap={prefersReducedMotion ? undefined : { scale: 0.95 }}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-xs font-bold inline-flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
          >
            <Shuffle className="w-3.5 h-3.5 theme-text" />
            <span>خلط</span>
          </motion.button>
        </div>
      </div>

      {/* Unit & Lesson Filter Controls (File 18: 70 cards across 3 Units / 14 Lessons) */}
      <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04]">
        <div className="flex flex-wrap gap-1.5">
          {STUDIO_UNITS.map((u) => {
            const count =
              u.id === 'all'
                ? flashcards.length
                : flashcards.filter((c) => c.unitId === u.id).length;
            return (
              <button
                key={u.id}
                type="button"
                onClick={() => {
                  setUnitFilter(u.id);
                  handleSelectLesson('all');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  unitFilter === u.id
                    ? 'theme-grad-btn text-white'
                    : 'bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-200/80 dark:hover:bg-white/10'
                }`}
              >
                {u.label} ({count})
              </button>
            );
          })}
        </div>

        <select
          aria-label="تصفية البطاقات حسب الدرس"
          value={lessonFilter}
          onChange={(e) => {
            const val = e.target.value;
            handleSelectLesson(val === 'all' ? 'all' : Number(val));
          }}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 text-xs font-bold cursor-pointer max-w-full lg:max-w-[290px]"
        >
          <option value="all">جميع الدروس في هذا الباب ({lessonOptions.length} دروس)</option>
          {lessonOptions.map((opt) => (
            <option key={opt.lessonNum} value={opt.lessonNum}>
              {opt.lessonLabel} ({opt.count} بطاقات)
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* 3D Framer Motion Flashcard Deck Stage */}
        <div className="lg:col-span-8 space-y-4">
          {/* Live Per-Lesson Countdown Ribbon directly above the Flashcard */}
          <div
            id="studioLessonCountdownRibbon"
            className="p-3.5 sm:px-4 rounded-2xl border border-slate-200 dark:border-white/12 bg-white/95 dark:bg-white/[0.04] flex flex-wrap items-center justify-between gap-3"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${urgencyAccent.badge}`}
              >
                <Clock
                  className={`w-4 h-4 ${
                    activeLessonTimer.status === 'running' && !prefersReducedMotion
                      ? 'animate-pulse'
                      : ''
                  }`}
                />
              </div>
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                  عداد مراجعة الدرس الحالي · {urgencyAccent.statusText}
                </div>
                <div className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-slate-100 truncate">
                  {activeLessonMeta.lessonLabel}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0 mr-auto sm:mr-0">
              <motion.span
                key={activeLessonClock.formatted}
                initial={
                  activeLessonProgress.urgency === 'critical' && !prefersReducedMotion
                    ? { scale: 1.12 }
                    : false
                }
                animate={{ scale: 1 }}
                transition={{ duration: 0.22 }}
                data-testid="lesson-countdown-ribbon-clock"
                className={`formula-ltr text-lg sm:text-xl font-black tabular-nums px-3 py-1 rounded-xl border ${urgencyAccent.badge} ${urgencyAccent.text}`}
              >
                {activeLessonClock.formatted}
              </motion.span>

              <motion.button
                type="button"
                whileTap={prefersReducedMotion ? undefined : { scale: 0.94 }}
                onClick={() =>
                  setLessonTimers((prev) => toggleLessonCountdown(prev, activeLessonNum))
                }
                aria-label={
                  activeLessonTimer.status === 'running'
                    ? 'إيقاف عداد مراجعة الدرس'
                    : 'بدء عداد مراجعة الدرس'
                }
                className="theme-grad-btn px-3.5 py-2 rounded-xl text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
              >
                {activeLessonTimer.status === 'running' ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>إيقاف</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>
                      {activeLessonTimer.status === 'completed' ? 'إعادة البدء' : 'بدء مراجعة الدرس'}
                    </span>
                  </>
                )}
              </motion.button>

              <button
                type="button"
                onClick={() =>
                  setLessonTimers((prev) => resetLessonCountdown(prev, activeLessonNum))
                }
                aria-label="إعادة ضبط عداد مراجعة الدرس"
                className="p-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {!currentCard ? (
            <div className="p-10 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] text-center space-y-3">
              <CheckCircle2 className="w-10 h-10 theme-text mx-auto" />
              <h3 className="font-extrabold text-lg">أحسنت! أتقنت جميع البطاقات في هذه المجموعة</h3>
              <button
                type="button"
                onClick={() => {
                  setFilterMode('all');
                  setUnitFilter('all');
                  handleSelectLesson('all');
                }}
                className="theme-grad-btn px-5 py-2.5 rounded-xl text-white font-bold text-sm cursor-pointer"
              >
                عرض جميع البطاقات ({flashcards.length}) للمراجعة
              </button>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-slate-500 dark:text-slate-400">
                <span>
                  {currentCard.unitName} · {currentCard.lessonLabel}
                </span>
                <span className="tabular-nums">
                  بطاقة {safeIdx + 1} من {deck.length} · اضغط على البطاقة أو مفتاح Space لقلبها
                </span>
              </div>

              {/* Layered Deck Stage with Framer Motion Spring 3D Flip */}
              <div className="relative pt-2 pb-4">
                {/* Subtle depth cards behind the active flashcard */}
                {deck.length > 1 && (
                  <>
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-x-6 top-5 bottom-0 rounded-2xl border border-slate-200/70 dark:border-white/[0.06] bg-white/50 dark:bg-white/[0.02] -z-10"
                    />
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-x-3 top-3.5 bottom-2 rounded-2xl border border-slate-200/80 dark:border-white/[0.08] bg-white/75 dark:bg-white/[0.03] -z-10"
                    />
                  </>
                )}

                <AnimatePresence mode="wait" custom={slideDir}>
                  <motion.div
                    key={currentCard.id}
                    custom={slideDir}
                    initial={
                      prefersReducedMotion
                        ? { opacity: 0 }
                        : {
                            opacity: 0,
                            x: slideDir > 0 ? -42 : 42,
                            rotateZ: slideDir > 0 ? -2.2 : 2.2,
                            scale: 0.96,
                          }
                    }
                    animate={{ opacity: 1, x: 0, rotateZ: 0, scale: 1 }}
                    exit={
                      prefersReducedMotion
                        ? { opacity: 0 }
                        : {
                            opacity: 0,
                            x: slideDir > 0 ? 42 : -42,
                            rotateZ: slideDir > 0 ? 2.2 : -2.2,
                            scale: 0.96,
                          }
                    }
                    transition={{ type: 'spring', stiffness: 320, damping: 26 }}
                  >
                    <button
                      type="button"
                      data-testid="studio-flashcard-button"
                      onClick={handleFlip}
                      aria-pressed={flipped}
                      aria-label={`قلب البطاقة التعليمية: ${currentCard.front}`}
                      className="flashcard-scene block w-full cursor-pointer text-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--p-primary)] rounded-2xl"
                    >
                      <motion.div
                        data-testid="studio-flashcard-inner"
                        data-flipped={flipped ? 'true' : 'false'}
                        animate={
                          prefersReducedMotion
                            ? { rotateY: flipped ? 180 : 0 }
                            : {
                                rotateY: flipped ? 180 : 0,
                                scale: flipCount > 0 ? [1, 1.032, 1] : 1,
                              }
                        }
                        whileHover={prefersReducedMotion ? undefined : { y: -4 }}
                        whileTap={prefersReducedMotion ? undefined : { scale: 0.985 }}
                        transition={{
                          rotateY: {
                            type: 'spring',
                            stiffness: 240,
                            damping: 20,
                            mass: 0.85,
                          },
                          scale: { duration: 0.42, ease: [0.16, 1, 0.3, 1] },
                          y: { type: 'spring', stiffness: 400, damping: 28 },
                        }}
                        className="flashcard-motion-inner relative h-76 sm:h-84 w-full"
                      >
                        {/* Front Face */}
                        <div className="flashcard-face absolute inset-0 glass-panel p-6 sm:p-8 rounded-2xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900/80 shadow-lg dark:shadow-2xl flex flex-col items-center justify-between overflow-hidden">
                          {/* Specular Light Sheen on Flip */}
                          {!prefersReducedMotion && flipCount > 0 && !flipped && (
                            <motion.div
                              key={`sheen-front-${flipCount}`}
                              aria-hidden="true"
                              initial={{ x: '130%', opacity: 0 }}
                              animate={{ x: '-140%', opacity: [0, 0.35, 0] }}
                              transition={{ duration: 0.65, ease: 'easeOut' }}
                              className="pointer-events-none absolute inset-y-0 w-1/2 -skew-x-12 bg-gradient-to-r from-transparent via-white/40 dark:via-white/20 to-transparent"
                            />
                          )}

                          <div className="w-full flex items-center justify-between gap-2 text-xs font-bold">
                            <span className="inline-flex items-center gap-1.5 theme-text">
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>بطاقة #{currentCard.index} · السؤال / المفهوم</span>
                            </span>
                            {masteredIds.includes(currentCard.id) && (
                              <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>مُتقنة</span>
                              </span>
                            )}
                          </div>

                          <div className="flex flex-col items-center justify-center gap-4 my-auto py-2">
                            <p className="text-base sm:text-xl font-extrabold text-slate-900 dark:text-slate-100 leading-relaxed max-w-xl">
                              {currentCard.front}
                            </p>
                            {currentCard.formulaHint && (
                              <code className="formula-ltr px-3.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-950/80 border border-slate-200/80 dark:border-white/10 text-xs sm:text-sm font-bold theme-text max-w-full overflow-x-auto">
                                {currentCard.formulaHint}
                              </code>
                            )}
                          </div>

                          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400">
                            <RefreshCw className="w-3.5 h-3.5" />
                            <span>انقر لقلب البطاقة وإظهار الإجابة النموذجية</span>
                          </div>
                        </div>

                        {/* Back Face */}
                        <div className="flashcard-face flashcard-back absolute inset-0 glass-panel p-6 sm:p-8 rounded-2xl border-2 theme-border bg-gradient-to-br from-white via-slate-50 to-white dark:from-slate-900/95 dark:via-slate-900 dark:to-slate-950/95 shadow-2xl flex flex-col items-center justify-between overflow-hidden">
                          {/* Specular Light Sheen on Flip to Back */}
                          {!prefersReducedMotion && flipCount > 0 && flipped && (
                            <motion.div
                              key={`sheen-back-${flipCount}`}
                              aria-hidden="true"
                              initial={{ x: '130%', opacity: 0 }}
                              animate={{ x: '-140%', opacity: [0, 0.35, 0] }}
                              transition={{ duration: 0.65, ease: 'easeOut' }}
                              className="pointer-events-none absolute inset-y-0 w-1/2 -skew-x-12 bg-gradient-to-r from-transparent via-[var(--p-primary)]/30 to-transparent"
                            />
                          )}

                          <div className="w-full flex items-center justify-between gap-2 text-xs font-bold">
                            <span className="inline-flex items-center gap-1.5 theme-text">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>الإجابة النموذجية · بطاقة #{currentCard.index}</span>
                            </span>
                            <span className="text-slate-400">{currentCard.lessonLabel}</span>
                          </div>

                          <div className="flex flex-col items-center justify-center gap-4 my-auto py-2">
                            <p className="text-sm sm:text-lg font-bold text-slate-800 dark:text-slate-100 leading-relaxed max-w-xl">
                              {currentCard.back}
                            </p>
                            {currentCard.formulaHint && (
                              <code className="formula-ltr px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-white/10 text-xs sm:text-sm font-bold text-slate-900 dark:text-cyan-300 max-w-full overflow-x-auto">
                                {currentCard.formulaHint}
                              </code>
                            )}
                          </div>

                          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-400">
                            <RefreshCw className="w-3.5 h-3.5" />
                            <span>انقر للعودة إلى وجه السؤال</span>
                          </div>
                        </div>
                      </motion.div>
                    </button>
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Deck Navigation & Mastery Controls */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <motion.button
                    type="button"
                    onClick={handlePrev}
                    whileTap={prefersReducedMotion ? undefined : { scale: 0.95 }}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-sm font-bold inline-flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>السابقة</span>
                  </motion.button>
                  <motion.button
                    type="button"
                    onClick={handleFlip}
                    whileTap={prefersReducedMotion ? undefined : { scale: 0.95 }}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/[0.06] text-sm font-bold inline-flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-white/12 cursor-pointer"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 theme-text transition-transform duration-300 ${
                        flipped ? 'rotate-180' : ''
                      }`}
                    />
                    <span>{flipped ? 'وجه السؤال' : 'قلب البطاقة'}</span>
                  </motion.button>
                  <motion.button
                    type="button"
                    onClick={handleNext}
                    whileTap={prefersReducedMotion ? undefined : { scale: 0.95 }}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-sm font-bold inline-flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
                  >
                    <span>التالية</span>
                    <ChevronLeft className="w-4 h-4" />
                  </motion.button>
                </div>

                <motion.button
                  type="button"
                  onClick={() => onToggleMastered(currentCard.id)}
                  whileTap={prefersReducedMotion ? undefined : { scale: 0.95 }}
                  animate={
                    masteredIds.includes(currentCard.id) && !prefersReducedMotion
                      ? { scale: [1, 1.05, 1] }
                      : undefined
                  }
                  transition={{ duration: 0.28 }}
                  className={`px-5 py-2.5 rounded-xl text-sm font-bold inline-flex items-center gap-2 transition cursor-pointer ${
                    masteredIds.includes(currentCard.id)
                      ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                      : 'theme-grad-btn text-white'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {masteredIds.includes(currentCard.id) ? 'بطاقة مُتقنة ✓' : 'تحديد كمُتقنة'}
                  </span>
                </motion.button>
              </div>
            </>
          )}
        </div>

        {/* Studio Side Panel: Per-Lesson Review Countdown + Mastery Progress + Pomodoro */}
        <div className="lg:col-span-4 space-y-5">
          {/* Per-Lesson Review Countdown Card */}
          <div
            id="studioLessonCountdownPanel"
            className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/12 bg-white dark:bg-white/[0.04] space-y-4"
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2 font-extrabold text-base text-slate-900 dark:text-slate-100">
                  <Clock className="w-4 h-4 theme-text" />
                  <span>العداد التنازلي لمراجعة الدرس</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {activeLessonMeta.lessonLabel} · إتقان {activeLessonMeta.masteredCards}/
                  {activeLessonMeta.totalCards} بطاقات
                </p>
              </div>
              {activeLessonTimer.completedSessions > 0 && (
                <span className="text-[11px] font-extrabold text-emerald-600 dark:text-emerald-400 shrink-0">
                  ✓ {activeLessonTimer.completedSessions}×
                </span>
              )}
            </div>

            {/* Circular Animated SVG Countdown Ring */}
            <div className="flex items-center justify-center py-1">
              <div className="relative w-32 h-32 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100" aria-hidden="true">
                  <circle
                    cx="50"
                    cy="50"
                    r={RING_RADIUS}
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="6.5"
                    className="text-slate-200 dark:text-white/10"
                  />
                  <motion.circle
                    cx="50"
                    cy="50"
                    r={RING_RADIUS}
                    fill="none"
                    stroke={urgencyAccent.ring}
                    strokeWidth="6.5"
                    strokeLinecap="round"
                    strokeDasharray={RING_CIRCUMFERENCE}
                    animate={{ strokeDashoffset: dashOffset }}
                    transition={
                      prefersReducedMotion
                        ? { duration: 0 }
                        : { duration: 0.45, ease: 'easeOut' }
                    }
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span
                    data-testid="lesson-countdown-panel-clock"
                    className={`formula-ltr text-2xl font-black tabular-nums ${urgencyAccent.text}`}
                  >
                    {activeLessonClock.formatted}
                  </span>
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 mt-0.5">
                    {urgencyAccent.statusText}
                  </span>
                </div>
              </div>
            </div>

            {/* Duration Presets for Active Lesson */}
            <div className="grid grid-cols-4 gap-1.5">
              {LESSON_TIMER_PRESETS.map((preset) => {
                const isSelected = activeLessonTimer.durationSec === preset.seconds;
                return (
                  <button
                    key={preset.seconds}
                    type="button"
                    onClick={() =>
                      setLessonTimers((prev) =>
                        setLessonDurationPreset(prev, activeLessonNum, preset.seconds)
                      )
                    }
                    className={`py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                      isSelected
                        ? 'theme-grad-btn text-white'
                        : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200/80 dark:hover:bg-white/10'
                    }`}
                  >
                    {preset.label}
                  </button>
                );
              })}
            </div>

            {/* Quick Lesson Switcher with Individual Countdown Status */}
            <div className="space-y-2 pt-1 border-t border-slate-200/80 dark:border-white/10">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                اختر درساً لمراجعة عداده التنازلي المستقل:
              </div>
              <div className="max-h-36 overflow-y-auto custom-scrollbar space-y-1.5 pl-1">
                {lessonOptions.map((opt) => {
                  const t = ensureLessonTimer(lessonTimers, opt.lessonNum);
                  const clock = formatCountdownClock(t.remainingSec);
                  const isCurrent = opt.lessonNum === activeLessonNum;
                  return (
                    <button
                      key={opt.lessonNum}
                      type="button"
                      data-testid={`lesson-timer-row-${opt.lessonNum}`}
                      onClick={() => handleSelectLesson(opt.lessonNum)}
                      className={`w-full px-3 py-2 rounded-xl border text-right text-xs flex items-center justify-between gap-2 transition cursor-pointer ${
                        isCurrent
                          ? 'theme-border bg-[var(--p-primary)]/10 text-slate-900 dark:text-white font-extrabold'
                          : 'border-slate-200/80 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.02] text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06] font-bold'
                      }`}
                    >
                      <span className="truncate">{opt.lessonLabel}</span>
                      <span
                        className={`formula-ltr tabular-nums shrink-0 text-[11px] ${
                          t.status === 'completed'
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : t.status === 'running'
                            ? 'theme-text'
                            : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {t.status === 'completed' ? '✓ 00:00' : clock.formatted}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Mastery Progress Card */}
          <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100">
                تقدم إتقان البطاقات
              </h3>
              <span className="font-black text-lg theme-text tabular-nums">{masteryPct}%</span>
            </div>
            <div className="h-2.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
              <motion.div
                className="h-full rounded-full theme-grad-btn"
                initial={false}
                animate={{ width: `${masteryPct}%` }}
                transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              />
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 tabular-nums">
              أتقنت {validMasteredCount} من أصل {flashcards.length} بطاقة مراجعة (14 درساً × 5 بطاقات).
            </p>
          </div>

          {/* Pomodoro Focus Timer */}
          <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-extrabold text-base text-slate-900 dark:text-slate-100">
                <Timer className="w-4 h-4 theme-text" />
                <span>مؤقت التركيز (بومودورو)</span>
              </div>
            </div>

            <div className="flex gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-white/5">
              <button
                type="button"
                onClick={() => switchTimerPreset('focus')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                  timerMode === 'focus'
                    ? 'theme-grad-btn text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                مذاكرة (25 د)
              </button>
              <button
                type="button"
                onClick={() => switchTimerPreset('break')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                  timerMode === 'break'
                    ? 'theme-grad-btn text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                استراحة (5 د)
              </button>
            </div>

            <div className="text-center py-2">
              <div className="formula-ltr text-3xl sm:text-4xl font-black theme-text tabular-nums">
                {mins}:{secs}
              </div>
            </div>

            <div className="flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => setTimerRunning((r) => !r)}
                className="theme-grad-btn px-5 py-2.5 rounded-xl text-white text-sm font-bold inline-flex items-center gap-2 cursor-pointer"
              >
                {timerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{timerRunning ? 'إيقاف مؤقت' : 'ابدأ الجلسة'}</span>
              </button>
              <button
                type="button"
                onClick={() => switchTimerPreset(timerMode)}
                aria-label="إعادة ضبط المؤقت"
                className="p-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
