import { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Atom,
  BookOpen,
  Check,
  ClipboardCheck,
  Copy,
  FlaskConical,
  Layers,
  Search,
  Sparkles,
} from 'lucide-react';
import { ACADEMY_DATA, type UnitId } from '../data/academyData';

interface SyllabusAtlasViewProps {
  active: boolean;
  onOpenDeepLesson: (lessonId: string) => void;
  onOpenSubTopicQuestions: (subTopicId: string, lessonId: string) => void;
  onOpenLessonFlashcards: (lessonNum: number) => void;
  onOpenLab: () => void;
  onNotify: (msg: string) => void;
}

const UNIT_FILTERS: ReadonlyArray<{ id: 'all' | UnitId; label: string; range: string }> = [
  { id: 'all', label: 'المنهج الكامل', range: '14 درساً' },
  { id: 'unit1', label: 'الباب الأول: الحساب الكيميائي', range: 'الدروس 01 – 05' },
  { id: 'unit2', label: 'الباب الثاني: بنية الذرة', range: 'الدروس 06 – 09' },
  { id: 'unit3', label: 'الباب الثالث: الجدول الدوري', range: 'الدروس 10 – 14' },
];

export function SyllabusAtlasView({
  active,
  onOpenDeepLesson,
  onOpenSubTopicQuestions,
  onOpenLessonFlashcards,
  onOpenLab,
  onNotify,
}: SyllabusAtlasViewProps) {
  const { heading, subheading, lessons } = ACADEMY_DATA.syllabus14;
  const { equations, constants, atomicMasses } = ACADEMY_DATA.openBook;

  const [sectionMode, setSectionMode] = useState<'lessons14' | 'equations'>('lessons14');
  const [unitFilter, setUnitFilter] = useState<'all' | UnitId>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedId, setSelectedId] = useState(lessons[0]?.id ?? 'syl-01');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredLessons = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return lessons.filter((item) => {
      if (unitFilter !== 'all' && item.unitId !== unitFilter) return false;
      if (!q) return true;
      return (
        item.title.toLowerCase().includes(q) ||
        item.numberLabel.toLowerCase().includes(q) ||
        item.unitName.toLowerCase().includes(q) ||
        item.sections.some(
          (s) =>
            s.title.toLowerCase().includes(q) ||
            s.items.some((line) => line.toLowerCase().includes(q))
        )
      );
    });
  }, [lessons, searchQuery, unitFilter]);

  const activeLesson = useMemo(() => {
    return (
      filteredLessons.find((l) => l.id === selectedId) ??
      filteredLessons[0] ??
      lessons[0]
    );
  }, [filteredLessons, lessons, selectedId]);

  const filteredEquations = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return equations.filter((eq) => {
      if (unitFilter !== 'all' && eq.unitId !== unitFilter) return false;
      if (!q) return true;
      return (
        eq.equation.toLowerCase().includes(q) ||
        eq.tag.toLowerCase().includes(q)
      );
    });
  }, [equations, searchQuery, unitFilter]);

  const handleCopy = (id: string, text: string, label: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedId(id);
    onNotify(`تم نسخ ${label} إلى الحافظة`);
    window.setTimeout(() => {
      setCopiedId((prev) => (prev === id ? null : prev));
    }, 1800);
  };

  return (
    <section
      id="view-syllabus"
      className={`app-view ${
        active ? 'view-reveal' : 'hidden'
      } academy-container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-6`}
    >
      {/* Header Row */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="space-y-1 max-w-3xl">
          <p className="text-xs font-extrabold theme-text">
            المنهج الموحد للصف الثاني الثانوي · الفصل الدراسي الأول
          </p>
          <h2 className="text-2xl sm:text-3xl font-black aurora-text">{heading}</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            {subheading}
          </p>
        </div>

        {/* Mode Switcher */}
        <div
          role="tablist"
          aria-label="أقسام أطلس المنهج"
          className="flex flex-wrap gap-1.5 p-1.5 rounded-2xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10"
        >
          <button
            type="button"
            role="tab"
            aria-selected={sectionMode === 'lessons14'}
            onClick={() => setSectionMode('lessons14')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold inline-flex items-center gap-2 transition cursor-pointer ${
              sectionMode === 'lessons14'
                ? 'theme-grad-btn text-white'
                : 'text-slate-700 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>الشرح الكامل للـ 14 درساً</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={sectionMode === 'equations'}
            onClick={() => setSectionMode('equations')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold inline-flex items-center gap-2 transition cursor-pointer ${
              sectionMode === 'equations'
                ? 'theme-grad-btn text-white'
                : 'text-slate-700 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10'
            }`}
          >
            <Atom className="w-4 h-4" />
            <span>أطلس المعادلات الـ 18 والكتل الذرية</span>
          </button>
        </div>
      </div>

      {/* Unit Filters & Search Bar */}
      <div className="flex flex-col xl:flex-row gap-3 items-stretch xl:items-center justify-between">
        <div className="flex flex-wrap gap-1.5 p-1 rounded-xl bg-slate-200/70 dark:bg-white/5 border border-slate-200 dark:border-white/10">
          {UNIT_FILTERS.map((u) => (
            <button
              key={u.id}
              type="button"
              onClick={() => setUnitFilter(u.id)}
              className={`px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                unitFilter === u.id
                  ? 'theme-grad-btn text-white'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10'
              }`}
            >
              {u.label} <span className="opacity-80">({u.range})</span>
            </button>
          ))}
        </div>

        <div className="relative w-full xl:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث داخل الدروس الـ 14 أو المعادلات..."
            aria-label="ابحث داخل شروحات المنهج الـ 14"
            className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
          />
        </div>
      </div>

      {/* ================================================================= */}
      {/* TAB A: 14-LESSON STRUCTURED SYLLABUS READER                       */}
      {/* ================================================================= */}
      {sectionMode === 'lessons14' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Sidebar: All 14 Lessons Index */}
          <aside className="lg:col-span-4 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] p-3 space-y-1.5 max-h-[680px] overflow-y-auto custom-scrollbar">
            <div className="px-2 py-1.5 flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
              <span>فهرس الدروس الموحد</span>
              <span className="tabular-nums theme-text">{filteredLessons.length} / 14</span>
            </div>

            {filteredLessons.length === 0 ? (
              <div className="p-6 text-center text-xs font-bold text-slate-500">
                لا توجد دروس مطابقة لعبارة البحث الحالية.
              </div>
            ) : (
              filteredLessons.map((item) => {
                const isSelected = activeLesson?.id === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedId(item.id)}
                    aria-current={isSelected ? 'true' : undefined}
                    className={`w-full text-right p-3 rounded-xl border transition cursor-pointer flex items-start justify-between gap-2.5 ${
                      isSelected
                        ? 'theme-border theme-bg-soft'
                        : 'border-transparent hover:bg-slate-100 dark:hover:bg-white/5'
                    }`}
                  >
                    <div className="min-w-0 space-y-0.5">
                      <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                        {item.numberLabel} · {item.unitName.split(':')[0]}
                      </div>
                      <div
                        className={`text-xs sm:text-sm font-extrabold leading-snug ${
                          isSelected
                            ? 'theme-text'
                            : 'text-slate-800 dark:text-slate-100'
                        }`}
                      >
                        {item.title}
                      </div>
                    </div>
                    <span className="font-mono text-xs font-black theme-text shrink-0 tabular-nums pt-0.5">
                      {String(item.number).padStart(2, '0')}
                    </span>
                  </button>
                );
              })
            )}
          </aside>

          {/* Main Reader Pane */}
          {activeLesson && (
            <article className="lg:col-span-8 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] p-5 sm:p-7 space-y-6">
              <div className="space-y-3 border-b border-slate-200 dark:border-white/10 pb-5">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-slate-500 dark:text-slate-400">
                  <span>
                    {activeLesson.unitName} · {activeLesson.numberLabel}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const summaryText = [
                        `${activeLesson.numberLabel}: ${activeLesson.title}`,
                        ...activeLesson.sections.flatMap((s) => [
                          `\n${s.title}:`,
                          ...s.items.map((x) => `- ${x}`),
                        ]),
                      ].join('\n');
                      handleCopy(activeLesson.id, summaryText, `ملخص ${activeLesson.numberLabel}`);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 hover:bg-slate-100 dark:hover:bg-white/10 text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
                  >
                    {copiedId === activeLesson.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 theme-text" />
                    )}
                    <span>نسخ ملخص الدرس</span>
                  </button>
                </div>

                <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white leading-snug">
                  {activeLesson.numberLabel}: {activeLesson.title}
                </h3>

                {/* Direct Jump Actions connecting this 14-lesson syllabus entry to the whole platform */}
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() =>
                      onOpenSubTopicQuestions(activeLesson.subTopicId, activeLesson.mappedLessonId)
                    }
                    className="theme-grad-btn px-4 py-2 rounded-xl text-white text-xs font-extrabold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <ClipboardCheck className="w-3.5 h-3.5" />
                    <span>بنك أسئلة {activeLesson.numberLabel} (100 سؤال)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenLessonFlashcards(activeLesson.number)}
                    className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:theme-border text-xs font-extrabold text-slate-800 dark:text-slate-100 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Layers className="w-3.5 h-3.5 theme-text" />
                    <span>بطاقات الدرس في الاستوديو (5 بطاقات)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenDeepLesson(activeLesson.mappedLessonId)}
                    className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:theme-border text-xs font-bold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <BookOpen className="w-3.5 h-3.5 theme-text" />
                    <span>الشرح الموسّع بالكتاب</span>
                  </button>
                  <button
                    type="button"
                    onClick={onOpenLab}
                    className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:theme-border text-xs font-bold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <FlaskConical className="w-3.5 h-3.5 theme-text" />
                    <span>تطبيق بالمختبر</span>
                  </button>
                </div>
              </div>

              {/* Verbatim Curriculum Sections */}
              <div className="space-y-5">
                {activeLesson.sections.map((sec, idx) => (
                  <div
                    key={`${activeLesson.id}-sec-${idx}`}
                    className="rounded-xl border border-slate-200/80 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.02] p-4 sm:p-5 space-y-3"
                  >
                    <h4 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 theme-text shrink-0" />
                      <span>
                        {idx + 1}. {sec.title}
                      </span>
                    </h4>
                    <ul className="space-y-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
                      {sec.items.map((line, lIdx) => (
                        <li
                          key={lIdx}
                          className="flex items-start gap-2.5 pb-2 border-b last:border-b-0 border-slate-200/60 dark:border-white/5 last:pb-0"
                        >
                          <span className="font-mono text-[11px] font-black theme-text shrink-0 mt-0.5 tabular-nums">
                            {String(lIdx + 1).padStart(2, '0')}
                          </span>
                          <span className="whitespace-pre-line">{line}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              {/* Next / Prev Lesson Footer */}
              <div className="pt-4 border-t border-slate-200 dark:border-white/10 flex items-center justify-between gap-3">
                {(() => {
                  const curIdx = lessons.findIndex((l) => l.id === activeLesson.id);
                  const prevLesson = curIdx > 0 ? lessons[curIdx - 1] : null;
                  const nextLesson = curIdx >= 0 && curIdx < lessons.length - 1 ? lessons[curIdx + 1] : null;
                  return (
                    <>
                      <button
                        type="button"
                        disabled={!prevLesson}
                        onClick={() => prevLesson && setSelectedId(prevLesson.id)}
                        className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
                      >
                        {prevLesson ? `الدرس السابق: ${prevLesson.numberLabel}` : 'بداية المنهج'}
                      </button>
                      <button
                        type="button"
                        disabled={!nextLesson}
                        onClick={() => nextLesson && setSelectedId(nextLesson.id)}
                        className="px-4 py-2 rounded-xl theme-grad-btn text-white text-xs font-bold disabled:opacity-40 inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <span>
                          {nextLesson ? `الدرس التالي: ${nextLesson.numberLabel}` : 'نهاية المنهج الـ 14'}
                        </span>
                        {nextLesson && <ArrowLeft className="w-3.5 h-3.5" />}
                      </button>
                    </>
                  );
                })()}
              </div>
            </article>
          )}
        </div>
      )}

      {/* ================================================================= */}
      {/* TAB B: 18 BALANCED CURRICULUM EQUATIONS + 21 ATOMIC MASSES        */}
      {/* ================================================================= */}
      {sectionMode === 'equations' && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-white/10 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-white">
                  أهم المعادلات الكيميائية الموزونة بالمنهج ({filteredEquations.length} معادلة)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  جميع معادلات منهج الصف الثاني الثانوي الترم الأول جاهزة للبحث والنسخ المباشر
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleCopy(
                    'all-eqs',
                    filteredEquations.map((e) => `${e.number}- ${e.equation}`).join('\n'),
                    'جميع المعادلات الموزونة'
                  )
                }
                className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold inline-flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5 theme-text" />
                <span>نسخ جميع المعادلات</span>
              </button>
            </div>

            <div className="divide-y divide-slate-200/80 dark:divide-white/10">
              {filteredEquations.map((eq) => (
                <div
                  key={eq.id}
                  className="px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-white/[0.02]"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <span className="font-mono text-xs font-black theme-text w-6 tabular-nums shrink-0">
                      {String(eq.number).padStart(2, '0')}
                    </span>
                    <div className="min-w-0 flex-1 space-y-0.5">
                      <code className="formula-ltr block text-xs sm:text-sm font-bold text-slate-900 dark:text-cyan-300 overflow-x-auto">
                        {eq.equation}
                      </code>
                      <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                        {eq.tag}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopy(eq.id, eq.equation, `المعادلة #${eq.number}`)}
                    aria-label={`نسخ المعادلة رقم ${eq.number}`}
                    className="p-2 rounded-lg border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-500 dark:text-slate-300 cursor-pointer shrink-0"
                  >
                    {copiedId === eq.id ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Constants + 21 Standard Atomic Masses */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <div className="lg:col-span-6 p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-3">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                الثوابت الفيزيائية والكيميائية القياسية (الترم الأول)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {constants.map((c) => (
                  <div
                    key={c.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-white/10 space-y-1"
                  >
                    <div className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      {c.label}
                    </div>
                    <div className="formula-ltr text-sm font-black theme-text tabular-nums">
                      {c.value}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      {c.detail}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-6 p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-white/[0.04] space-y-3">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                الكتل الذرية النسبية الجرامية القياسية ({atomicMasses.length} عنصراً · g/mol)
              </h3>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-2">
                {atomicMasses.map((am) => (
                  <div
                    key={am.symbol}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200/80 dark:border-white/10 text-center"
                  >
                    <div className="formula-ltr text-sm font-black text-slate-900 dark:text-white">
                      {am.symbol}
                    </div>
                    <div className="formula-ltr text-xs font-bold theme-text tabular-nums">
                      {am.mass}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
