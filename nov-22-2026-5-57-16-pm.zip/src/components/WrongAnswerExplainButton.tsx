import { ArrowLeft, BookOpen } from 'lucide-react';
import { resolveLessonExplanationTarget } from '../utils/mistakesEngine';
import type { ExplanationJumpTarget } from './MistakesView';

interface WrongAnswerExplainButtonProps {
  questionId: string;
  questionText: string;
  lessonId?: string;
  sectionIndex?: number;
  onJumpToExplanation: (target: ExplanationJumpTarget) => void;
  label?: string;
  className?: string;
}

export function WrongAnswerExplainButton({
  questionId,
  questionText,
  lessonId,
  sectionIndex,
  onJumpToExplanation,
  label = 'شرح الجزء',
  className = '',
}: WrongAnswerExplainButtonProps) {
  const target = resolveLessonExplanationTarget(questionId, lessonId, sectionIndex);

  return (
    <button
      type="button"
      data-testid="wrong-answer-explain-btn"
      onClick={() =>
        onJumpToExplanation({
          lessonId: target.lessonId,
          sectionIndex: target.sectionIndex,
          sectionTitle: target.sectionTitle,
          questionText,
        })
      }
      title={`الانتقال إلى شرح: ${target.sectionTitle} (${target.lessonTitle})`}
      aria-label={`الانتقال إلى شرح الجزء الخاص بهذا السؤال: ${target.sectionTitle}`}
      className={`inline-flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-xl border border-rose-500/45 bg-rose-500/12 hover:bg-rose-500/22 active:scale-95 text-rose-700 dark:text-rose-200 text-[11px] font-extrabold whitespace-nowrap transition-all shrink-0 cursor-pointer ${className}`}
    >
      <BookOpen className="w-3.5 h-3.5 shrink-0" />
      <span>{label}</span>
      <ArrowLeft className="w-3 h-3 shrink-0" />
    </button>
  );
}
