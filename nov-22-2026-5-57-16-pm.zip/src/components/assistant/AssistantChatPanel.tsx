import React, { useEffect, useRef, useState } from 'react';
import {
  BookOpen,
  ChevronDown,
  ChevronUp,
  ImagePlus,
  Loader2,
  Mic,
  MicOff,
  PlusCircle,
  Send,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import {
  NOT_FOUND_LITERAL,
  buildLocalFallbackResponse,
  buildRagContextBlock,
  searchCurriculumRag,
  type CurriculumChunkKind,
  type ParsedCurriculumKnowledge,
} from '../../utils/curriculumRag';
import { callFreePuterChat } from '../../utils/puterAiClient';
import { CurriculumMathText } from '../CurriculumMathText';

export interface AssistantChatEntry {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  imageDataUrl?: string;
  sources?: { sourceTitle: string; snippet: string }[];
  modeLabel?: string;
}

const CHAT_STORAGE_KEY = 'smart_curriculum_chat_history_v1';

const QUICK_ACTION_CHIPS: ReadonlyArray<{
  label: string;
  buildPrompt: (lessonTitle: string | null) => string;
  preferKinds: CurriculumChunkKind[];
}> = [
  {
    label: '📖 اشرح لي الدرس',
    buildPrompt: (lesson) =>
      lesson
        ? `اشرح لي ${lesson} بالكامل وبأسلوب مبسط مع الأمثلة والاستنتاجات الواردة في المنهج المرفق فقط.`
        : 'اشرح لي أهم محاور وأساسيات الدروس الواردة في ملف المنهج المرفق بأسلوب منظم ومبسط.',
    preferKinds: ['explanation'],
  },
  {
    label: '🧪 لخص المعادلات والقوانين',
    buildPrompt: (lesson) =>
      lesson
        ? `لخص لي جميع المعادلات الكيميائية والقوانين الرياضية والثوابت الخاصة بـ ${lesson} من المنهج المرفق.`
        : 'لخص لي جميع المعادلات الكيميائية الموزونة والقوانين الرياضية والثوابت القياسية الواردة في المنهج المرفق.',
    preferKinds: ['law', 'equation', 'table'],
  },
  {
    label: '📝 هات لي سؤالين اختبار (وانتظر إجابتي)',
    buildPrompt: (lesson) =>
      lesson
        ? `هات لي سؤالين اختبار من ${lesson} في المنهج المرفق (اختيار من متعدد) بدون ذكر الإجابة الصحيحة، وانتظر إجابتي أولاً لتصححها لي.`
        : 'هات لي سؤالين اختبار متنوعين من المنهج المرفق بدون ذكر الإجابة الصحيحة، وانتظر إجابتي أولاً لتصححها لي.',
    preferKinds: ['mcq', 'essay'],
  },
  {
    label: '💡 أهم التريكات والتعليلات',
    buildPrompt: (lesson) =>
      lesson
        ? `ما أهم التريكات وأسئلة علل والاستنتاجات الدقيقة في ${lesson} من المنهج المرفق؟`
        : 'ما أهم التريكات والتعليلات العلمية والاستنتاجات المقارنة الواردة في المنهج المرفق؟',
    preferKinds: ['essay', 'explanation', 'mcq'],
  },
];

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionInstanceLike {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

interface AssistantChatPanelProps {
  knowledge: ParsedCurriculumKnowledge;
  externalPrompt?: { text: string; lessonCode?: string; nonce: number } | null;
  onNotify: (msg: string, tone?: 'success' | 'info' | 'error') => void;
}

function loadStoredMessages(): AssistantChatEntry[] {
  try {
    const raw = window.localStorage.getItem(CHAT_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as AssistantChatEntry[]) : [];
  } catch {
    return [];
  }
}

export function AssistantChatPanel({
  knowledge,
  externalPrompt,
  onNotify,
}: AssistantChatPanelProps) {
  const [messages, setMessages] = useState<AssistantChatEntry[]>(() => loadStoredMessages());
  const [inputText, setInputText] = useState('');
  const [selectedLessonCode, setSelectedLessonCode] = useState<string>('all');
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [attachedImageName, setAttachedImageName] = useState<string>('');
  const [isSending, setIsSending] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [openSourcesMap, setOpenSourcesMap] = useState<Record<string, boolean>>({});

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const recognitionRef = useRef<SpeechRecognitionInstanceLike | null>(null);
  const scrollEndRef = useRef<HTMLDivElement | null>(null);
  const handledExternalNonce = useRef<number>(0);

  useEffect(() => {
    try {
      // Save without huge base64 images exceeding quota
      const compact = messages.slice(-40).map((m) => ({
        ...m,
        imageDataUrl: m.imageDataUrl && m.imageDataUrl.length < 180000 ? m.imageDataUrl : undefined,
      }));
      window.localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(compact));
    } catch {
      // ignore quota overflow
    }
  }, [messages]);

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, isSending]);

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      recognitionRef.current?.stop();
    };
  }, []);

  const submitQuery = async (
    rawQuery: string,
    opts?: { preferKinds?: CurriculumChunkKind[]; lessonOverride?: string; imageOverride?: string | null }
  ) => {
    const trimmed = rawQuery.trim();
    const imgToSend = opts?.imageOverride !== undefined ? opts.imageOverride : attachedImage;
    if (!trimmed && !imgToSend) return;
    if (isSending) return;

    const effectiveLesson = opts?.lessonOverride ?? selectedLessonCode;
    const userDisplayText = trimmed || 'اشرح لي خطوات حل السؤال الموجود في الصورة المرفقة من المنهج فقط.';

    const userMsg: AssistantChatEntry = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: userDisplayText,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      imageDataUrl: imgToSend ?? undefined,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setAttachedImage(null);
    setAttachedImageName('');
    setIsSending(true);

    try {
      // 1. Strict Local Arabic RAG Search inside the EXCLUSIVE curriculum knowledge file ONLY
      const searchResult = searchCurriculumRag(knowledge, userDisplayText, {
        lessonCode: effectiveLesson,
        topK: 6,
        preferKinds: opts?.preferKinds,
      });

      const isQuizPrompt = userDisplayText.includes('سؤالين اختبار');
      const ragContext = searchResult.hasRelevantMatch
        ? buildRagContextBlock(searchResult.hits, 6800)
        : '';

      // If no relevant match and no image uploaded, immediately respect the strict rule without wasting a roundtrip
      if (!searchResult.hasRelevantMatch && !imgToSend) {
        const refusalMsg: AssistantChatEntry = {
          id: `a-${Date.now() + 1}`,
          role: 'assistant',
          content: `عذراً، (${NOT_FOUND_LITERAL}).\n\nيمكنك طرح سؤال من الدروس والقوانين والمعادلات الموجودة داخل ملف المنهج المرفق، أو تحديث ملف المنهج الخاص من الزر العلوي.`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          modeLabel: 'الالتزام الحصري بالمنهج المرفق',
        };
        setMessages((prev) => [...prev, refusalMsg]);
        return;
      }

      // If an image is uploaded without text keywords, provide a condensed syllabus index + top chunks so Puter can ground strictly
      const effectiveContext =
        ragContext ||
        knowledge.chunks
          .filter((c) => c.kind === 'explanation' || c.kind === 'law' || c.kind === 'equation')
          .slice(0, 8)
          .map((c) => `[${c.sourceTitle}]\n${c.text}`)
          .join('\n\n')
          .slice(0, 6800);

      // 2. Call 100% Free Puter.js v2 AI (window.puter.ai.chat)
      const historyForModel = messages.slice(-6).map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const puterRes = await callFreePuterChat({
        userPrompt: userDisplayText,
        ragContext: effectiveContext,
        history: historyForModel,
        imageDataUrl: imgToSend,
        extraSystemDirective: isQuizPrompt
          ? 'مهم جداً: أعط الطالب سؤالين فقط من المقاطع المرفقة مع الخيارات، ولا تذكر الإجابة الصحيحة الآن، واطلب منه كتابة إجابته لتصحيحها.'
          : undefined,
      });

      const sources = searchResult.hits.slice(0, 4).map((h) => ({
        sourceTitle: h.chunk.sourceTitle,
        snippet: h.chunk.text.slice(0, 260) + (h.chunk.text.length > 260 ? '...' : ''),
      }));

      if (puterRes.ok && puterRes.text) {
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now() + 1}`,
            role: 'assistant',
            content: puterRes.text,
            timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
            sources,
            modeLabel: 'Puter AI المجاني · من ملف المنهج المرفق',
          },
        ]);
      } else {
        // 3. Automatic Zero-Crash Fallback directly from Local Arabic RAG
        let fallbackContent = '';
        if (isQuizPrompt) {
          const pool =
            effectiveLesson !== 'all'
              ? knowledge.mcqs.filter((q) => q.lessonCode === effectiveLesson)
              : knowledge.mcqs;
          const picked = pool.slice(0, 2);
          if (picked.length > 0) {
            fallbackContent =
              `**اختبار سريع من ملف المنهج المرفق** (أجب ثم أرسل إجابتك للمراجعة):\n\n` +
              picked
                .map(
                  (q, idx) =>
                    `### سؤال ${idx + 1} (${q.lessonLabel})\n${q.question}\n` +
                    q.options.map((o) => `- ${o.key}) ${o.text}`).join('\n')
                )
                .join('\n\n---\n\n') +
              `\n\nاكتب إجابتك (مثلاً: 1 أ، 2 ب) وسأصححها لك مباشرة من المنهج.`;
          } else {
            fallbackContent = buildLocalFallbackResponse(
              userDisplayText,
              searchResult,
              puterRes.usedFallbackReason
            );
          }
        } else if (imgToSend && !searchResult.hasRelevantMatch) {
          fallbackContent =
            `**تم استلام صورة السؤال** (${puterRes.usedFallbackReason}).\n\n` +
            `لقراءة الصورة آلياً يلزم تفعيل جلسة Puter المجانية، أو يمكنك كتابة نص السؤال أو أهم الكلمات المفتاحية منه هنا وسأستخرج لك شرحه الكامل فوراً من ملف المنهج المرفق.`;
        } else {
          fallbackContent = buildLocalFallbackResponse(
            userDisplayText,
            searchResult,
            puterRes.usedFallbackReason
          );
        }

        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now() + 1}`,
            role: 'assistant',
            content: fallbackContent,
            timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
            sources,
            modeLabel: 'بحث المنهج المحلي المباشر (بديل تلقائي)',
          },
        ]);
      }
    } finally {
      setIsSending(false);
    }
  };

  // Trigger from external tools (e.g., "اشرح بالمساعد خطوة بخطوة" in Equations Explorer)
  useEffect(() => {
    if (externalPrompt && externalPrompt.nonce !== handledExternalNonce.current) {
      handledExternalNonce.current = externalPrompt.nonce;
      if (externalPrompt.lessonCode) {
        setSelectedLessonCode(externalPrompt.lessonCode);
      }
      void submitQuery(externalPrompt.text, {
        lessonOverride: externalPrompt.lessonCode ?? 'all',
        preferKinds: ['equation', 'law', 'explanation'],
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalPrompt]);

  const handleQuickChip = (chip: (typeof QUICK_ACTION_CHIPS)[number]) => {
    const lessonObj = knowledge.lessons.find((l) => l.code === selectedLessonCode);
    const prompt = chip.buildPrompt(lessonObj ? lessonObj.title : null);
    void submitQuery(prompt, { preferKinds: chip.preferKinds });
  };

  const handleToggleVoiceInput = () => {
    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionInstanceLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionInstanceLike;
    };
    const SpeechRec = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SpeechRec) {
      onNotify('متصفحك الحالي لا يدعم الإملاء الصوتي (Web Speech API).', 'info');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    try {
      const rec = new SpeechRec();
      rec.lang = 'ar-EG';
      rec.interimResults = false;
      rec.continuous = false;
      rec.onresult = (e) => {
        const transcript = e.results?.[0]?.[0]?.transcript ?? '';
        if (transcript) {
          setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };
      rec.onerror = () => {
        setIsListening(false);
        onNotify('تعذّر التقاط الصوت، تأكد من صلاحية الميكروفون.', 'info');
      };
      rec.onend = () => {
        setIsListening(false);
      };
      recognitionRef.current = rec;
      setIsListening(true);
      rec.start();
    } catch {
      setIsListening(false);
      onNotify('تعذّر تشغيل الميكروفون في هذا المتصفح.', 'info');
    }
  };

  const handleToggleSpeak = (msg: AssistantChatEntry) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      onNotify('متصفحك لا يدعم القراءة الصوتية (Speech Synthesis).', 'info');
      return;
    }
    if (speakingMsgId === msg.id) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const cleanSpeech = msg.content
      .replace(/\$+/g, '')
      .replace(/\\ce\{([^}]+)\}/g, '$1')
      .replace(/[#*_`>-]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.lang = 'ar-EG';
    utterance.rate = 0.98;
    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);
    setSpeakingMsgId(msg.id);
    window.speechSynthesis.speak(utterance);
  };

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      onNotify('يرجى اختيار ملف صورة صالح.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAttachedImage(reader.result);
        setAttachedImageName(file.name);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleClearChat = () => {
    window.speechSynthesis?.cancel();
    setSpeakingMsgId(null);
    setMessages([]);
    try {
      window.localStorage.removeItem(CHAT_STORAGE_KEY);
    } catch {
      // ignore
    }
    onNotify('تم بدء محادثة جديدة ومسح السجل المحلي.', 'info');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-11.5rem)] min-h-[540px] rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 overflow-hidden">
      {/* Chat Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 px-4 py-3 border-b border-slate-200 dark:border-white/10 bg-slate-50/80 dark:bg-white/[0.02]">
        <div className="flex flex-wrap items-center gap-2.5 min-w-0">
          <label
            htmlFor="assistant-lesson-scope"
            className="text-xs font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap"
          >
            نطاق البحث في المنهج:
          </label>
          <select
            id="assistant-lesson-scope"
            value={selectedLessonCode}
            onChange={(e) => setSelectedLessonCode(e.target.value)}
            className="max-w-[260px] sm:max-w-xs truncate rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-bold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
          >
            <option value="all">كل ملف المنهج المرفق ({knowledge.lessons.length} درساً وملفاً)</option>
            {knowledge.lessons.map((l) => (
              <option key={l.code} value={l.code}>
                {l.title}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={handleClearChat}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-rose-500/10 hover:text-rose-600 dark:hover:text-rose-400 hover:border-rose-500/30 transition cursor-pointer whitespace-nowrap"
        >
          {messages.length > 0 ? <Trash2 className="w-3.5 h-3.5" /> : <PlusCircle className="w-3.5 h-3.5" />}
          <span>محادثة جديدة / مسح السجل</span>
        </button>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-5 space-y-4 custom-scrollbar">
        {messages.length === 0 ? (
          <div className="max-w-2xl mx-auto py-8 text-center space-y-4">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <BookOpen className="w-6 h-6" />
            </div>
            <div className="space-y-1.5">
              <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
                مرحباً بك في المساعد الذكي للمنهج
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-7">
                اسألني أي سؤال أو ارفع صورة مسألة أو استخدم الميكروفون؛ وسأجيبك حصرياً من ملف المنهج المرفق بدقة أرقامه وقوانينه ومعادلاته دون أي معلومات خارجية.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 text-right">
              {[
                'ما معادلات تكوين الأوزون في الستراتوسفير؟',
                'كيف يُحسب الضغط الكلي عند عمق 100 m تحت سطح البحر؟',
                'لماذا يُعد غاز أول أكسيد الكربون CO قاتلاً صامتاً؟',
                'قارن بين النسيج البرانشيمي والكولنشيمي والإسكلرنشيمي',
              ].map((sample) => (
                <button
                  key={sample}
                  type="button"
                  onClick={() => void submitQuery(sample)}
                  className="p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50/80 dark:bg-white/[0.03] hover:border-emerald-500/50 hover:bg-emerald-500/5 text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200 transition text-right cursor-pointer"
                >
                  {sample}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';
            const sourcesOpen = !!openSourcesMap[msg.id];
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-start' : 'items-end'}`}
              >
                <div
                  className={`max-w-[92%] sm:max-w-[82%] rounded-2xl px-4 py-3.5 border ${
                    isUser
                      ? 'bg-emerald-600 text-white border-emerald-500'
                      : 'bg-slate-50 dark:bg-slate-900/90 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-white/10'
                  }`}
                >
                  {msg.imageDataUrl && (
                    <div className="mb-2.5 overflow-hidden rounded-xl border border-white/20 max-w-xs">
                      <img
                        src={msg.imageDataUrl}
                        alt="صورة السؤال المرفقة"
                        className="w-full h-auto max-h-56 object-contain bg-black/20"
                      />
                    </div>
                  )}

                  {isUser ? (
                    <p className="text-sm leading-7 whitespace-pre-wrap">{msg.content}</p>
                  ) : (
                    <CurriculumMathText text={msg.content} />
                  )}

                  {/* Footer row of message */}
                  <div
                    className={`mt-2.5 pt-2 border-t flex flex-wrap items-center justify-between gap-2 text-[11px] ${
                      isUser
                        ? 'border-white/20 text-emerald-100'
                        : 'border-slate-200 dark:border-white/10 text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span>{msg.timestamp}</span>
                      {!isUser && msg.modeLabel && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{msg.modeLabel}</span>
                        </>
                      )}
                    </div>

                    {!isUser && (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleToggleSpeak(msg)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-slate-700 dark:text-slate-200 hover:text-emerald-600 dark:hover:text-emerald-400 font-bold transition cursor-pointer"
                        >
                          {speakingMsgId === msg.id ? (
                            <>
                              <VolumeX className="w-3.5 h-3.5" />
                              <span>إيقاف الصوت</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5" />
                              <span>استمع للشرح</span>
                            </>
                          )}
                        </button>

                        {msg.sources && msg.sources.length > 0 && (
                          <button
                            type="button"
                            onClick={() =>
                              setOpenSourcesMap((prev) => ({
                                ...prev,
                                [msg.id]: !prev[msg.id],
                              }))
                            }
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-slate-700 dark:text-slate-200 hover:text-emerald-600 dark:hover:text-emerald-400 font-bold transition cursor-pointer"
                          >
                            <span>المصادر ({msg.sources.length})</span>
                            {sourcesOpen ? (
                              <ChevronUp className="w-3.5 h-3.5" />
                            ) : (
                              <ChevronDown className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Retrieved Exclusive Sources Accordion */}
                  {!isUser && sourcesOpen && msg.sources && msg.sources.length > 0 && (
                    <div className="mt-2.5 space-y-2 border-t border-slate-200 dark:border-white/10 pt-2.5">
                      {msg.sources.map((src, sIdx) => (
                        <div
                          key={`${msg.id}-src-${sIdx}`}
                          className="rounded-xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-white/10 p-2.5 text-xs space-y-1"
                        >
                          <div className="font-bold text-emerald-700 dark:text-emerald-400">
                            {src.sourceTitle}
                          </div>
                          <p className="text-slate-600 dark:text-slate-300 leading-5">
                            {src.snippet}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}

        {isSending && (
          <div className="flex justify-end">
            <div className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-900 px-4 py-3 text-xs font-bold text-slate-700 dark:text-slate-200">
              <Loader2 className="w-4 h-4 animate-spin text-emerald-500" />
              <span>جارٍ البحث في ملف المنهج المرفق وصياغة الإجابة...</span>
            </div>
          </div>
        )}
        <div ref={scrollEndRef} />
      </div>

      {/* Quick Action Chips + Input Composer */}
      <div className="border-t border-slate-200 dark:border-white/10 bg-slate-50/90 dark:bg-slate-950/90 p-3 sm:p-4 space-y-3">
        {/* Required 4 Quick Action Chips */}
        <div
          aria-label="أزرار الإجراءات السريعة"
          className="flex items-center gap-2 overflow-x-auto pb-1 custom-scrollbar"
        >
          {QUICK_ACTION_CHIPS.map((chip) => (
            <button
              key={chip.label}
              type="button"
              disabled={isSending}
              onClick={() => handleQuickChip(chip)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 hover:border-emerald-500/60 hover:bg-emerald-500/10 text-xs font-bold text-slate-800 dark:text-slate-200 transition whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
            >
              {chip.label}
            </button>
          ))}
        </div>

        {/* Attached Image Preview */}
        {attachedImage && (
          <div className="flex items-center justify-between gap-3 rounded-xl border border-emerald-500/35 bg-emerald-500/10 px-3 py-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <img
                src={attachedImage}
                alt="معاينة الصورة"
                className="w-10 h-10 rounded-lg object-cover border border-white/20 shrink-0"
              />
              <span className="text-xs font-bold text-emerald-800 dark:text-emerald-200 truncate">
                صورة مرفقة: {attachedImageName}
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setAttachedImage(null);
                setAttachedImageName('');
              }}
              aria-label="إزالة الصورة"
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-black/10 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Composer Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void submitQuery(inputText);
          }}
          className="flex items-end gap-2"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImagePick}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="رفع صورة سؤال"
            aria-label="رفع صورة سؤال"
            className="min-h-[44px] min-w-[44px] rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:border-emerald-500/50 hover:text-emerald-600 dark:hover:text-emerald-400 flex items-center justify-center transition cursor-pointer shrink-0"
          >
            <ImagePlus className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleToggleVoiceInput}
            title={isListening ? 'إيقاف التسجيل الصوتي' : 'تحدث بالعربية (ar-EG)'}
            aria-label="التحدث بالميكروفون"
            className={`min-h-[44px] min-w-[44px] rounded-xl border flex items-center justify-center transition cursor-pointer shrink-0 ${
              isListening
                ? 'border-rose-500 bg-rose-500 text-white'
                : 'border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:border-emerald-500/50 hover:text-emerald-600 dark:hover:text-emerald-400'
            }`}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                void submitQuery(inputText);
              }
            }}
            rows={1}
            placeholder={
              isListening
                ? 'جارٍ الاستماع باللهجة المصرية (ar-EG)...'
                : 'اكتب سؤالك من المنهج المرفق هنا... (Enter للإرسال)'
            }
            className="flex-1 min-h-[44px] max-h-28 resize-none rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />

          <button
            type="submit"
            disabled={isSending || (!inputText.trim() && !attachedImage)}
            aria-label="إرسال السؤال"
            className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-sm inline-flex items-center gap-1.5 transition cursor-pointer shrink-0"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">إرسال</span>
          </button>
        </form>
      </div>
    </div>
  );
}
