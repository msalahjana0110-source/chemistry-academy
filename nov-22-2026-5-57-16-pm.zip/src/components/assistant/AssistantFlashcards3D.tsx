import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  RotateCw,
  Shuffle,
} from 'lucide-react';
import type { ParsedCurriculumKnowledge } from '../../utils/curriculumRag';
import { CurriculumMathText } from '../CurriculumMathText';

const MASTERED_STORAGE_KEY = 'smart_curriculum_flashcards_mastered_v1';

interface AssistantFlashcards3DProps {
  knowledge: ParsedCurriculumKnowledge;
}

export function AssistantFlashcards3D({ knowledge }: AssistantFlashcards3DProps) {
  const [lessonFilter, setLessonFilter] = useState<string>('all');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [shuffleSeed, setShuffleSeed] = useState(0);
  const [masteredIds, setMasteredIds] = useState<string[]>(() => {
    try {
      const raw = window.localStorage.getItem(MASTERED_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? (parsed as string[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(MASTERED_STORAGE_KEY, JSON.stringify(masteredIds));
    } catch {
      // ignore
    }
  }, [masteredIds]);

  const lessonOptions = useMemo(() => {
    const map = new Map<string, string>();
    for (const c of knowledge.flashcards) {
      if (!map.has(c.lessonCode)) {
        map.set(c.lessonCode, c.lessonLabel);
      }
    }
    return Array.from(map.entries()).sort((a, b) => Number(a[0]) - Number(b[0]));
  }, [knowledge.flashcards]);

  const deck = useMemo(() => {
    const filtered =
      lessonFilter === 'all'
        ? knowledge.flashcards
        : knowledge.flashcards.filter((c) => c.lessonCode === lessonFilter);
    if (shuffleSeed === 0) return filtered;
    const copy = [...filtered];
    // Deterministic seeded shuffle
    let s = shuffleSeed;
    for (let i = copy.length - 1; i > 0; i--) {
      s = (s * 1664525 + 1013904223) % 4294967296;
      const j = s % (i + 1);
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }, [knowledge.flashcards, lessonFilter, shuffleSeed]);

  const safeIdx = deck.length > 0 ? Math.min(currentIdx, deck.length - 1) : 0;
  const activeCard = deck[safeIdx] ?? null;
  const isMastered = activeCard ? masteredIds.includes(activeCard.id) : false;

  const masteredInDeck = deck.filter((c) => masteredIds.includes(c.id)).length;
  const pct = deck.length > 0 ? Math.round((masteredInDeck / deck.length) * 100) : 0;

  const goPrev = () => {
    setFlipped(false);
    setCurrentIdx((prev) => (prev <= 0 ? Math.max(deck.length - 1, 0) : prev - 1));
  };

  const goNext = () => {
    setFlipped(false);
    setCurrentIdx((prev) => (prev >= deck.length - 1 ? 0 : prev + 1));
  };

  const toggleMastered = () => {
    if (!activeCard) return;
    setMasteredIds((prev) =>
      prev.includes(activeCard.id)
        ? prev.filter((id) => id !== activeCard.id)
        : [...prev, activeCard.id]
    );
  };

  if (deck.length === 0 || !activeCard) {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-10 text-center text-sm text-slate-500">
        لا توجد بطاقات مراجعة في ملف المنهج المرفق حالياً.
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Controls & Progress */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
              بطاقات المراجعة ثلاثية الأبعاد (3D)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums mt-0.5">
              الإتقان: {masteredInDeck} / {deck.length} ({pct}%) · البطاقة {safeIdx + 1} من {deck.length}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              aria-label="تصفية البطاقات حسب الدرس"
              value={lessonFilter}
              onChange={(e) => {
                setLessonFilter(e.target.value);
                setCurrentIdx(0);
                setFlipped(false);
              }}
              className="max-w-[240px] truncate rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-xs font-bold text-slate-900 dark:text-slate-100 cursor-pointer"
            >
              <option value="all">كل البطاقات ({knowledge.flashcards.length})</option>
              {lessonOptions.map(([code, label]) => (
                <option key={code} value={code}>
                  {label}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => {
                setShuffleSeed((s) => s + 1);
                setCurrentIdx(0);
                setFlipped(false);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:bg-emerald-500/10 text-xs font-bold text-slate-700 dark:text-slate-200 transition cursor-pointer"
            >
              <Shuffle className="w-3.5 h-3.5" />
              <span>خلط عشوائي</span>
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-2 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
          <div
            className="h-full bg-emerald-500 transition-all duration-300"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      {/* 3D Flip Stage */}
      <div className="flashcard-scene">
        <motion.div
          onClick={() => setFlipped((f) => !f)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setFlipped((f) => !f);
            }
          }}
          aria-label="اقلب البطاقة لعرض الإجابة"
          animate={{ rotateY: flipped ? 180 : 0 }}
          transition={{ type: 'spring', stiffness: 220, damping: 24 }}
          className="flashcard-motion-inner relative w-full min-h-[290px] sm:min-h-[320px] cursor-pointer"
        >
          {/* Front Face */}
          <div className="flashcard-face absolute inset-0 rounded-2xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-950 p-6 sm:p-8 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="font-bold text-emerald-600 dark:text-emerald-400">
                الوجه الأمامي · السؤال
              </span>
              <span>{activeCard.lessonLabel}</span>
            </div>

            <div className="my-auto py-4 text-center">
              <div className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white leading-9">
                <CurriculumMathText text={activeCard.front} />
              </div>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-slate-500 dark:text-slate-400">
              <RotateCw className="w-3.5 h-3.5" />
              <span>اضغط على البطاقة لقلبها ورؤية الإجابة النموذجية</span>
            </div>
          </div>

          {/* Back Face */}
          <div className="flashcard-face flashcard-back absolute inset-0 rounded-2xl border border-emerald-500/45 bg-emerald-50 dark:bg-slate-900 p-6 sm:p-8 flex flex-col justify-between shadow-lg">
            <div className="flex items-center justify-between text-xs text-emerald-700 dark:text-emerald-300">
              <span className="font-extrabold">الوجه الخلفي · الإجابة النموذجية</span>
              <span>بطاقة #{activeCard.cardNumber}</span>
            </div>

            <div className="my-auto py-4 text-center">
              <div className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100 leading-8">
                <CurriculumMathText text={activeCard.back} />
              </div>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-400">
              <RotateCw className="w-3.5 h-3.5" />
              <span>اضغط للعودة إلى السؤال</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Navigation & Mastery Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={goPrev}
          className="min-h-[44px] inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-950/75 text-sm font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" />
          <span>السابقة</span>
        </button>

        <button
          type="button"
          onClick={toggleMastered}
          className={`min-h-[44px] inline-flex items-center gap-2 px-5 py-2 rounded-xl border text-sm font-bold transition cursor-pointer ${
            isMastered
              ? 'border-emerald-500 bg-emerald-600 text-white'
              : 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/20'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{isMastered ? 'تم الإتقان ✓' : 'تحديد كمُتقَنة'}</span>
        </button>

        <button
          type="button"
          onClick={goNext}
          className="min-h-[44px] inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-950/75 text-sm font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition cursor-pointer"
        >
          <span>التالية</span>
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
