import React, { useMemo, useState } from 'react';
import { Calculator, ChevronDown, ChevronUp, FlaskConical, MessageSquareText } from 'lucide-react';
import type { ParsedCurriculumKnowledge, ParsedEquationOrLaw } from '../../utils/curriculumRag';
import { CurriculumMathText, KatexFormula } from '../CurriculumMathText';

interface EquationsExplorerToolProps {
  knowledge: ParsedCurriculumKnowledge;
  onAskInChat: (prompt: string, lessonCode?: string) => void;
}

function InteractiveLawCalculator({
  calculatorId,
}: {
  calculatorId: NonNullable<ParsedEquationOrLaw['calculatorId']>;
}) {
  const [depthM, setDepthM] = useState('100');
  const [tempC, setTempC] = useState('25');
  const [surfaceC, setSurfaceC] = useState('32');
  const [heightKm, setHeightKm] = useState('2');
  const [massKg, setMassKg] = useState('2');
  const [deltaT, setDeltaT] = useState('5');
  const [mmHg, setMmHg] = useState('750');

  if (calculatorId === 'water-pressure') {
    const h = Number(depthM) || 0;
    const pWater = h / 10;
    const pTotal = 1 + pWater;
    const pPascal = pTotal * 101300;
    return (
      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3.5 space-y-2.5">
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-700 dark:text-emerald-300">
          <Calculator className="w-3.5 h-3.5" />
          <span>حاسبة القانون الفورية (الضغط المائي والكلي)</span>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
            <span>العمق h (متر):</span>
            <input
              type="number"
              min="0"
              value={depthM}
              onChange={(e) => setDepthM(e.target.value)}
              className="w-24 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-2.5 py-1 text-xs font-mono tabular-nums text-slate-900 dark:text-white"
            />
          </label>
          <div className="text-xs font-bold text-slate-800 dark:text-slate-200 tabular-nums space-x-3 space-x-reverse">
            <span>ضغط الماء: <strong className="text-emerald-600 dark:text-emerald-400">{pWater.toFixed(2)} atm</strong></span>
            <span>·</span>
            <span>الضغط الكلي: <strong className="text-emerald-600 dark:text-emerald-400">{pTotal.toFixed(2)} atm</strong></span>
            <span>·</span>
            <span dir="ltr" className="formula-ltr">{pPascal.toExponential(3)} N/m²</span>
          </div>
        </div>
      </div>
    );
  }

  if (calculatorId === 'temp-convert') {
    const c = Number(tempC) || 0;
    const k = c + 273;
    const f = 1.8 * c + 32;
    return (
      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3.5 space-y-2.5">
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-700 dark:text-emerald-300">
          <Calculator className="w-3.5 h-3.5" />
          <span>محوّل درجات الحرارة الثلاث الفوري</span>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
            <span>الدرجة بالسيليزي (°C):</span>
            <input
              type="number"
              value={tempC}
              onChange={(e) => setTempC(e.target.value)}
              className="w-24 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-2.5 py-1 text-xs font-mono tabular-nums text-slate-900 dark:text-white"
            />
          </label>
          <div className="text-xs font-bold text-slate-800 dark:text-slate-200 tabular-nums flex flex-wrap gap-3">
            <span>كلفن: <strong className="text-emerald-600 dark:text-emerald-400">{k.toFixed(2)} K</strong></span>
            <span>·</span>
            <span>فهرنهايت: <strong className="text-emerald-600 dark:text-emerald-400">{f.toFixed(2)} °F</strong></span>
          </div>
        </div>
      </div>
    );
  }

  if (calculatorId === 'troposphere-temp') {
    const ts = Number(surfaceC) || 0;
    const h = Number(heightKm) || 0;
    const th = ts - 6.5 * h;
    return (
      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3.5 space-y-2.5">
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-700 dark:text-emerald-300">
          <Calculator className="w-3.5 h-3.5" />
          <span>حاسبة حرارة التروبوسفير بالارتفاع</span>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <span>حرارة السطح (°C):</span>
            <input
              type="number"
              value={surfaceC}
              onChange={(e) => setSurfaceC(e.target.value)}
              className="w-20 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-2 py-1 text-xs font-mono tabular-nums"
            />
          </label>
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <span>الارتفاع (km):</span>
            <input
              type="number"
              step="0.1"
              value={heightKm}
              onChange={(e) => setHeightKm(e.target.value)}
              className="w-20 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-2 py-1 text-xs font-mono tabular-nums"
            />
          </label>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 tabular-nums">
            الحرارة عند الارتفاع: <strong className="text-emerald-600 dark:text-emerald-400">{th.toFixed(2)} °C</strong>
          </span>
        </div>
      </div>
    );
  }

  if (calculatorId === 'heat-quantity') {
    const m = Number(massKg) || 0;
    const dt = Number(deltaT) || 0;
    const q = m * 4180 * dt;
    return (
      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3.5 space-y-2.5">
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-700 dark:text-emerald-300">
          <Calculator className="w-3.5 h-3.5" />
          <span>حاسبة كمية الحرارة للماء (c = 4180 J/kg.°C)</span>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <span>الكتلة m (kg):</span>
            <input
              type="number"
              step="0.1"
              value={massKg}
              onChange={(e) => setMassKg(e.target.value)}
              className="w-20 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-2 py-1 text-xs font-mono tabular-nums"
            />
          </label>
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <span>Δt (°C):</span>
            <input
              type="number"
              value={deltaT}
              onChange={(e) => setDeltaT(e.target.value)}
              className="w-20 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-2 py-1 text-xs font-mono tabular-nums"
            />
          </label>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 tabular-nums">
            كمية الحرارة Q: <strong className="text-emerald-600 dark:text-emerald-400">{q.toLocaleString('en-US')} J</strong>
          </span>
        </div>
      </div>
    );
  }

  // pressure-convert
  const pMm = Number(mmHg) || 0;
  const pNm2 = (pMm / 760) * 101300;
  const pMb = pNm2 / 100;
  const pAtm = pMm / 760;
  return (
    <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3.5 space-y-2.5">
      <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-700 dark:text-emerald-300">
        <Calculator className="w-3.5 h-3.5" />
        <span>محوّل وحدات الضغط الجوي الفوري</span>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
          <span>الضغط (mmHg):</span>
          <input
            type="number"
            value={mmHg}
            onChange={(e) => setMmHg(e.target.value)}
            className="w-24 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 px-2 py-1 text-xs font-mono tabular-nums"
          />
        </label>
        <div className="text-xs font-bold text-slate-800 dark:text-slate-200 tabular-nums flex flex-wrap gap-2.5">
          <span><strong className="text-emerald-600 dark:text-emerald-400">{pNm2.toFixed(2)} N/m²</strong></span>
          <span>·</span>
          <span><strong className="text-emerald-600 dark:text-emerald-400">{pMb.toFixed(2)} mb</strong></span>
          <span>·</span>
          <span><strong className="text-emerald-600 dark:text-emerald-400">{pAtm.toFixed(3)} atm</strong></span>
        </div>
      </div>
    </div>
  );
}

export function EquationsExplorerTool({
  knowledge,
  onAskInChat,
}: EquationsExplorerToolProps) {
  const [filter, setFilter] = useState<'all' | 'equation' | 'law'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(
    knowledge.equationsAndLaws[0]?.id ?? null
  );

  const items = useMemo(() => {
    if (filter === 'all') return knowledge.equationsAndLaws;
    return knowledge.equationsAndLaws.filter((item) => item.category === filter);
  }, [knowledge.equationsAndLaws, filter]);

  const eqCount = knowledge.equationsAndLaws.filter((i) => i.category === 'equation').length;
  const lawCount = knowledge.equationsAndLaws.filter((i) => i.category === 'law').length;

  return (
    <div className="space-y-4">
      {/* Header & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-4">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
            مفكك وموازن المعادلات والقوانين المنهجية
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            جميع المعادلات الكيميائية الموزونة والقوانين المستخرجة حصرياً من ملف المنهج المرفق مع عرض KaTeX + mhchem وخطوات التفكيك.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
          {[
            { id: 'all' as const, label: `الكل (${knowledge.equationsAndLaws.length})` },
            { id: 'equation' as const, label: `المعادلات (${eqCount})` },
            { id: 'law' as const, label: `القوانين (${lawCount})` },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                filter === tab.id
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Cards Grid */}
      {items.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-10 text-center text-sm text-slate-500">
          لا توجد معادلات أو قوانين في هذا التصنيف داخل الملف المرفق حالياً.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {items.map((item) => {
            const isOpen = expandedId === item.id;
            return (
              <article
                key={item.id}
                className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-4 sm:p-5 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        {item.category === 'equation' ? 'معادلة كيميائية موزونة' : 'قانون رياضي / فيزيائي'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.lessonLabel}</span>
                    </div>
                    <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white mt-0.5">
                      {item.title}
                    </h3>
                  </div>

                  <button
                    type="button"
                    onClick={() => setExpandedId(isOpen ? null : item.id)}
                    aria-expanded={isOpen}
                    className="min-h-[36px] px-2.5 py-1 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 inline-flex items-center gap-1 shrink-0 cursor-pointer"
                  >
                    <span>{isOpen ? 'إخفاء الخطوات' : 'تفكيك الخطوات'}</span>
                    {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* Rendered KaTeX + mhchem Formula (Strict LTR isolated) */}
                <KatexFormula expression={item.katexExpression} displayMode />

                {/* Expanded Step-by-Step Breakdown + Calculator */}
                {isOpen && (
                  <div className="space-y-3 pt-1 border-t border-slate-200 dark:border-white/10">
                    <div className="space-y-1.5">
                      <div className="text-xs font-extrabold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <FlaskConical className="w-3.5 h-3.5 text-emerald-500" />
                        <span>تفاصيل المنهج المرفق:</span>
                      </div>
                      {item.details.map((d, idx) => (
                        <div key={idx} className="text-xs text-slate-600 dark:text-slate-300 leading-6">
                          <CurriculumMathText text={d} />
                        </div>
                      ))}
                    </div>

                    <div className="space-y-1.5">
                      <div className="text-xs font-extrabold text-slate-700 dark:text-slate-300">
                        خطوات الفهم والتطبيق:
                      </div>
                      <ol className="space-y-1 pr-4 list-decimal text-xs text-slate-600 dark:text-slate-300 leading-6">
                        {item.steps.map((step, sIdx) => (
                          <li key={sIdx}>{step}</li>
                        ))}
                      </ol>
                    </div>

                    {item.calculatorId && (
                      <InteractiveLawCalculator calculatorId={item.calculatorId} />
                    )}

                    <button
                      type="button"
                      onClick={() =>
                        onAskInChat(
                          `اشرح لي خطوة بخطوة ${item.title} (${item.formulaRaw}) مع مثال تطبيقي من المنهج المرفق فقط.`,
                          item.lessonCode !== '16' ? item.lessonCode : 'all'
                        )
                      }
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition cursor-pointer"
                    >
                      <MessageSquareText className="w-3.5 h-3.5" />
                      <span>اشرحها بالمساعد الذكي خطوة بخطوة</span>
                    </button>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
