import React, { useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileText,
  RotateCcw,
  Save,
  Upload,
  X,
} from 'lucide-react';
import type { ParsedCurriculumKnowledge } from '../../utils/curriculumRag';

interface KnowledgeManagerModalProps {
  open: boolean;
  sourceName: string;
  isCustom: boolean;
  rawText: string;
  knowledge: ParsedCurriculumKnowledge;
  onClose: () => void;
  onReplaceKnowledge: (nextText: string, nextSourceName: string) => void;
  onResetDefault: () => void;
}

export function KnowledgeManagerModal({
  open,
  sourceName,
  isCustom,
  rawText,
  knowledge,
  onClose,
  onReplaceKnowledge,
  onResetDefault,
}: KnowledgeManagerModalProps) {
  const [draftText, setDraftText] = useState(rawText);
  const [draftName, setDraftName] = useState(sourceName);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!open) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const pieces: string[] = [];
    const names: string[] = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      names.push(f.name);
      const txt = await f.text();
      pieces.push(txt.replace(/^\uFEFF/, '').trim());
    }
    const merged = pieces.join('\n\n');
    if (merged.trim().length < 20) {
      setStatusMsg('الملف المرفوع فارغ أو قصير جداً.');
      return;
    }
    const label = names.length === 1 ? names[0] : `${names[0]} (+${names.length - 1} ملفات)`;
    setDraftText(merged);
    setDraftName(label);
    onReplaceKnowledge(merged, label);
    setStatusMsg(`تم تبديل ملف المنهج الخاص بنجاح (${merged.length.toLocaleString('en-US')} حرف).`);
    e.target.value = '';
  };

  const handleSaveManual = () => {
    if (draftText.trim().length < 20) {
      setStatusMsg('أدخل نص منهج صالحاً (20 حرفاً على الأقل).');
      return;
    }
    onReplaceKnowledge(draftText.trim(), draftName.trim() || 'ملف منهج مخصص');
    setStatusMsg('تم حفظ وتفعيل نص المنهج الجديد محلياً بنجاح.');
  };

  const handleDownloadCurrent = () => {
    const blob = new Blob([rawText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'curriculum_knowledge.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-label="تحديث وتبديل ملف المنهج الخاص"
    >
      <div className="w-full max-w-3xl max-h-[90vh] flex flex-col rounded-2xl border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-950 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 px-5 py-4 border-b border-slate-200 dark:border-white/10">
          <div className="min-w-0">
            <h2 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-white">
              تحديث / تبديل ملف المنهج الخاص
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              المساعد يعتمد حصرياً على هذا الملف فقط ولا يستخدم أي نصوص خارجية أو نصوص من واجهة الموقع.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="min-h-[40px] min-w-[40px] rounded-xl border border-slate-200 dark:border-white/10 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 custom-scrollbar">
          {/* Active File Stats */}
          <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.03] p-4 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                <FileText className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>المصدر النشط: {sourceName}</span>
                <span className="text-slate-400">·</span>
                <span className="text-emerald-600 dark:text-emerald-400">
                  {isCustom ? 'ملف مخصص محلياً' : 'ملف المنهج المرفق الافتراضي'}
                </span>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              <span>الحجم: {knowledge.rawLength.toLocaleString('en-US')} حرف</span>
              <span>·</span>
              <span>المقاطع المفهرسة: {knowledge.chunks.length}</span>
              <span>·</span>
              <span>الدروس والملفات: {knowledge.lessons.length}</span>
              <span>·</span>
              <span>البطاقات: {knowledge.flashcards.length}</span>
              <span>·</span>
              <span>المعادلات والقوانين: {knowledge.equationsAndLaws.length}</span>
              <span>·</span>
              <span>أسئلة الاختيار: {knowledge.mcqs.length}</span>
            </div>
          </div>

          {/* Upload / Actions Row */}
          <div className="flex flex-wrap items-center gap-2.5">
            <input
              ref={fileInputRef}
              type="file"
              accept=".txt,.md,text/plain"
              multiple
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold transition cursor-pointer whitespace-nowrap"
            >
              <Upload className="w-4 h-4" />
              <span>رفع ملف منهج جديد (.txt / .md)</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadCurrent}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 text-xs sm:text-sm font-bold transition cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              <span>تحميل الملف الحالي</span>
            </button>

            {isCustom && (
              <button
                type="button"
                onClick={() => {
                  onResetDefault();
                  setStatusMsg('تمت استعادة ملف المنهج الافتراضي المرفق (IS_04 – IS_18).');
                }}
                className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300 hover:bg-amber-500/20 text-xs sm:text-sm font-bold transition cursor-pointer whitespace-nowrap"
              >
                <RotateCcw className="w-4 h-4" />
                <span>استعادة الملف الافتراضي</span>
              </button>
            )}
          </div>

          {statusMsg && (
            <div className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-2.5 text-xs font-bold text-emerald-700 dark:text-emerald-300">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{statusMsg}</span>
            </div>
          )}

          {/* Direct Paste / Edit Text */}
          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label
                htmlFor="curriculum-name-input"
                className="text-xs font-bold text-slate-700 dark:text-slate-300"
              >
                أو لصق / تعديل نص المنهج مباشرة:
              </label>
              <input
                id="curriculum-name-input"
                type="text"
                value={draftName}
                onChange={(e) => setDraftName(e.target.value)}
                placeholder="اسم ملف المنهج"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <textarea
              value={draftText}
              onChange={(e) => setDraftText(e.target.value)}
              rows={9}
              placeholder="الصق هنا كامل نص ملف التفكير أو المنهج الخاص بك..."
              className="w-full rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900/80 p-3.5 text-xs sm:text-sm leading-6 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 custom-scrollbar"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 px-5 py-3.5 border-t border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.02]">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            يُحفظ التعديل محلياً على جهازك فقط (مجاني 100%)
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
            >
              إغلاق
            </button>
            <button
              type="button"
              onClick={handleSaveManual}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>حفظ وتفعيل النص</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
