import React, { useEffect, useMemo, useState } from 'react';
import { CalendarDays, Check, Copy, CheckSquare, Square } from 'lucide-react';
import {
  buildRevisionSchedule,
  type ParsedCurriculumKnowledge,
} from '../../utils/curriculumRag';

const PLANNER_DONE_KEY = 'smart_curriculum_planner_done_v1';

interface RevisionPlannerToolProps {
  knowledge: ParsedCurriculumKnowledge;
  onNotify: (msg: string, tone?: 'success' | 'info' | 'error') => void;
}

export function RevisionPlannerTool({ knowledge, onNotify }: RevisionPlannerToolProps) {
  const [daysLeft, setDaysLeft] = useState(7);
  const [hoursPerDay, setHoursPerDay] = useState(2);
  const [focusMode, setFocusMode] = useState<'balanced' | 'fast' | 'advanced'>('balanced');
  const [copied, setCopied] = useState(false);
  const [completedTasks, setCompletedTasks] = useState<string[]>(() => {
    try {
      const raw = window.localStorage.getItem(PLANNER_DONE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? (parsed as string[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(PLANNER_DONE_KEY, JSON.stringify(completedTasks));
    } catch {
      // ignore
    }
  }, [completedTasks]);

  const schedule = useMemo(
    () => buildRevisionSchedule(knowledge.lessons, daysLeft, hoursPerDay, focusMode),
    [knowledge.lessons, daysLeft, hoursPerDay, focusMode]
  );

  const toggleTask = (taskKey: string) => {
    setCompletedTasks((prev) =>
      prev.includes(taskKey) ? prev.filter((k) => k !== taskKey) : [...prev, taskKey]
    );
  };

  const handleCopySchedule = async () => {
    const text = schedule
      .map(
        (d) =>
          `${d.title} (${d.estimatedHours} ساعات)\n` +
          d.tasks.map((t, i) => `  ${i + 1}. ${t}`).join('\n')
      )
      .join('\n\n');
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      onNotify('تم نسخ جدول المراجعة بنجاح.');
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      onNotify('تعذّر النسخ التلقائي، يمكنك تحديد الجدول ونسخه يدوياً.', 'info');
    }
  };

  return (
    <div className="space-y-5">
      {/* Controls */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <CalendarDays className="w-5 h-5 text-emerald-500" />
              <span>صانع جدول المراجعة الذكي حسب الأيام المتبقية</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              يوزّع جميع الدروس الموجودة في ملف المنهج المرفق توزيعاً متوازناً مع مهام عملية يومية.
            </p>
          </div>

          <button
            type="button"
            onClick={() => void handleCopySchedule()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 hover:bg-emerald-500/10 text-xs font-bold text-slate-700 dark:text-slate-200 transition cursor-pointer whitespace-nowrap"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ' : 'نسخ الجدول نصياً'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
              <label htmlFor="days-left-range">عدد الأيام المتبقية للامتحان</label>
              <span className="text-emerald-600 dark:text-emerald-400 tabular-nums">{daysLeft} أيام</span>
            </div>
            <input
              id="days-left-range"
              type="range"
              min={1}
              max={21}
              value={daysLeft}
              onChange={(e) => setDaysLeft(Number(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
              <label htmlFor="hours-day-range">ساعات المذاكرة اليومية</label>
              <span className="text-emerald-600 dark:text-emerald-400 tabular-nums">{hoursPerDay} ساعات</span>
            </div>
            <input
              id="hours-day-range"
              type="range"
              min={1}
              max={8}
              value={hoursPerDay}
              onChange={(e) => setHoursPerDay(Number(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer"
            />
          </div>

          <div className="space-y-1.5">
            <span className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              نمط المراجعة
            </span>
            <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
              {[
                { id: 'balanced' as const, label: 'متوازن' },
                { id: 'fast' as const, label: 'سريع' },
                { id: 'advanced' as const, label: 'متفوقين' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setFocusMode(m.id)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    focusMode === m.id
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Day Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {schedule.map((day) => (
          <article
            key={day.day}
            className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-4 sm:p-5 space-y-3"
          >
            <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-200 dark:border-white/10">
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
                {day.title}
              </h3>
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 tabular-nums whitespace-nowrap">
                {day.estimatedHours} ساعات
              </span>
            </div>

            <div className="space-y-1">
              {day.lessons.map((l) => (
                <div
                  key={`${day.day}-${l.code}`}
                  className="text-xs font-bold text-slate-700 dark:text-slate-300"
                >
                  • {l.title}
                </div>
              ))}
            </div>

            <div className="space-y-2 pt-1">
              {day.tasks.map((task, idx) => {
                const taskKey = `d${daysLeft}-m${focusMode}-${day.day}-${idx}`;
                const done = completedTasks.includes(taskKey);
                return (
                  <button
                    key={taskKey}
                    type="button"
                    onClick={() => toggleTask(taskKey)}
                    className={`w-full flex items-start gap-2.5 p-2.5 rounded-xl border text-right text-xs transition cursor-pointer ${
                      done
                        ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-800 dark:text-emerald-200 line-through'
                        : 'border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.02] text-slate-700 dark:text-slate-200 hover:border-emerald-500/40'
                    }`}
                  >
                    {done ? (
                      <CheckSquare className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    )}
                    <span className="leading-5">{task}</span>
                  </button>
                );
              })}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
