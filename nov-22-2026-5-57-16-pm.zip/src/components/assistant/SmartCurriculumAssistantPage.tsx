import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  Bot,
  CalendarDays,
  Code2,
  FileUp,
  FlaskConical,
  HelpCircle,
  Layers,
  Loader2,
  MessageSquareText,
  Moon,
  Sun,
} from 'lucide-react';
import {
  parseCurriculumKnowledge,
  type ParsedCurriculumKnowledge,
} from '../../utils/curriculumRag';
import { AssistantChatPanel } from './AssistantChatPanel';
import { AssistantFlashcards3D } from './AssistantFlashcards3D';
import { EquationsExplorerTool } from './EquationsExplorerTool';
import { KnowledgeManagerModal } from './KnowledgeManagerModal';
import { RevisionPlannerTool } from './RevisionPlannerTool';
import { TeacherJsonGeneratorTool } from './TeacherJsonGeneratorTool';
import { WhyWrongTool } from './WhyWrongTool';

type AssistantToolTab =
  | 'chat'
  | 'why-wrong'
  | 'equations'
  | 'flashcards'
  | 'planner'
  | 'teacher-json';

const CUSTOM_KNOWLEDGE_TEXT_KEY = 'smart_curriculum_custom_knowledge_text_v1';
const CUSTOM_KNOWLEDGE_NAME_KEY = 'smart_curriculum_custom_knowledge_name_v1';
const DEFAULT_KNOWLEDGE_NAME = 'ملف المنهج المرفق الكامل (IS_04 – IS_18)';

const TOOL_TABS: ReadonlyArray<{
  id: AssistantToolTab;
  label: string;
  icon: typeof MessageSquareText;
}> = [
  { id: 'chat', label: 'المحادثة الذكية', icon: MessageSquareText },
  { id: 'why-wrong', label: 'لماذا أخطأت؟', icon: HelpCircle },
  { id: 'equations', label: 'المعادلات والقوانين', icon: FlaskConical },
  { id: 'flashcards', label: 'بطاقات 3D', icon: Layers },
  { id: 'planner', label: 'جدول المراجعة', icon: CalendarDays },
  { id: 'teacher-json', label: 'أداة المعلم JSON', icon: Code2 },
];

interface SmartCurriculumAssistantPageProps {
  isDark: boolean;
  onToggleTheme: () => void;
  onExitToPlatform: () => void;
  onNotify: (msg: string, tone?: 'success' | 'info' | 'error') => void;
}

export function SmartCurriculumAssistantPage({
  isDark,
  onToggleTheme,
  onExitToPlatform,
  onNotify,
}: SmartCurriculumAssistantPageProps) {
  const [activeTab, setActiveTab] = useState<AssistantToolTab>('chat');
  const [rawKnowledge, setRawKnowledge] = useState<string>('');
  const [sourceName, setSourceName] = useState<string>(DEFAULT_KNOWLEDGE_NAME);
  const [isCustom, setIsCustom] = useState<boolean>(false);
  const [loadingKnowledge, setLoadingKnowledge] = useState<boolean>(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [managerOpen, setManagerOpen] = useState<boolean>(false);
  const [externalPrompt, setExternalPrompt] = useState<{
    text: string;
    lessonCode?: string;
    nonce: number;
  } | null>(null);

  const loadDefaultCurriculumFile = async () => {
    setLoadingKnowledge(true);
    setLoadError(null);
    try {
      const res = await fetch('/curriculum_knowledge.txt', { cache: 'no-store' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      setRawKnowledge(text);
      setSourceName(DEFAULT_KNOWLEDGE_NAME);
      setIsCustom(false);
    } catch {
      setLoadError('تعذّر تحميل ملف المنهج المدمج (curriculum_knowledge.txt). يمكنك رفع ملف بديل من زر تحديث ملف المنهج.');
    } finally {
      setLoadingKnowledge(false);
    }
  };

  useEffect(() => {
    try {
      const customText = window.localStorage.getItem(CUSTOM_KNOWLEDGE_TEXT_KEY);
      const customName = window.localStorage.getItem(CUSTOM_KNOWLEDGE_NAME_KEY);
      if (customText && customText.trim().length >= 20) {
        setRawKnowledge(customText);
        setSourceName(customName || 'ملف منهج مخصص');
        setIsCustom(true);
        setLoadingKnowledge(false);
        return;
      }
    } catch {
      // fallback to bundled file
    }
    void loadDefaultCurriculumFile();
  }, []);

  const knowledge: ParsedCurriculumKnowledge = useMemo(
    () => parseCurriculumKnowledge(rawKnowledge),
    [rawKnowledge]
  );

  const handleReplaceKnowledge = (nextText: string, nextName: string) => {
    setRawKnowledge(nextText);
    setSourceName(nextName);
    setIsCustom(true);
    try {
      window.localStorage.setItem(CUSTOM_KNOWLEDGE_TEXT_KEY, nextText);
      window.localStorage.setItem(CUSTOM_KNOWLEDGE_NAME_KEY, nextName);
    } catch {
      onNotify('تم تفعيل الملف للجلسة الحالية (الحجم أكبر من سعة التخزين الدائم بالمتصفح).', 'info');
      return;
    }
    onNotify(`تم تبديل ملف المنهج الخاص إلى: ${nextName}`);
  };

  const handleResetDefault = () => {
    try {
      window.localStorage.removeItem(CUSTOM_KNOWLEDGE_TEXT_KEY);
      window.localStorage.removeItem(CUSTOM_KNOWLEDGE_NAME_KEY);
    } catch {
      // ignore
    }
    void loadDefaultCurriculumFile();
    onNotify('تمت استعادة ملف المنهج المرفق الافتراضي بنجاح.', 'info');
  };

  const handleAskInChat = (prompt: string, lessonCode?: string) => {
    setActiveTab('chat');
    setExternalPrompt({ text: prompt, lessonCode, nonce: Date.now() });
  };

  return (
    <div
      id="view-assistant-standalone"
      dir="rtl"
      className="min-h-screen flex flex-col bg-slate-50 dark:bg-[#050914] text-slate-900 dark:text-slate-100 relative z-20"
    >
      {/* Dedicated Standalone Top Bar (Completely separate from main academy header) */}
      <header className="sticky top-0 z-40 border-b border-slate-200 dark:border-white/10 bg-white/95 dark:bg-[#070d1e]/95 glass-panel">
        <div className="max-w-[1380px] mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2 sm:gap-4">
          {/* Brand Zone */}
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Bot className="w-5 h-5" />
            </div>
            <span className="font-extrabold text-sm sm:text-lg text-slate-900 dark:text-white whitespace-nowrap truncate">
              <span className="hidden sm:inline">المساعد الذكي للمنهج</span>
              <span className="sm:hidden">المساعد الذكي</span>
            </span>
          </div>

          {/* Primary Actions Zone */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setManagerOpen(true)}
              data-testid="open-knowledge-manager-btn"
              className="min-h-[40px] inline-flex items-center gap-1.5 px-2.5 sm:px-3.5 py-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-xs font-bold transition whitespace-nowrap cursor-pointer"
            >
              <FileUp className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">تحديث / تبديل ملف المنهج الخاص</span>
              <span className="sm:hidden">المنهج</span>
            </button>

            <button
              type="button"
              onClick={onToggleTheme}
              aria-label="تبديل الوضع الليلي والنهاري"
              className="min-h-[40px] min-w-[40px] rounded-xl border border-slate-200 dark:border-white/15 bg-slate-100/80 dark:bg-white/5 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-white/10 flex items-center justify-center transition cursor-pointer"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={onExitToPlatform}
              data-testid="exit-assistant-btn"
              className="min-h-[40px] inline-flex items-center gap-1.5 px-2.5 sm:px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-xs font-bold text-slate-700 dark:text-slate-200 transition whitespace-nowrap cursor-pointer"
            >
              <ArrowRight className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">العودة للمنصة</span>
              <span className="sm:hidden">المنصة</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Standalone Workspace */}
      <main className="flex-1 max-w-[1380px] w-full mx-auto px-4 sm:px-6 py-5 space-y-4">
        {/* Tool Navigation Tabs + Compact Exclusive Knowledge Metadata Line */}
        <div className="flex flex-col gap-2.5">
          {/* Interactive Tool Switcher Tabs */}
          <nav
            aria-label="أدوات المساعد الذكي للمنهج"
            className="flex items-center gap-2 overflow-x-auto pb-1 sm:flex-wrap sm:overflow-visible custom-scrollbar"
          >
            {TOOL_TABS.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  aria-current={active ? 'page' : undefined}
                  className={`min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 cursor-pointer border ${
                    active
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-white dark:bg-slate-950/75 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-white/10 hover:border-emerald-500/40'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Quiet Unboxed Exclusive Source Metadata */}
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            <span className="font-bold text-emerald-700 dark:text-emerald-400">
              المصدر الحصري: {sourceName}
            </span>
            <span aria-hidden="true">·</span>
            <span>{knowledge.chunks.length} مقطعاً</span>
            <span aria-hidden="true">·</span>
            <span>{knowledge.flashcards.length} بطاقة</span>
            <span aria-hidden="true">·</span>
            <span>مجاني 100% (Puter AI + بحث محلي)</span>
          </div>
        </div>

        {/* Active Tool Body */}
        {loadingKnowledge ? (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-16 flex flex-col items-center justify-center gap-3 text-slate-500">
            <Loader2 className="w-7 h-7 animate-spin text-emerald-500" />
            <p className="text-sm font-bold">جارٍ تحميل وفهرسة ملف المنهج المرفق...</p>
          </div>
        ) : loadError ? (
          <div className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-6 text-center space-y-3">
            <p className="text-sm font-bold text-rose-700 dark:text-rose-300">{loadError}</p>
            <button
              type="button"
              onClick={() => setManagerOpen(true)}
              className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold cursor-pointer"
            >
              رفع ملف منهج الآن
            </button>
          </div>
        ) : (
          <>
            {activeTab === 'chat' && (
              <AssistantChatPanel
                knowledge={knowledge}
                externalPrompt={externalPrompt}
                onNotify={onNotify}
              />
            )}
            {activeTab === 'why-wrong' && <WhyWrongTool knowledge={knowledge} />}
            {activeTab === 'equations' && (
              <EquationsExplorerTool knowledge={knowledge} onAskInChat={handleAskInChat} />
            )}
            {activeTab === 'flashcards' && <AssistantFlashcards3D knowledge={knowledge} />}
            {activeTab === 'planner' && (
              <RevisionPlannerTool knowledge={knowledge} onNotify={onNotify} />
            )}
            {activeTab === 'teacher-json' && (
              <TeacherJsonGeneratorTool knowledge={knowledge} onNotify={onNotify} />
            )}
          </>
        )}
      </main>

      {/* Quiet Standalone Footer */}
      <footer className="border-t border-slate-200 dark:border-white/10 py-4 px-4 text-center text-xs text-slate-500 dark:text-slate-400">
        المساعد الذكي للمنهج — يعمل مجاناً 100% بدون مفاتيح API · يعتمد حصرياً على ملف المنهج المرفق فقط
      </footer>

      <KnowledgeManagerModal
        open={managerOpen}
        sourceName={sourceName}
        isCustom={isCustom}
        rawText={rawKnowledge}
        knowledge={knowledge}
        onClose={() => setManagerOpen(false)}
        onReplaceKnowledge={handleReplaceKnowledge}
        onResetDefault={handleResetDefault}
      />
    </div>
  );
}
