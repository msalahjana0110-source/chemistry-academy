import React, { useState } from 'react';
import { Check, Code2, Copy, Download, Loader2, Sparkles } from 'lucide-react';
import {
  buildRagContextBlock,
  generateLocalMcqJson,
  searchCurriculumRag,
  type GeneratedTeacherMcq,
  type ParsedCurriculumKnowledge,
} from '../../utils/curriculumRag';
import { callFreePuterChat } from '../../utils/puterAiClient';

interface TeacherJsonGeneratorToolProps {
  knowledge: ParsedCurriculumKnowledge;
  onNotify: (msg: string, tone?: 'success' | 'info' | 'error') => void;
}

export function TeacherJsonGeneratorTool({
  knowledge,
  onNotify,
}: TeacherJsonGeneratorToolProps) {
  const [lessonCode, setLessonCode] = useState<string>('all');
  const [count, setCount] = useState<number>(5);
  const [difficulty, setDifficulty] = useState<'الكل' | 'أساسي' | 'متوسط' | 'متفوقين'>('الكل');
  const [useAi, setUseAi] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);
  const [items, setItems] = useState<GeneratedTeacherMcq[]>(() =>
    generateLocalMcqJson(knowledge, { lessonCode: 'all', count: 5, difficulty: 'الكل' })
  );
  const [statusLabel, setStatusLabel] = useState<string>(
    'تم الاستخراج المباشر بصيغة JSON مطابقة لملف المنهج المرفق'
  );
  const [copied, setCopied] = useState(false);

  const jsonOutput = JSON.stringify(items, null, 2);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const localBaseline = generateLocalMcqJson(knowledge, { lessonCode, count, difficulty });
      if (!useAi) {
        setItems(localBaseline);
        setStatusLabel('توليد فوري محلي مطابق 100% لأسلوب ملف المنهج المرفق');
        return;
      }

      const lessonObj = knowledge.lessons.find((l) => l.code === lessonCode);
      const rag = searchCurriculumRag(
        knowledge,
        lessonObj ? lessonObj.title : 'أسئلة اختيار من متعدد الشرح القوانين المعادلات',
        { lessonCode, topK: 8, preferKinds: ['explanation', 'mcq'] }
      );
      const context = buildRagContextBlock(rag.hits, 6400);

      const prompt = [
        `قم بتوليد ${count} أسئلة اختيار من متعدد بصيغة JSON Array صالحة فقط (بدون أي نص خارج JSON وبدون علامات markdown).`,
        `المستوى المطلوب: ${difficulty}.`,
        'المخطط المطلوب لكل عنصر:',
        '{"id":"Q_01","lesson":"اسم الدرس","difficulty":"متوسط","question":"نص السؤال","options":{"a":"...","b":"...","c":"...","d":"..."},"correctAnswer":"a","explanation":"التعليل العلمي من المنهج"}',
        'اعتمد حصرياً على المقاطع المرفقة من المنهج ولا تضف أي معلومة خارجية.',
      ].join('\n');

      const res = await callFreePuterChat({ userPrompt: prompt, ragContext: context });
      if (res.ok && res.text) {
        const cleaned = res.text
          .replace(/^```json\s*/i, '')
          .replace(/^```\s*/i, '')
          .replace(/\s*```$/i, '')
          .trim();
        const start = cleaned.indexOf('[');
        const end = cleaned.lastIndexOf(']');
        if (start !== -1 && end > start) {
          try {
            const parsed = JSON.parse(cleaned.slice(start, end + 1));
            if (Array.isArray(parsed) && parsed.length > 0 && parsed[0]?.question && parsed[0]?.options) {
              setItems(parsed as GeneratedTeacherMcq[]);
              setStatusLabel('تم التوليد عبر Puter AI المجاني · JSON مُتحقق من صحته');
              return;
            }
          } catch {
            // fall through to clean local JSON
          }
        }
      }

      setItems(localBaseline);
      setStatusLabel(
        res.usedFallbackReason
          ? `تم التوليد التلقائي من بنك المنهج المرفق (${res.usedFallbackReason})`
          : 'تم التوليد المباشر بصيغة JSON صالحة من ملف المنهج المرفق'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleCopyJson = async () => {
    try {
      await navigator.clipboard.writeText(jsonOutput);
      setCopied(true);
      onNotify('تم نسخ كود JSON بنجاح.');
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      onNotify('تعذّر النسخ التلقائي.', 'info');
    }
  };

  const handleDownloadJson = () => {
    const blob = new Blob([jsonOutput], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `curriculum_mcqs_${lessonCode}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      {/* Teacher Controls */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-5 space-y-4">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Code2 className="w-5 h-5 text-emerald-500" />
            <span>أداة المعلم — مولد أسئلة اختيار من متعدد بصيغة JSON</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            توليد أسئلة اختيار من متعدد مطابقة لأسلوب ملف المنهج المرفق ومحقّقة البنية جاهزة للتصدير والدمج المباشر.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="space-y-1">
            <label htmlFor="teacher-lesson-select" className="text-xs font-bold text-slate-700 dark:text-slate-300">
              الدرس المستهدف
            </label>
            <select
              id="teacher-lesson-select"
              value={lessonCode}
              onChange={(e) => setLessonCode(e.target.value)}
              className="w-full rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-xs font-bold text-slate-900 dark:text-slate-100 cursor-pointer"
            >
              <option value="all">كل المنهج المرفق</option>
              {knowledge.lessons.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.title}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="teacher-diff-select" className="text-xs font-bold text-slate-700 dark:text-slate-300">
              مستوى الصعوبة
            </label>
            <select
              id="teacher-diff-select"
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as typeof difficulty)}
              className="w-full rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-xs font-bold text-slate-900 dark:text-slate-100 cursor-pointer"
            >
              <option value="الكل">الكل (متنوع)</option>
              <option value="أساسي">أساسي</option>
              <option value="متوسط">متوسط</option>
              <option value="متفوقين">متفوقين ومستويات عليا</option>
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="teacher-count-input" className="text-xs font-bold text-slate-700 dark:text-slate-300">
              عدد الأسئلة ({count})
            </label>
            <input
              id="teacher-count-input"
              type="number"
              min={1}
              max={15}
              value={count}
              onChange={(e) => setCount(Math.max(1, Math.min(15, Number(e.target.value) || 5)))}
              className="w-full rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-xs font-mono font-bold tabular-nums text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="space-y-1">
            <span className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              طريقة التوليد
            </span>
            <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
              <button
                type="button"
                onClick={() => setUseAi(true)}
                className={`py-1.5 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                  useAi ? 'bg-emerald-600 text-white' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Puter AI + بديل
              </button>
              <button
                type="button"
                onClick={() => setUseAi(false)}
                className={`py-1.5 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                  !useAi ? 'bg-emerald-600 text-white' : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                فوري من الملف
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <button
            type="button"
            disabled={loading}
            onClick={() => void handleGenerate()}
            className="min-h-[42px] inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs sm:text-sm font-bold transition cursor-pointer"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>توليد أسئلة JSON الآن</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => void handleCopyJson()}
              className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-emerald-500/10 transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ' : 'نسخ JSON'}</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadJson}
              className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-emerald-500/10 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل .json</span>
            </button>
          </div>
        </div>
      </div>

      {/* Output JSON Viewer */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-b border-slate-200 dark:border-white/10 bg-slate-50/80 dark:bg-white/[0.02] text-xs">
          <span className="font-bold text-slate-800 dark:text-slate-200 tabular-nums">
            JSON صالح · {items.length} أسئلة
          </span>
          <span className="text-slate-500 dark:text-slate-400">{statusLabel}</span>
        </div>
        <pre
          dir="ltr"
          className="p-4 text-xs font-mono leading-6 text-slate-800 dark:text-emerald-200 bg-slate-50/60 dark:bg-[#040814] overflow-x-auto max-h-[520px] custom-scrollbar"
        >
          {jsonOutput}
        </pre>
      </div>
    </div>
  );
}
