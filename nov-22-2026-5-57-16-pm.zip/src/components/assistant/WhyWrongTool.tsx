import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  HelpCircle,
  Loader2,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import {
  NOT_FOUND_LITERAL,
  buildRagContextBlock,
  searchCurriculumRag,
  type ParsedCurriculumKnowledge,
  type ParsedMcqQuestion,
} from '../../utils/curriculumRag';
import { callFreePuterChat } from '../../utils/puterAiClient';
import { CurriculumMathText } from '../CurriculumMathText';

interface WhyWrongToolProps {
  knowledge: ParsedCurriculumKnowledge;
}

export function WhyWrongTool({ knowledge }: WhyWrongToolProps) {
  const [questionText, setQuestionText] = useState('');
  const [wrongAnswer, setWrongAnswer] = useState('');
  const [correctAnswer, setCorrectAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const [analysisText, setAnalysisText] = useState<string | null>(null);
  const [sourceNote, setSourceNote] = useState<string>('');
  const [similarQuestion, setSimilarQuestion] = useState<ParsedMcqQuestion | null>(null);
  const [pickedSimilarIdx, setPickedSimilarIdx] = useState<number | null>(null);

  const handleFillExample = () => {
    setQuestionText('لماذا يُعد غاز أول أكسيد الكربون (CO) قاتلاً صامتاً عند استنشاقه؟');
    setWrongAnswer('لأنه يتفاعل مع الأكسجين في الرئتين ويكوّن حمض الكبريتيك');
    setCorrectAnswer('لأنه عديم اللون والرائحة ويرتبط بالهيموجلوبين أقوى بـ 200–250 مرة من O₂ مكوناً HbCO');
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim() || !wrongAnswer.trim() || !correctAnswer.trim()) return;
    setLoading(true);
    setAnalysisText(null);
    setSimilarQuestion(null);
    setPickedSimilarIdx(null);

    try {
      const combinedQuery = `${questionText} ${correctAnswer} ${wrongAnswer}`;
      const rag = searchCurriculumRag(knowledge, combinedQuery, {
        topK: 6,
        preferKinds: ['explanation', 'mcq', 'essay'],
      });

      if (!rag.hasRelevantMatch) {
        setAnalysisText(`عذراً، (${NOT_FOUND_LITERAL}).`);
        setSourceNote('الالتزام الحصري بملف المنهج المرفق');
        return;
      }

      // Find a similar practice MCQ from the same lesson in the exclusive curriculum file
      const primaryLessonCode = rag.hits[0]?.chunk.lessonCode;
      const lessonMcqs = knowledge.mcqs.filter(
        (m) =>
          m.lessonCode === primaryLessonCode &&
          !m.question.includes(questionText.trim().slice(0, 20))
      );
      const fallbackMcq = lessonMcqs[0] ?? knowledge.mcqs[0] ?? null;

      const ragContext = buildRagContextBlock(rag.hits, 6200);
      const prompt = [
        `السؤال: ${questionText.trim()}`,
        `إجابتي الخاطئة: ${wrongAnswer.trim()}`,
        `الإجابة الصحيحة: ${correctAnswer.trim()}`,
        'المطلوب منك اعتماداً حصرياً على المقاطع المرفقة من المنهج:',
        '1) اشرح بوضوح سبب خطأ إجابتي ولماذا الإجابة الصحيحة هي الأدق وفق نص المنهج.',
        '2) أعطني قاعدة سريعة لتجنب هذا الخطأ مستقبلاً.',
        '3) اقترح سؤالاً مشابهاً للتدريب من نفس الدرس المرفق.',
      ].join('\n');

      const puterRes = await callFreePuterChat({
        userPrompt: prompt,
        ragContext,
      });

      if (puterRes.ok && puterRes.text) {
        setAnalysisText(puterRes.text);
        setSourceNote('تحليل عبر Puter AI المجاني · مستند حصرياً لملف المنهج');
      } else {
        const matchedLessonTitle = rag.hits[0]?.chunk.sourceTitle ?? 'المنهج المرفق';
        const excerpt = rag.hits
          .slice(0, 2)
          .map((h, i) => `### مرجع ${i + 1}: ${h.chunk.sourceTitle}\n${h.chunk.text}`)
          .join('\n\n---\n\n');

        const localReport = [
          `### تشخيص الخطأ من ملف المنهج المرفق (${matchedLessonTitle})`,
          `- **إجابتك المختارة:** ${wrongAnswer.trim()} — غير متطابقة مع النص العلمي الوارد في المنهج.`,
          `- **الإجابة الصحيحة المعتمدة:** ${correctAnswer.trim()}`,
          '',
          '### الشرح المرجعي المطابق من ملف المنهج:',
          excerpt,
        ].join('\n');

        setAnalysisText(localReport);
        setSourceNote(puterRes.usedFallbackReason || 'تحليل مباشر من ملف المنهج المرفق');
      }

      if (fallbackMcq) {
        setSimilarQuestion(fallbackMcq);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
      {/* Input Form */}
      <form
        onSubmit={handleAnalyze}
        className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-5 space-y-4"
      >
        <div className="flex items-start justify-between gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
              لماذا إجابتي خاطئة؟
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              اكتب السؤال وإجابتك الخاطئة والإجابة الصحيحة؛ وسيشرح لك المساعد سبب الخطأ من المنهج المرفق ويعطيك سؤالاً مشابهاً للتدريب.
            </p>
          </div>
          <button
            type="button"
            onClick={handleFillExample}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 text-[11px] font-bold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/10 transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            تجربة مثال
          </button>
        </div>

        <div className="space-y-1.5">
          <label
            htmlFor="why-wrong-question"
            className="block text-xs font-bold text-slate-700 dark:text-slate-300"
          >
            نص السؤال
          </label>
          <textarea
            id="why-wrong-question"
            required
            rows={3}
            value={questionText}
            onChange={(e) => setQuestionText(e.target.value)}
            placeholder="مثال: ما قيمة الضغط الكلي عند عمق 100 m تحت سطح البحر؟"
            className="w-full rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-slate-900 p-3 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="space-y-1.5">
          <label
            htmlFor="why-wrong-student"
            className="block text-xs font-bold text-rose-600 dark:text-rose-400"
          >
            إجابتك الخاطئة
          </label>
          <input
            id="why-wrong-student"
            required
            type="text"
            value={wrongAnswer}
            onChange={(e) => setWrongAnswer(e.target.value)}
            placeholder="اكتب الإجابة التي اخترتها وكانت خاطئة..."
            className="w-full rounded-xl border border-rose-500/35 bg-rose-500/5 p-3 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500"
          />
        </div>

        <div className="space-y-1.5">
          <label
            htmlFor="why-wrong-correct"
            className="block text-xs font-bold text-emerald-700 dark:text-emerald-400"
          >
            الإجابة الصحيحة
          </label>
          <input
            id="why-wrong-correct"
            required
            type="text"
            value={correctAnswer}
            onChange={(e) => setCorrectAnswer(e.target.value)}
            placeholder="اكتب الإجابة الصحيحة النموذجية..."
            className="w-full rounded-xl border border-emerald-500/35 bg-emerald-500/5 p-3 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2 pt-1">
          <button
            type="submit"
            disabled={loading}
            className="flex-1 min-h-[44px] inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-bold transition cursor-pointer"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>اشرح سبب الخطأ وهات سؤالاً مشابهاً</span>
          </button>
          {(questionText || wrongAnswer || correctAnswer) && (
            <button
              type="button"
              onClick={() => {
                setQuestionText('');
                setWrongAnswer('');
                setCorrectAnswer('');
                setAnalysisText(null);
                setSimilarQuestion(null);
              }}
              aria-label="مسح الحقول"
              className="min-h-[44px] min-w-[44px] rounded-xl border border-slate-200 dark:border-white/15 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      </form>

      {/* Output Analysis + Interactive Similar Practice Question */}
      <div className="lg:col-span-7 space-y-5">
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950/75 p-5 min-h-[260px]">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-12 gap-3 text-slate-500 dark:text-slate-400">
              <Loader2 className="w-7 h-7 animate-spin text-emerald-500" />
              <p className="text-sm font-bold">جارٍ تحليل الخطأ من ملف المنهج المرفق...</p>
            </div>
          ) : analysisText ? (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-200 dark:border-white/10">
                <span className="text-sm font-extrabold text-slate-900 dark:text-white">
                  تفسير الخطأ والتصويب المنهجي
                </span>
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  {sourceNote}
                </span>
              </div>
              <CurriculumMathText text={analysisText} />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center space-y-2.5">
              <HelpCircle className="w-9 h-9 text-slate-400" />
              <h3 className="text-sm font-extrabold text-slate-800 dark:text-slate-200">
                جاهز لتحليل إجابتك بدقة من المنهج
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md leading-6">
                أدخل تفاصيل السؤال الذي أخطأت فيه على اليمين (أو اضغط «تجربة مثال») ليظهر هنا شرح علمي مبسط وسؤال تدريبي مشابه.
              </p>
            </div>
          )}
        </div>

        {/* Interactive Similar Practice Question */}
        {similarQuestion && (
          <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/[0.04] dark:bg-emerald-500/[0.06] p-5 space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-extrabold text-emerald-800 dark:text-emerald-300">
                سؤال تدريبي مشابه من نفس الدرس للتثبيت
              </h3>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {similarQuestion.lessonLabel}
              </span>
            </div>

            <div className="text-sm font-bold text-slate-900 dark:text-white">
              <CurriculumMathText text={similarQuestion.question} />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {similarQuestion.options.map((opt, idx) => {
                const answered = pickedSimilarIdx !== null;
                const isPicked = pickedSimilarIdx === idx;
                const isRight = idx === similarQuestion.correctIndex;

                let cls =
                  'border-slate-200 dark:border-white/15 bg-white dark:bg-slate-900/80 text-slate-800 dark:text-slate-200 hover:border-emerald-500/60';
                if (answered && isRight) {
                  cls =
                    'border-emerald-500 bg-emerald-500/15 text-emerald-900 dark:text-emerald-200 font-bold';
                } else if (answered && isPicked && !isRight) {
                  cls = 'border-rose-500 bg-rose-500/15 text-rose-900 dark:text-rose-200 font-bold';
                }

                return (
                  <button
                    key={opt.key}
                    type="button"
                    disabled={answered}
                    onClick={() => setPickedSimilarIdx(idx)}
                    className={`p-3 rounded-xl border text-right text-xs sm:text-sm transition flex items-center justify-between gap-2 cursor-pointer disabled:cursor-default ${cls}`}
                  >
                    <span>
                      {opt.key}) {opt.text}
                    </span>
                    {answered && isRight && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
                    {answered && isPicked && !isRight && <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {pickedSimilarIdx !== null && (
              <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900/90 p-3 text-xs leading-6 text-slate-700 dark:text-slate-200">
                <strong className="text-emerald-700 dark:text-emerald-400">التعليل المنهجي: </strong>
                <CurriculumMathText text={similarQuestion.explanation} />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
