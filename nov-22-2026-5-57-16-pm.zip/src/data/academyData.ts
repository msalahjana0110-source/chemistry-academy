import lessonsJson from './curriculum/lessons.json';
import revisionPointsJson from './curriculum/revisionPoints.json';
import mcqBankJson from './curriculum/mcqBank.json';
import essayBankJson from './curriculum/essayBank.json';
import syllabus14Json from './curriculum/syllabus14.json';
import openBook14Json from './curriculum/openBook14.json';
import flashcards70Json from './curriculum/flashcards70.json';

export type UnitId = 'unit1' | 'unit2' | 'unit3';

export interface LessonTable {
  headers: string[];
  rows: string[][];
}

export interface LessonBlock {
  type: 'paragraph' | 'formula' | 'example' | 'table' | 'analogy' | 'bullet';
  title?: string;
  content?: string;
  items?: string[];
  table?: LessonTable;
}

export interface LessonSection {
  title: string;
  body: string;
  equation?: string;
  blocks?: LessonBlock[];
}

export interface LessonQuickCheck {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface LessonPracticeMcq {
  id: string;
  kind: 'mcq';
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface LessonPracticeEssay {
  id: string;
  kind: 'essay';
  question: string;
  modelAnswer: string;
}

export type LessonPracticeCheck = LessonPracticeMcq | LessonPracticeEssay;

export interface LessonItem {
  id: string;
  lessonNumber: number;
  unitId: UnitId;
  unitName: string;
  numberLabel: string;
  title: string;
  summary: string;
  coreIdea: string;
  curriculumImportance: string;
  durationMin: number;
  level: 'أساسي' | 'متوسط' | 'متقدم';
  coverImage: string;
  objectives: string[];
  sections: LessonSection[];
  examTip: string;
  examTraps: string[];
  focusPoints: string[];
  quickCheck: LessonQuickCheck;
  practiceChecks: LessonPracticeCheck[];
}

export interface RevisionPointItem {
  id: string;
  index: number;
  text: string;
  subPoints: string[];
}

export interface RevisionLessonBlock {
  lessonId: string;
  lessonNumber: number;
  unitId: UnitId;
  unitName: string;
  numberLabel: string;
  lessonTitle: string;
  points: RevisionPointItem[];
}

export type OpenBookCategory =
  | 'الباب الأول: الحساب الكيميائي'
  | 'الباب الثاني: بنية الذرة'
  | 'الباب الثالث: الجدول الدوري وتصنيف العناصر';

export interface OpenBookEntry {
  id: string;
  number?: number;
  kind?: string;
  unitId?: UnitId;
  category: OpenBookCategory;
  lessonId: string;
  title: string;
  formula: string;
  variables: string;
  lines?: string[];
  note: string;
}

export interface ScientificConstantItem {
  id: string;
  label: string;
  value: string;
  detail: string;
}

export interface AtomicMassItem {
  symbol: string;
  mass: string;
}

export interface CurriculumEquationItem {
  id: string;
  number: number;
  equation: string;
  tag: string;
  unitId: UnitId;
}

export interface Syllabus14Section {
  title: string;
  items: string[];
}

export interface Syllabus14Lesson {
  id: string;
  number: number;
  numberLabel: string;
  unitId: UnitId;
  unitName: string;
  title: string;
  mappedLessonId: string;
  subTopicId: string;
  sections: Syllabus14Section[];
}

export interface FlashcardItem {
  id: string;
  index: number;
  unitId: UnitId;
  unitName: string;
  lessonNum: number;
  subTopicId: string;
  lessonLabel: string;
  unit: string;
  front: string;
  formulaHint?: string;
  back: string;
  equation?: string;
}

export type QuizDifficulty = 'سهل' | 'متوسط' | 'متقدم';
export type QuizSkillType = 'فهم ومفاهيم' | 'حسابات كيميائية' | 'معادلات وتفاعلات';
export type QuestionSourceTag = 'بنك الدرس' | 'استنتاجي فائق' | 'متفوقين ومستويات عليا';

export interface QuizQuestion {
  id: string;
  unitId: UnitId;
  unit: string;
  lessonId: string;
  lessonTitle: string;
  subTopicId: string;
  subTopicTitle: string;
  difficulty: QuizDifficulty;
  skillType: QuizSkillType;
  sourceTag: QuestionSourceTag;
  sectionIndex: number;
  question: string;
  formula?: string;
  hint: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface EssayQuestion {
  id: string;
  unitId: UnitId;
  unit: string;
  lessonId: string;
  lessonTitle: string;
  subTopicId: string;
  subTopicTitle: string;
  difficulty: QuizDifficulty;
  sourceTag: QuestionSourceTag;
  sectionIndex: number;
  question: string;
  modelAnswer: string;
}

export interface EquationChallenge {
  id: string;
  title: string;
  category: string;
  species: Array<{ formula: string; side: 'reactant' | 'product' }>;
  solution: number[];
  note: string;
}

export interface CreatorProfile {
  id: 'author' | 'designer';
  roleBadge: string;
  name: string;
  title: string;
  bio: string;
  highlights: string[];
  phone: string;
  telHref: string;
  emblemFormula: string;
}

export const PLATFORM_LOGO_URL =
  '/assets/aistudio/WhatsApp_Image_2026-11-22_at_7.54.32_AM_66431769.jpeg';
export const HERO_LAB_IMAGE = '/src/assets/images/hero_chemistry_lab_studio_1795317628325.jpg';
export const UNIT1_IMAGE = '/src/assets/images/lesson_atomic_orbitals_1795317629331.jpg';
export const UNIT2_IMAGE = '/src/assets/images/lesson_electrochemistry_cell_1795317627843.jpg';
export const UNIT3_IMAGE = '/src/assets/images/lesson_organic_benzene_1795317627662.jpg';

const PARSED_LESSONS = lessonsJson as unknown as LessonItem[];
const PARSED_REVISION = revisionPointsJson as unknown as RevisionLessonBlock[];
const PARSED_MCQS = mcqBankJson as unknown as QuizQuestion[];
const PARSED_ESSAYS = essayBankJson as unknown as EssayQuestion[];
const PARSED_SYLLABUS14 = syllabus14Json as unknown as Syllabus14Lesson[];
const PARSED_OPENBOOK14 = openBook14Json as unknown as {
  constants: ScientificConstantItem[];
  atomicMasses: AtomicMassItem[];
  cards: OpenBookEntry[];
  equations: CurriculumEquationItem[];
};
const PARSED_FLASHCARDS70 = flashcards70Json as unknown as FlashcardItem[];

export const CURRICULUM_UNIT_META: ReadonlyArray<{
  id: UnitId;
  shortLabel: string;
  fullName: string;
  kicker: string;
  title: string;
  summary: string;
  firstLessonId: string;
  image: string;
  alt: string;
}> = [
  {
    id: 'unit1',
    shortLabel: 'الحساب الكيميائي',
    fullName: 'الباب الأول: الحساب الكيميائي',
    kicker: 'الباب الأول · الدروس 01 – 04',
    title: 'الحساب الكيميائي والمول والمحاليل',
    summary:
      'المول وعدد أفوجادرو، الحجم المولي للغازات (STP و rtp)، العامل المحدد للتفاعل، الصيغ الأولية والجزيئية، وتركيز المحاليل وتخفيفها.',
    firstLessonId: 'lesson-1',
    image: UNIT1_IMAGE,
    alt: 'تمثيل علمي للحساب الكيميائي والمول والجزيئات',
  },
  {
    id: 'unit2',
    shortLabel: 'بنية الذرة',
    fullName: 'الباب الثاني: بنية الذرة',
    kicker: 'الباب الثاني · الدروس 05 – 08',
    title: 'بنية الذرة وأعداد الكم والتوزيع الإلكتروني',
    summary:
      'نماذج طومسون ورذرفورد وبور، طيف الهيدروجين الخطي، النظرية الموجية وأعداد الكم الأربعة، ومبادئ باولي وأوفباو وهوند.',
    firstLessonId: 'lesson-5',
    image: UNIT2_IMAGE,
    alt: 'نموذج علمي لطيف الذرة وأوربيتالات الإلكترونات',
  },
  {
    id: 'unit3',
    shortLabel: 'الجدول الدوري',
    fullName: 'الباب الثالث: الجدول الدوري وتصنيف العناصر',
    kicker: 'الباب الثالث · الدروس 09 – 12',
    title: 'الجدول الدوري وتدرج الخواص والأكسدة والاختزال',
    summary:
      'فئات s و p و d و f، تدرج نصف القطر وجهد التأين والميل والسالبية، الأكاسيد القاعدية والحامضية والمترددة، وأعداد التأكسد وموازنة التفاعلات.',
    firstLessonId: 'lesson-9',
    image: UNIT3_IMAGE,
    alt: 'تصنيف عناصر الجدول الدوري والروابط وتدرج الخواص',
  },
];

export const ACADEMY_DATA = {
  brand: {
    name: 'أكاديمية الكيمياء',
    logoUrl: PLATFORM_LOGO_URL,
    credits: 'إعداد مستر صلاح عيد • تصميم محمد صلاح',
    authorName: 'مستر صلاح عيد',
    authorRole: 'إعداد المادة العلمية',
    authorPhone: '01007235605',
    designerName: 'محمد صلاح',
    designerRole: 'تصميم وتطوير المنصة',
    designerPhone: '01113223341',
    splashBadge: 'الكيمياء · الصف الثاني الثانوي · الفصل الدراسي الأول 2026 / 2027',
    splashEnterLabel: 'دخول المنصة',
    footerText: 'أكاديمية الكيمياء (الصف الثاني الثانوي — الترم الأول) — إعداد مستر صلاح عيد • تصميم محمد صلاح',
    creators: [
      {
        id: 'author',
        roleBadge: 'إعداد المادة العلمية والبنك المنهجي',
        name: 'مستر صلاح عيد',
        title: 'خبير ومُعدّ منهج الكيمياء للمرحلة الثانوية',
        bio: 'إعداد علمي دقيق لمنهج الكيمياء للصف الثاني الثانوي (الفصل الدراسي الأول 2026 / 2027) يشمل الشرح المنهجي لـ 12 درساً، فخاخ الامتحانات، أهم نقاط المراجعة النهائية، وبنك أسئلة ومسائل يتجاوز 1,560 سؤالاً.',
        highlights: [
          '12 درساً مشروحاً بالكامل مع الأمثلة المحلولة وجداول المقارنة',
          'بنك 1,400 سؤال منهجي (اختيار من متعدد ومقالي ومسائل)',
          '160 سؤالاً استنتاجياً للمتفوقين ومستويات التفكير العليا',
        ],
        phone: '01007235605',
        telHref: 'tel:01007235605',
        emblemFormula: 'n = m / M · 6.02×10²³',
      },
      {
        id: 'designer',
        roleBadge: 'تصميم وتطوير المنصة التفاعلية',
        name: 'محمد صلاح',
        title: 'مصمم ومطور واجهات المنصات التعليمية التفاعلية',
        bio: 'تصميم وهندسة تجربة تعليمية متكاملة تجمع بين القارئ المنهجي التفاعلي، المختبر الافتراضي، الكتاب المفتوح، الاختبار التكيّفي الذكي، سجل الأخطاء المرتبط بالشرح، وإصدار الشهادات المعتمدة.',
        highlights: [
          'واجهة احترافية بست لوحات ألوان ووضع ليلي/نهاري كامل',
          'ربط ذكي لكل سؤال خاطئ بفقرة شرحه داخل الدرس مباشرة',
          'مختبر افتراضي وحاسبة كتلة مولية وموازن معادلات تفاعلي',
        ],
        phone: '01113223341',
        telHref: 'tel:01113223341',
        emblemFormula: 'M.S.AI · 3D Lab Engine',
      },
    ] as CreatorProfile[],
  },
  home: {
    badge: 'الصف الثاني الثانوي · الفصل الدراسي الأول 2026 / 2027',
    title: 'أكاديمية الكيمياء التفاعلية',
    description:
      'منهج الكيمياء الكامل للصف الثاني الثانوي (الترم الأول): 12 درساً مشروحاً بالخطوات والأمثلة وفخاخ الامتحانات، أهم نقاط المراجعة النهائية، وبنك شامل يضم 1,560 سؤالاً ومسألة محلولة مع المختبر التفاعلي والاختبار التكيّفي.',
    primaryCta: 'ابدأ الدروس (12 درساً)',
    secondaryCta: 'افتح المختبر التفاعلي',
    lessonsCountLabel: 'الدروس والشروحات',
    questionsCountLabel: 'بنك الأسئلة والمسائل',
    creditsCardTitle: 'الإعداد والتصميم',
    marqueeItems: [
      '✦ الكيمياء — الصف الثاني الثانوي — الترم الأول 2026 / 2027',
      '✦ إعداد مستر صلاح عيد (01007235605)',
      '✦ تصميم محمد صلاح (01113223341)',
      '✦ 12 درساً منهجياً كاملاً بالأمثلة المحلولة وفخاخ الامتحانات',
      '✦ 1,560 سؤالاً ومسألة محلولة + 160 سؤال متفوقين ومستويات عليا',
      '✦ أهم النقاط الجوهرية للمراجعة النهائية لكل درس',
      '✦ اختبار تكيّفي ذكي وسجل أخطاء مرتبط بشرح كل درس',
    ],
  },
  lessons: {
    heading: 'الدروس والشروحات المنهجية (12 درساً)',
    subheading:
      'شرح منهجي كامل للأبواب الثلاثة مع الأمثلة المحلولة بالخطوات، جداول المقارنة، فخاخ الامتحانات، أهم نقاط التركيز، وتدريبات التحقق من الفهم',
    items: PARSED_LESSONS,
  },
  syllabus14: {
    heading: 'أطلس شروحات المنهج الكامل (14 درساً)',
    subheading:
      'التقسيم المنهجي التفصيلي لملف المنهج الموحد (الدروس 01–05 الحساب الكيميائي، 06–09 بنية الذرة، 10–14 الجدول الدوري) مع أطلس المعادلات الـ 18 والربط المباشر ببنك الأسئلة وبطاقات الاستوديو',
    lessons: PARSED_SYLLABUS14,
  },
  lab: {
    heading: 'المختبر الافتراضي التفاعلي (الصف الثاني الثانوي)',
    subheading:
      '6 مختبرات تفاعلية مخصصة 100% للترم الأول: الحساب الكيميائي والتخفيف، تجربة رذرفورد، طيف الهيدروجين (بور)، التوزيع والأوربيتالات وأعداد الكم، الجدول الدوري وتدرج الخواص، والأكاسيد والأكسدة والاختزال',
    equations: [
      {
        id: 'eq-water-elec',
        title: 'التحليل الكهربي للماء المحمض (الدرس 02)',
        category: 'الحساب الكيميائي',
        species: [
          { formula: 'H2O', side: 'reactant' },
          { formula: 'H2', side: 'product' },
          { formula: 'O2', side: 'product' },
        ],
        solution: [2, 2, 1],
        note: 'كل 2 mol من الماء ينحل كهربياً إلى 2 mol من الهيدروجين و 1 mol من الأكسجين.',
      },
      {
        id: 'eq-kno3-decomp',
        title: 'الانحلال الحراري لنترات البوتاسيوم (الدرس 02)',
        category: 'الحساب الكيميائي',
        species: [
          { formula: 'KNO3', side: 'reactant' },
          { formula: 'KNO2', side: 'product' },
          { formula: 'O2', side: 'product' },
        ],
        solution: [2, 2, 1],
        note: 'تفاعل منهجي أساسي لحساب حجم الأكسجين الناتج في STP أو rtp من كتلة KNO₃.',
      },
      {
        id: 'eq-sodium-water',
        title: 'تفاعل الصوديوم مع الماء (الدرس 02 و 11)',
        category: 'الخاصية الفلزية والحساب الكيميائي',
        species: [
          { formula: 'Na', side: 'reactant' },
          { formula: 'H2O', side: 'reactant' },
          { formula: 'NaOH', side: 'product' },
          { formula: 'H2', side: 'product' },
        ],
        solution: [2, 2, 2, 1],
        note: 'تفاعل طارد للحرارة بشدة يتصاعد فيه غاز الهيدروجين ويتكون محلول هيدروكسيد الصوديوم القاعدي.',
      },
      {
        id: 'eq-nh3-ox',
        title: 'أكسدة النشادر بالأكسجين (العامل المحدد)',
        category: 'الحساب الكيميائي',
        species: [
          { formula: 'NH3', side: 'reactant' },
          { formula: 'O2', side: 'reactant' },
          { formula: 'NO', side: 'product' },
          { formula: 'H2O', side: 'product' },
        ],
        solution: [4, 5, 4, 6],
        note: 'معادلة شهيرة في مسائل العامل المحدد: قسّم مولات NH₃ على 4 ومولات O₂ على 5 لتحديد المحدد.',
      },
      {
        id: 'eq-al2o3-hcl',
        title: 'تفاعل أكسيد الألومنيوم المتردد مع حمض HCl (الدرس 11)',
        category: 'الأكاسيد المترددة',
        species: [
          { formula: 'Al2O3', side: 'reactant' },
          { formula: 'HCl', side: 'reactant' },
          { formula: 'AlCl3', side: 'product' },
          { formula: 'H2O', side: 'product' },
        ],
        solution: [1, 6, 2, 3],
        note: 'يتفاعل الأكسيد المتردد Al₂O₃ مع الأحماض كأكسيد قاعدي مكوناً ملحاً وماءً، ومع القواعد كأكسيد حامضي.',
      },
      {
        id: 'eq-mno2-hcl',
        title: 'تفاعل أكسدة واختزال ثاني أكسيد المنجنيز مع HCl (الدرس 12)',
        category: 'الأكسدة والاختزال',
        species: [
          { formula: 'MnO2', side: 'reactant' },
          { formula: 'HCl', side: 'reactant' },
          { formula: 'MnCl2', side: 'product' },
          { formula: 'Cl2', side: 'product' },
          { formula: 'H2O', side: 'product' },
        ],
        solution: [1, 4, 1, 1, 2],
        note: 'يُختزل المنجنيز من +4 إلى +2 (عامل مؤكسد) ويتأكسد الكلور من -1 إلى 0 في Cl₂ (عامل مختزل).',
      },
    ] as EquationChallenge[],
  },
  openBook: {
    heading: 'الكتاب المفتوح وأوراق المفاهيم والمراجعة النهائية',
    subheading:
      '14 ورقة قوانين ومفاهيم + 18 معادلة موزونة + الثوابت والكتل الذرية الـ 21 + 93 نقطة جوهرية للمراجعة النهائية جاهزة للبحث والنسخ والتثبيت',
    entries: PARSED_OPENBOOK14.cards,
    constants: PARSED_OPENBOOK14.constants,
    atomicMasses: PARSED_OPENBOOK14.atomicMasses,
    equations: PARSED_OPENBOOK14.equations,
    revisionLessons: PARSED_REVISION,
  },
  studio: {
    heading: 'الاستوديو التعليمي — 70 بطاقة مراجعة تفاعلية',
    subheading:
      '70 بطاقة تعليمية ثلاثية الأبعاد تغطي جميع الدروس الـ 14 (5 بطاقات مركّزة لكل درس) مع التصفية حسب الباب والدرس ومؤقت بومودورو',
    flashcards: PARSED_FLASHCARDS70,
  },
  quiz: {
    heading: 'مركز الاختبارات وبنك الأسئلة الشامل (1,560 سؤالاً)',
    subheading:
      'بنك 798 سؤال اختيار من متعدد + 762 سؤالاً مقالياً ومسألة محلولة (بما فيها 160 سؤال متفوقين ومستويات عليا) + الاختبار التكيّفي الذكي ومصمم ورقة الامتحان',
    bankTitle: 'بنك الأسئلة والمسائل الشامل',
    adaptiveTitle: 'الاختبار التكيّفي الذكي',
    printButtonLabel: 'طباعة ورقة الامتحان',
    paperTitle: 'أكاديمية الكيمياء — الصف الثاني الثانوي (الترم الأول)',
    paperSubtitle: 'إعداد مستر صلاح عيد (01007235605) • تصميم محمد صلاح (01113223341)',
    questions: PARSED_MCQS,
    essayQuestions: PARSED_ESSAYS,
  },
};
