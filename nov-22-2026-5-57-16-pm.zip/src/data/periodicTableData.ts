export type ElementCategory =
  | 'alkali'
  | 'alkaline'
  | 'transition'
  | 'nonmetal'
  | 'halogen'
  | 'noble'
  | 'metalloid'
  | 'post-transition';

export type ElementBlock = 's' | 'p' | 'd' | 'f';

export interface PeriodicElement {
  number: number;
  symbol: string;
  nameAr: string;
  nameEn: string;
  mass: number;
  group: number;
  period: number;
  block: ElementBlock;
  category: ElementCategory;
  shells: number[];
  config: string;
  atomicRadiusPm: number;
  firstIonizationKj: number;
  electronAffinityKj: number | null;
  electronegativity: number | null;
  stateAr: string;
  highlightAr: string;
  anomalyNoteAr?: string;
}

export const ELEMENT_CATEGORY_META: Record<
  ElementCategory,
  { labelAr: string; colorClass: string; swatch: string }
> = {
  alkali: {
    labelAr: 'فلزات قلوية',
    colorClass: 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300',
    swatch: '#f43f5e',
  },
  alkaline: {
    labelAr: 'قلوية أرضية',
    colorClass: 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300',
    swatch: '#f59e0b',
  },
  transition: {
    labelAr: 'عناصر انتقالية',
    colorClass: 'border-cyan-500/40 bg-cyan-500/10 text-cyan-700 dark:text-cyan-300',
    swatch: '#06b6d4',
  },
  'post-transition': {
    labelAr: 'فلزات ضعيفة',
    colorClass: 'border-blue-500/40 bg-blue-500/10 text-blue-700 dark:text-blue-300',
    swatch: '#3b82f6',
  },
  metalloid: {
    labelAr: 'أشباه فلزات',
    colorClass: 'border-teal-500/40 bg-teal-500/10 text-teal-700 dark:text-teal-300',
    swatch: '#14b8a6',
  },
  nonmetal: {
    labelAr: 'لافلزات',
    colorClass: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
    swatch: '#10b981',
  },
  halogen: {
    labelAr: 'هالوجينات',
    colorClass: 'border-violet-500/40 bg-violet-500/10 text-violet-700 dark:text-violet-300',
    swatch: '#8b5cf6',
  },
  noble: {
    labelAr: 'غازات نبيلة',
    colorClass: 'border-indigo-500/40 bg-indigo-500/10 text-indigo-700 dark:text-indigo-300',
    swatch: '#6366f1',
  },
};

export const PERIODIC_ELEMENTS: PeriodicElement[] = [
  { number: 1, symbol: 'H', nameAr: 'هيدروجين', nameEn: 'Hydrogen', mass: 1.008, group: 1, period: 1, block: 's', category: 'nonmetal', shells: [1], config: '1s¹', atomicRadiusPm: 37, firstIonizationKj: 1312, electronAffinityKj: -73, electronegativity: 2.2, stateAr: 'غاز', highlightAr: 'أبسط ذرة في الكون؛ فسّر نموذج بور طيف انبعاثه الخطي المرئي (4 ألوان عند العودة إلى n=2).' },
  { number: 2, symbol: 'He', nameAr: 'هيليوم', nameEn: 'Helium', mass: 4.003, group: 18, period: 1, block: 's', category: 'noble', shells: [2], config: '1s²', atomicRadiusPm: 31, firstIonizationKj: 2372, electronAffinityKj: 0, electronegativity: null, stateAr: 'غاز', highlightAr: 'أعلى جهد تأين أول في الجدول الدوري (2372 kJ/mol)؛ غاز نبيل ينتمي للفئة s وليس p.', anomalyNoteAr: 'أعلى جهد تأين أول (2372 kJ/mol) وميله الإلكتروني يقارب الصفر لامتلاء 1s².' },
  { number: 3, symbol: 'Li', nameAr: 'ليثيوم', nameEn: 'Lithium', mass: 6.94, group: 1, period: 2, block: 's', category: 'alkali', shells: [2, 1], config: '[He] 2s¹', atomicRadiusPm: 152, firstIonizationKj: 520, electronAffinityKj: -60, electronegativity: 0.98, stateAr: 'صلب', highlightAr: 'أكبر عناصر الدورة الثانية في نصف القطر الذري وأقلها في جهد التأين الأول.' },
  { number: 4, symbol: 'Be', nameAr: 'بيريليوم', nameEn: 'Beryllium', mass: 9.012, group: 2, period: 2, block: 's', category: 'alkaline', shells: [2, 2], config: '[He] 2s²', atomicRadiusPm: 112, firstIonizationKj: 899, electronAffinityKj: 19, electronegativity: 1.57, stateAr: 'صلب', highlightAr: 'ينتهي بـ 2s² تام الامتلاء لذلك يشذ في جهد التأين الأول والميل الإلكتروني.', anomalyNoteAr: 'شذوذ: جهد تأين Be (899) أكبر من B (801)، وميله الإلكتروني موجب (+19 kJ/mol) لامتلاء 2s².' },
  { number: 5, symbol: 'B', nameAr: 'بورون', nameEn: 'Boron', mass: 10.81, group: 13, period: 2, block: 'p', category: 'metalloid', shells: [2, 3], config: '[He] 2s² 2p¹', atomicRadiusPm: 85, firstIonizationKj: 801, electronAffinityKj: -27, electronegativity: 2.04, stateAr: 'صلب', highlightAr: 'شبه فلز يبدأ به عناصر الفئة p؛ جهد تأينه الأول أقل من البريليوم Be.' },
  { number: 6, symbol: 'C', nameAr: 'كربون', nameEn: 'Carbon', mass: 12.011, group: 14, period: 2, block: 'p', category: 'nonmetal', shells: [2, 4], config: '[He] 2s² 2p²', atomicRadiusPm: 77, firstIonizationKj: 1086, electronAffinityKj: -122, electronegativity: 2.55, stateAr: 'صلب', highlightAr: 'مثال أساسي في قاعدة هوند (إلكترونان مفردان في 2p) وأكسيده CO₂ حامضي و CO متعادل.' },
  { number: 7, symbol: 'N', nameAr: 'نيتروجين', nameEn: 'Nitrogen', mass: 14.007, group: 15, period: 2, block: 'p', category: 'nonmetal', shells: [2, 5], config: '[He] 2s² 2p³', atomicRadiusPm: 70, firstIonizationKj: 1402, electronAffinityKj: 7, electronegativity: 3.04, stateAr: 'غاز', highlightAr: 'يمتلك 3 إلكترونات مفردة في 2p³ (نصف ممتلئ ومستقر) فيشذ في جهد التأين والميل.', anomalyNoteAr: 'شذوذ: جهد تأين N (1402) أكبر من O (1314)، وميله موجب (+7 kJ/mol) لاستقرار 2p³ نصف الممتلئ.' },
  { number: 8, symbol: 'O', nameAr: 'أكسجين', nameEn: 'Oxygen', mass: 15.999, group: 16, period: 2, block: 'p', category: 'nonmetal', shells: [2, 6], config: '[He] 2s² 2p⁴', atomicRadiusPm: 66, firstIonizationKj: 1314, electronAffinityKj: -141, electronegativity: 3.44, stateAr: 'غاز', highlightAr: 'عدد تأكسده -2 غالباً، ويشذ في فوق الأكسيد (-1) وسوبر الأكسيد (-½) و OF₂ (+2).' },
  { number: 9, symbol: 'F', nameAr: 'فلور', nameEn: 'Fluorine', mass: 18.998, group: 17, period: 2, block: 'p', category: 'halogen', shells: [2, 7], config: '[He] 2s² 2p⁵', atomicRadiusPm: 64, firstIonizationKj: 1681, electronAffinityKj: -328, electronegativity: 3.98, stateAr: 'غاز', highlightAr: 'أقوى اللافلزات وأعلى سالبية كهربية (4.0) وعدد تأكسده (-1) دائماً في جميع مركباته.', anomalyNoteAr: 'شذوذ الميل الإلكتروني: Cl (-349) أكبر من F (-328) لصغر حجم ذرة الفلور (64 pm) وشدة التنافر.' },
  { number: 10, symbol: 'Ne', nameAr: 'نيون', nameEn: 'Neon', mass: 20.18, group: 18, period: 2, block: 'p', category: 'noble', shells: [2, 8], config: '[He] 2s² 2p⁶', atomicRadiusPm: 38, firstIonizationKj: 2081, electronAffinityKj: 0, electronegativity: null, stateAr: 'غاز', highlightAr: 'غاز نبيل خامل في نهاية الدورة الثانية بامتلاء تام لمستوى الطاقة الخارجي (2p⁶).' },
  { number: 11, symbol: 'Na', nameAr: 'صوديوم', nameEn: 'Sodium', mass: 22.99, group: 1, period: 3, block: 's', category: 'alkali', shells: [2, 8, 1], config: '[Ne] 3s¹', atomicRadiusPm: 186, firstIonizationKj: 496, electronAffinityKj: -53, electronegativity: 0.93, stateAr: 'صلب', highlightAr: 'نصف قطر ذرته (186 pm) أكبر بكثير من أيونه Na⁺ (102 pm)، وأكسيده Na₂O قاعدي قلوي.' },
  { number: 12, symbol: 'Mg', nameAr: 'ماغنيسيوم', nameEn: 'Magnesium', mass: 24.305, group: 2, period: 3, block: 's', category: 'alkaline', shells: [2, 8, 2], config: '[Ne] 3s²', atomicRadiusPm: 160, firstIonizationKj: 738, electronAffinityKj: 21, electronegativity: 1.31, stateAr: 'صلب', highlightAr: 'جهد تأينه الثالث (+7730 kJ/mol) يقفز بشدة لكسر مستوى طاقة مكتمل شبيه بالنيون.', anomalyNoteAr: 'شذوذ: جهد تأين Mg (738) أكبر من Al (578) وميله موجب (+21 kJ/mol) لامتلاء 3s².' },
  { number: 13, symbol: 'Al', nameAr: 'ألومنيوم', nameEn: 'Aluminum', mass: 26.982, group: 13, period: 3, block: 'p', category: 'post-transition', shells: [2, 8, 3], config: '[Ne] 3s² 3p¹', atomicRadiusPm: 143, firstIonizationKj: 578, electronAffinityKj: -43, electronegativity: 1.61, stateAr: 'صلب', highlightAr: 'أكسيده Al₂O₃ أشهر أكسيد متردد يتفاعل مع HCl و NaOH (معطياً NaAlO₂).' },
  { number: 14, symbol: 'Si', nameAr: 'سيليكون', nameEn: 'Silicon', mass: 28.085, group: 14, period: 3, block: 'p', category: 'metalloid', shells: [2, 8, 4], config: '[Ne] 3s² 3p²', atomicRadiusPm: 117, firstIonizationKj: 787, electronAffinityKj: -134, electronegativity: 1.9, stateAr: 'صلب', highlightAr: 'شبه فلز متوسط السالبية والتوصيل الكهربي يُستخدم في الترانزستورات والرقائق.' },
  { number: 15, symbol: 'P', nameAr: 'فوسفور', nameEn: 'Phosphorus', mass: 30.974, group: 15, period: 3, block: 'p', category: 'nonmetal', shells: [2, 8, 5], config: '[Ne] 3s² 3p³', atomicRadiusPm: 110, firstIonizationKj: 1012, electronAffinityKj: -72, electronegativity: 2.19, stateAr: 'صلب', highlightAr: 'جهد تأينه الأول أكبر من الكبريت S لأن 3p³ نصف ممتلئ؛ وجزيئه البخاري P₄ عدد تأكسده 0.' },
  { number: 16, symbol: 'S', nameAr: 'كبريت', nameEn: 'Sulfur', mass: 32.06, group: 16, period: 3, block: 'p', category: 'nonmetal', shells: [2, 8, 6], config: '[Ne] 3s² 3p⁴', atomicRadiusPm: 104, firstIonizationKj: 1000, electronAffinityKj: -200, electronegativity: 2.58, stateAr: 'صلب', highlightAr: 'أكسيده SO₃ حامضي يعطي H₂SO₄، ويدخل في تفاعل التناسب المشترك (2H₂S + SO₂ → 3S + 2H₂O).' },
  { number: 17, symbol: 'Cl', nameAr: 'كلور', nameEn: 'Chlorine', mass: 35.45, group: 17, period: 3, block: 'p', category: 'halogen', shells: [2, 8, 7], config: '[Ne] 3s² 3p⁵', atomicRadiusPm: 99, firstIonizationKj: 1251, electronAffinityKj: -349, electronegativity: 3.16, stateAr: 'غاز', highlightAr: 'أعلى عنصر في الجدول الدوري في طاقة الميل الإلكتروني (-349 kJ/mol) وأيونه Cl⁻=181 pm أكبر من ذرته.', anomalyNoteAr: 'أعلى ميل إلكتروني (-349 kJ/mol) أكبر من الفلور F (-328) لاتساع حجم الكلور النسبي.' },
  { number: 18, symbol: 'Ar', nameAr: 'أرجون', nameEn: 'Argon', mass: 39.948, group: 18, period: 3, block: 'p', category: 'noble', shells: [2, 8, 8], config: '[Ne] 3s² 3p⁶', atomicRadiusPm: 71, firstIonizationKj: 1521, electronAffinityKj: 0, electronegativity: null, stateAr: 'غاز', highlightAr: 'الغاز النبيل المعتمد في اختصار التوزيع الإلكتروني لعناصر الدورة الرابعة (Z=19..36).' },
  { number: 19, symbol: 'K', nameAr: 'بوتاسيوم', nameEn: 'Potassium', mass: 39.098, group: 1, period: 4, block: 's', category: 'alkali', shells: [2, 8, 8, 1], config: '[Ar] 4s¹', atomicRadiusPm: 227, firstIonizationKj: 419, electronAffinityKj: -48, electronegativity: 0.82, stateAr: 'صلب', highlightAr: 'يبدأ به ملء 4s قبل 3d حسب قاعدة (n+l)؛ ويدخل في KNO₃ و KO₂ و KMnO₄.' },
  { number: 20, symbol: 'Ca', nameAr: 'كالسيوم', nameEn: 'Calcium', mass: 40.078, group: 2, period: 4, block: 's', category: 'alkaline', shells: [2, 8, 8, 2], config: '[Ar] 4s²', atomicRadiusPm: 197, firstIonizationKj: 590, electronAffinityKj: -2, electronegativity: 1.0, stateAr: 'صلب', highlightAr: 'عدد تأكسده +2 دائماً؛ وفي هيدريد الكالسيوم CaH₂ يكون عدد تأكسد الهيدروجين (-1).' },
  { number: 21, symbol: 'Sc', nameAr: 'سكانديوم', nameEn: 'Scandium', mass: 44.956, group: 3, period: 4, block: 'd', category: 'transition', shells: [2, 8, 9, 2], config: '[Ar] 4s² 3d¹', atomicRadiusPm: 162, firstIonizationKj: 633, electronAffinityKj: -18, electronegativity: 1.36, stateAr: 'صلب', highlightAr: 'أول عنصر انتقالي رئيسي في الفئة d (تبدأ بالظهور في الدورة الرابعة).' },
  { number: 22, symbol: 'Ti', nameAr: 'تيتانيوم', nameEn: 'Titanium', mass: 47.867, group: 4, period: 4, block: 'd', category: 'transition', shells: [2, 8, 10, 2], config: '[Ar] 4s² 3d²', atomicRadiusPm: 147, firstIonizationKj: 659, electronAffinityKj: -8, electronegativity: 1.54, stateAr: 'صلب', highlightAr: 'عنصر انتقالي رئيسي في الفئة d يحتوي على إلكترونين مفردين في أوربيتالات 3d.' },
  { number: 23, symbol: 'V', nameAr: 'فاناديوم', nameEn: 'Vanadium', mass: 50.942, group: 5, period: 4, block: 'd', category: 'transition', shells: [2, 8, 11, 2], config: '[Ar] 4s² 3d³', atomicRadiusPm: 134, firstIonizationKj: 651, electronAffinityKj: -51, electronegativity: 1.63, stateAr: 'صلب', highlightAr: 'يمتلك 3 إلكترونات مفردة في 3d طبقاً لقاعدة هوند.' },
  { number: 24, symbol: 'Cr', nameAr: 'كروم', nameEn: 'Chromium', mass: 51.996, group: 6, period: 4, block: 'd', category: 'transition', shells: [2, 8, 13, 1], config: '[Ar] 4s¹ 3d⁵', atomicRadiusPm: 128, firstIonizationKj: 653, electronAffinityKj: -64, electronegativity: 1.66, stateAr: 'صلب', highlightAr: 'أشهر شذوذ في التوزيع الإلكتروني: 4s¹ 3d⁵ ليصبح 3d نصف ممتلئ (6 إلكترونات مفردة).', anomalyNoteAr: 'شذوذ التوزيع الإلكتروني: [Ar] 4s¹ 3d⁵ بدلاً من 4s² 3d⁴ لتحقيق استقرار نصف الامتلاء.' },
  { number: 25, symbol: 'Mn', nameAr: 'منجنيز', nameEn: 'Manganese', mass: 54.938, group: 7, period: 4, block: 'd', category: 'transition', shells: [2, 8, 13, 2], config: '[Ar] 4s² 3d⁵', atomicRadiusPm: 127, firstIonizationKj: 717, electronAffinityKj: 0, electronegativity: 1.55, stateAr: 'صلب', highlightAr: 'يصل عدد تأكسده إلى (+7) في برمنجنات البوتاسيوم KMnO₄ ويعمل كعامل مؤكسد قوي.' },
  { number: 26, symbol: 'Fe', nameAr: 'حديد', nameEn: 'Iron', mass: 55.845, group: 8, period: 4, block: 'd', category: 'transition', shells: [2, 8, 14, 2], config: '[Ar] 4s² 3d⁶', atomicRadiusPm: 126, firstIonizationKj: 763, electronAffinityKj: -15, electronegativity: 1.83, stateAr: 'صلب', highlightAr: 'مثال الكتاب لتدرج نصف القطر الأيوني: Fe (126 pm) > Fe²⁺ (78 pm) > Fe³⁺ (64.5 pm).' },
  { number: 27, symbol: 'Co', nameAr: 'كوبالت', nameEn: 'Cobalt', mass: 58.933, group: 9, period: 4, block: 'd', category: 'transition', shells: [2, 8, 15, 2], config: '[Ar] 4s² 3d⁷', atomicRadiusPm: 125, firstIonizationKj: 760, electronAffinityKj: -64, electronegativity: 1.88, stateAr: 'صلب', highlightAr: 'ينتمي للمجموعة الثامنة (3 أعمدة متشابهة أفقياً أكثر من رأسياً مع Fe و Ni).' },
  { number: 28, symbol: 'Ni', nameAr: 'نيكل', nameEn: 'Nickel', mass: 58.693, group: 10, period: 4, block: 'd', category: 'transition', shells: [2, 8, 16, 2], config: '[Ar] 4s² 3d⁸', atomicRadiusPm: 124, firstIonizationKj: 737, electronAffinityKj: -112, electronegativity: 1.91, stateAr: 'صلب', highlightAr: 'عنصر من أعمدة المجموعة الثامنة في الفئة d يحتوي على إلكترونين مفردين في 3d.' },
  { number: 29, symbol: 'Cu', nameAr: 'نحاس', nameEn: 'Copper', mass: 63.546, group: 11, period: 4, block: 'd', category: 'transition', shells: [2, 8, 18, 1], config: '[Ar] 4s¹ 3d¹⁰', atomicRadiusPm: 128, firstIonizationKj: 745, electronAffinityKj: -119, electronegativity: 1.9, stateAr: 'صلب', highlightAr: 'يشذ في التوزيع الإلكتروني (4s¹ 3d¹⁰) لتحقيق امتلاء تام للمستوى 3d؛ ويدخل في CuSO₄·5H₂O.', anomalyNoteAr: 'شذوذ التوزيع الإلكتروني: [Ar] 4s¹ 3d¹⁰ بدلاً من 4s² 3d⁹ لتحقيق الامتلاء التام لـ 3d.' },
  { number: 30, symbol: 'Zn', nameAr: 'خارصين', nameEn: 'Zinc', mass: 65.38, group: 12, period: 4, block: 'd', category: 'transition', shells: [2, 8, 18, 2], config: '[Ar] 4s² 3d¹⁰', atomicRadiusPm: 134, firstIonizationKj: 906, electronAffinityKj: 0, electronegativity: 1.65, stateAr: 'صلب', highlightAr: 'أكسيده ZnO أكسيد متردد يتفاعل مع H₂SO₄ و NaOH؛ ومركبه ZnS يعطي وميضاً في تجربة رذرفورد.' },
  { number: 31, symbol: 'Ga', nameAr: 'جاليوم', nameEn: 'Gallium', mass: 69.723, group: 13, period: 4, block: 'p', category: 'post-transition', shells: [2, 8, 18, 3], config: '[Ar] 4s² 3d¹⁰ 4p¹', atomicRadiusPm: 135, firstIonizationKj: 579, electronAffinityKj: -29, electronegativity: 1.81, stateAr: 'صلب', highlightAr: 'عنصر ممثل من الفئة p في الدورة الرابعة يبدأ بملء المستوى الفرعي 4p.' },
  { number: 32, symbol: 'Ge', nameAr: 'جرمانيوم', nameEn: 'Germanium', mass: 72.63, group: 14, period: 4, block: 'p', category: 'metalloid', shells: [2, 8, 18, 4], config: '[Ar] 4s² 3d¹⁰ 4p²', atomicRadiusPm: 122, firstIonizationKj: 762, electronAffinityKj: -119, electronegativity: 2.01, stateAr: 'صلب', highlightAr: 'من أشباه الفلزات المقررة (B, Si, Ge, As, Sb, Te, At) المستخدمة في الإلكترونيات.' },
  { number: 33, symbol: 'As', nameAr: 'زرنيخ', nameEn: 'Arsenic', mass: 74.922, group: 15, period: 4, block: 'p', category: 'metalloid', shells: [2, 8, 18, 5], config: '[Ar] 4s² 3d¹⁰ 4p³', atomicRadiusPm: 119, firstIonizationKj: 947, electronAffinityKj: -78, electronegativity: 2.18, stateAr: 'صلب', highlightAr: 'شبه فلز في المجموعة 5A ينتهي توزيعه بـ 4p³ نصف الممتلئ.' },
  { number: 34, symbol: 'Se', nameAr: 'سيلينيوم', nameEn: 'Selenium', mass: 78.971, group: 16, period: 4, block: 'p', category: 'nonmetal', shells: [2, 8, 18, 6], config: '[Ar] 4s² 3d¹⁰ 4p⁴', atomicRadiusPm: 116, firstIonizationKj: 941, electronAffinityKj: -195, electronegativity: 2.55, stateAr: 'صلب', highlightAr: 'لافلز في المجموعة 6A يشبه الكبريت والأكسجين في تركيب غلاف التكافؤ.' },
  { number: 35, symbol: 'Br', nameAr: 'بروم', nameEn: 'Bromine', mass: 79.904, group: 17, period: 4, block: 'p', category: 'halogen', shells: [2, 8, 18, 7], config: '[Ar] 4s² 3d¹⁰ 4p⁵', atomicRadiusPm: 114, firstIonizationKj: 1140, electronAffinityKj: -325, electronegativity: 2.96, stateAr: 'سائل', highlightAr: 'هالوجين سائل؛ مثال الكتاب للميل الإلكتروني: Br(g) + e⁻ → Br⁻(g), ΔH = -325 kJ/mol.' },
  { number: 36, symbol: 'Kr', nameAr: 'كريبتون', nameEn: 'Krypton', mass: 83.798, group: 18, period: 4, block: 'p', category: 'noble', shells: [2, 8, 18, 8], config: '[Ar] 4s² 3d¹⁰ 4p⁶', atomicRadiusPm: 88, firstIonizationKj: 1351, electronAffinityKj: 0, electronegativity: null, stateAr: 'غاز', highlightAr: 'غاز نبيل في نهاية الدورة الرابعة بامتلاء تام للمستوى 4p⁶.' },
  { number: 55, symbol: 'Cs', nameAr: 'سيزيوم', nameEn: 'Cesium', mass: 132.905, group: 1, period: 6, block: 's', category: 'alkali', shells: [2, 8, 18, 18, 8, 1], config: '[Xe] 6s¹', atomicRadiusPm: 265, firstIonizationKj: 377, electronAffinityKj: -46, electronegativity: 0.79, stateAr: 'صلب', highlightAr: 'أقوى الفلزات وأكبر العناصر حجماً (265 pm) وأقلها في جهد التأين (377 kJ/mol) والسالبية.', anomalyNoteAr: 'القمة الفلزية: أكبر نصف قطر ذري (265 pm) وأقل جهد تأين أول (377 kJ/mol).' },
];
