export type CertificateEdition = 'royal-gold' | 'emerald-molecular' | 'platinum-parchment';

export interface HardChallengeQuestion {
  id: string;
  topic: string;
  lessonId: string;
  sectionIndex: number;
  question: string;
  formula?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface CertificateEvaluation {
  correct: number;
  total: number;
  percentage: number;
  passed: boolean;
  tierTitle: string;
  tierRank: 'diamond' | 'gold' | 'none';
}

export interface SavedCertificate {
  id: string;
  serial: string;
  studentName: string;
  studentGrade: string;
  edition: CertificateEdition;
  scoreCorrect: number;
  scoreTotal: number;
  percentage: number;
  tierTitle: string;
  tierRank: 'diamond' | 'gold';
  issuedDateAr: string;
  createdAtIso: string;
}

export const CERTIFICATE_PASS_PERCENTAGE = 80;

export const HARD_CERTIFICATE_QUESTIONS: readonly HardChallengeQuestion[] = [
  {
    id: 'hc-1',
    topic: 'الباب الأول · المول والأملاح المتهدرتة',
    lessonId: 'lesson-1',
    sectionIndex: 1,
    question:
      'عينة من بلورات كبريتات النحاس المتهدرتة صيغتها CuSO₄·xH₂O كتلتها 24.95 g، وعند تسخينها تماماً حتى ثبوت الكتلة فقدت 9 g من كتلتها على هيئة بخار ماء. ما قيمة x علماً بأن Cu = 63.5, S = 32, O = 16, H = 1؟',
    formula: 'CuSO₄·xH₂O(s) —(Δ)→ CuSO₄(s) + xH₂O(v)',
    options: ['2', '3', '5', '7'],
    correctIndex: 2,
    explanation:
      'كتلة الملح اللامائي CuSO₄ = 24.95 − 9 = 15.95 g، وكتلته المولية 159.5 g/mol، إذن عدد مولاته = 0.1 mol. وعدد مولات الماء المتطاير = 9 ÷ 18 = 0.5 mol، فتكون قيمة x = 0.5 ÷ 0.1 = 5.',
  },
  {
    id: 'hc-2',
    topic: 'الباب الأول · العامل المحدد والمحاليل',
    lessonId: 'lesson-2',
    sectionIndex: 1,
    question:
      'في التفاعل الموزون 4NH₃ + 5O₂ → 4NO + 6H₂O، عند خلط 0.8 mol من NH₃ مع 0.8 mol من O₂، فإن العامل المحدد وعدد مولات NO الناتجة هما على الترتيب:',
    formula: '4NH₃(g) + 5O₂(g) → 4NO(g) + 6H₂O(v)',
    options: [
      'NH₃ — و 0.8 mol',
      'O₂ — و 0.64 mol',
      'NH₃ — و 0.64 mol',
      'O₂ — و 0.8 mol',
    ],
    correctIndex: 1,
    explanation:
      'نسبة NH₃ = 0.8 ÷ 4 = 0.20، ونسبة O₂ = 0.8 ÷ 5 = 0.16؛ الأقل هو O₂ فهو العامل المحدد. وبنسبة 5 إلى 4 يكون عدد مولات NO الناتجة = 0.8 × 4 ÷ 5 = 0.64 mol.',
  },
  {
    id: 'hc-3',
    topic: 'الباب الأول · تركيز الأيونات وتخفيف المحاليل',
    lessonId: 'lesson-4',
    sectionIndex: 1,
    question:
      'أُضيف 300 mL من الماء المقطر إلى 200 mL من محلول كربونات الصوديوم Na₂CO₃ تركيزه 0.5 M. ما التركيز المولاري لأيونات الصوديوم Na⁺ في المحلول الناتج؟',
    formula: 'M₁V₁ = M₂V₂  |  Na₂CO₃ → 2Na⁺ + CO₃²⁻',
    options: ['0.2 M', '0.4 M', '0.6 M', '1.0 M'],
    correctIndex: 1,
    explanation:
      'الحجم الكلي V₂ = 200 + 300 = 500 mL = 0.5 L؛ إذن تركيز الملح المخفف M₂ = (0.5 × 0.2) ÷ 0.5 = 0.2 M. وبما أن كل مول يعطي 2 mol من Na⁺، فإن تركيز [Na⁺] = 0.2 × 2 = 0.4 M.',
  },
  {
    id: 'hc-4',
    topic: 'الباب الثاني · أعداد الكم وقواعد التوزيع',
    lessonId: 'lesson-8',
    sectionIndex: 1,
    question:
      'عنصر انتقالي توزيعه الإلكتروني ينتهي بالمستوى الفرعي 3d⁵ ويحتوي مستواه الخارجي 4s على إلكترون واحد فقط (شذوذ توزيع لتحقيق الاستقرار). ما العدد الذري لهذا العنصر وعدد إلكتروناته المفردة الكلي؟',
    formula: '[Ar] 4s¹ 3d⁵',
    options: [
      '25 — و 5 إلكترونات مفردة',
      '24 — و 6 إلكترونات مفردة',
      '24 — و 5 إلكترونات مفردة',
      '29 — و إلكترون واحد مفرد',
    ],
    correctIndex: 1,
    explanation:
      'العنصر هو الكروم ₂₄Cr وتوزيعه الشاذ [Ar] 4s¹ 3d⁵ لتحقيق استقرار النصف ممتلئ، ويمتلك 1 إلكترون مفرد في 4s + 5 إلكترونات مفردة في 3d = 6 إلكترونات مفردة.',
  },
  {
    id: 'hc-5',
    topic: 'الباب الثالث · أعداد التأكسد والأكسدة والاختزال',
    lessonId: 'lesson-12',
    sectionIndex: 0,
    question:
      'ما الفرق الحسابي بين عددي تأكسد ذرتي النيتروجين في مركب نيتريت الأمونيوم NH₄NO₂؟',
    formula: 'NH₄⁺   +   NO₂⁻',
    options: ['0', '3', '6', '8'],
    correctIndex: 2,
    explanation:
      'في أيون الأمونيوم NH₄⁺ يكون عدد تأكسد N يساوي (−3)، وفي أيون النيتريت NO₂⁻ يكون عدد تأكسد N يساوي (+3)؛ إذن الفرق الحسابي بينهما = (+3) − (−3) = 6.',
  },
];

export function evaluateCertificateEligibility(
  selectedAnswers: Record<string, number>,
  questions: readonly HardChallengeQuestion[] = HARD_CERTIFICATE_QUESTIONS
): CertificateEvaluation {
  const total = questions.length;
  let correct = 0;

  for (const q of questions) {
    if (selectedAnswers[q.id] === q.correctIndex) {
      correct += 1;
    }
  }

  const percentage = total > 0 ? Math.round((correct / total) * 100) : 0;
  const passed = percentage >= CERTIFICATE_PASS_PERCENTAGE;

  if (percentage === 100) {
    return {
      correct,
      total,
      percentage,
      passed: true,
      tierTitle: 'وسام التميّز الماسي — نُخبة الكيمياء',
      tierRank: 'diamond',
    };
  }
  if (passed) {
    return {
      correct,
      total,
      percentage,
      passed: true,
      tierTitle: 'وسام التفوق الذهبي — باحث كيميائي متقدم',
      tierRank: 'gold',
    };
  }
  return {
    correct,
    total,
    percentage,
    passed: false,
    tierTitle: 'لم يتم بلوغ حد التأهيل (80%) بعد',
    tierRank: 'none',
  };
}

export function generateCertificateSerial(studentName: string, timestampMs: number): string {
  const clean = studentName.trim();
  let hash = 2166136261;
  const seed = `${clean}-${timestampMs}`;
  for (let i = 0; i < seed.length; i += 1) {
    hash ^= seed.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  const code = (hash >>> 0).toString(36).toUpperCase().padStart(6, '0').slice(0, 6);
  return `CHEM-2026-${code}`;
}

export function formatArabicCertificateDate(date: Date): string {
  try {
    return new Intl.DateTimeFormat('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  } catch {
    return date.toISOString().slice(0, 10);
  }
}

export function validateStudentName(name: string): { valid: boolean; error?: string } {
  const trimmed = name.trim();
  if (trimmed.length < 3) {
    return { valid: false, error: 'الرجاء كتابة اسمك الكامل (3 أحرف على الأقل) ليُنقش على الشهادة.' };
  }
  if (trimmed.length > 60) {
    return { valid: false, error: 'الاسم طويل جداً، يُرجى اختصاره لأقل من 60 حرفاً.' };
  }
  return { valid: true };
}
