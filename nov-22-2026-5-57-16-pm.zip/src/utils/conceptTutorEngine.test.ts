import test from 'node:test';
import assert from 'node:assert/strict';
import { ACADEMY_DATA } from '../data/academyData';
import {
  CONCEPT_COMPARISON_DECKS,
  OXIDATION_WORKED_CASES,
  analyzeElementQuantum,
  computeReadinessDiagnostic,
  solveDilutionProblem,
  solveMoleProblem,
} from './conceptTutorEngine';
import { buildMistakeFromQuizQuestion, upsertMistakeRecord } from './mistakesEngine';

test('solveMoleProblem calculates moles, Avogadro particles, STP and rtp volumes accurately', () => {
  const res = solveMoleProblem(44, 44);
  assert.equal(res.valid, true);
  assert.equal(res.moles, 1);
  assert.equal(res.volumeSTP, 22.4);
  assert.equal(res.volumeRTP, 24);
  assert.equal(res.steps.length, 3);

  const invalid = solveMoleProblem(-5, 18);
  assert.equal(invalid.valid, false);
});

test('solveDilutionProblem calculates final volume V2 and added water (V2 - V1)', () => {
  const res = solveDilutionProblem(2, 100, 0.5);
  assert.equal(res.valid, true);
  assert.equal(res.v2Ml, 400);
  assert.equal(res.waterAddedMl, 300);
  assert.equal(res.molesSolute, 0.2);
  assert.equal(res.steps.length, 3);

  // Rejects M2 >= M1 since dilution must lower concentration
  const invalid = solveDilutionProblem(1, 100, 1.5);
  assert.equal(invalid.valid, false);
});

test('analyzeElementQuantum resolves standard elements and Cr/Cu anomalies with exact quantum numbers', () => {
  const cr = analyzeElementQuantum(24);
  assert.equal(cr.symbol, 'Cr');
  assert.equal(cr.isAnomaly, true);
  assert.equal(cr.nobleGasConfig, '[Ar] 4s¹ 3d⁵');
  assert.equal(cr.unpairedElectrons, 6);
  assert.equal(cr.lastElectronQuantum.n, 3);
  assert.equal(cr.lastElectronQuantum.l, 2);
  assert.equal(cr.lastElectronQuantum.ml, 2);
  assert.equal(cr.lastElectronQuantum.ms, '+½');

  const cu = analyzeElementQuantum(29);
  assert.equal(cu.symbol, 'Cu');
  assert.equal(cu.isAnomaly, true);
  assert.equal(cu.nobleGasConfig, '[Ar] 4s¹ 3d¹⁰');
  assert.equal(cu.unpairedElectrons, 1);
  assert.equal(cu.lastElectronQuantum.ms, '-½');

  const na = analyzeElementQuantum(11);
  assert.equal(na.nobleGasConfig, '[Ne] 3s¹');
  assert.equal(na.period, 3);
  assert.equal(na.block, 's');
  assert.equal(na.lastElectronQuantum.n, 3);
  assert.equal(na.lastElectronQuantum.l, 0);
  assert.equal(na.lastElectronQuantum.ml, 0);
  assert.equal(na.lastElectronQuantum.ms, '+½');
});

test('concept comparisons, oxidation worked cases, and mastery diagnostics cover all 12 lessons', () => {
  assert.ok(CONCEPT_COMPARISON_DECKS.length >= 6);
  assert.ok(OXIDATION_WORKED_CASES.length >= 6);

  const qL2 = ACADEMY_DATA.quiz.questions.find((q) => q.lessonId === 'lesson-2')!;
  const mistakes = upsertMistakeRecord([], buildMistakeFromQuizQuestion(qL2, 0, 'question-bank'));

  const diag = computeReadinessDiagnostic(
    ACADEMY_DATA.lessons.items,
    ['lesson-1', 'lesson-5'],
    mistakes
  );
  assert.equal(diag.nodes.length, 12);
  assert.equal(diag.byUnit.length, 3);
  assert.equal(diag.priorityAction.lessonId, 'lesson-2');
  assert.equal(diag.priorityAction.mode, 'mistakes');
});
