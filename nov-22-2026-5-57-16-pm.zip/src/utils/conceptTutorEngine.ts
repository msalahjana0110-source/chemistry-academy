import type { LessonItem, UnitId } from '../data/academyData';
import type { MistakeRecord } from './mistakesEngine';

export interface TutorStep {
  stepNumber: number;
  title: string;
  formula?: string;
  explanation: string;
}

export interface MoleTutorResult {
  valid: boolean;
  error?: string;
  moles: number;
  particles: number;
  volumeSTP: number;
  volumeRTP: number;
  steps: TutorStep[];
  examTrap: string;
}

export const AVOGADRO = 6.02e23;

export function solveMoleProblem(massGrams: number, molarMass: number): MoleTutorResult {
  if (!Number.isFinite(massGrams) || massGrams <= 0) {
    return {
      valid: false,
      error: 'أدخل كتلة صحيحة أكبر من الصفر بالجرام (g).',
      moles: 0,
      particles: 0,
      volumeSTP: 0,
      volumeRTP: 0,
      steps: [],
      examTrap: '',
    };
  }
  if (!Number.isFinite(molarMass) || molarMass <= 0) {
    return {
      valid: false,
      error: 'أدخل كتلة مولية صحيحة أكبر من الصفر (g/mol).',
      moles: 0,
      particles: 0,
      volumeSTP: 0,
      volumeRTP: 0,
      steps: [],
      examTrap: '',
    };
  }

  const moles = Number((massGrams / molarMass).toFixed(4));
  const particles = moles * AVOGADRO;
  const volumeSTP = Number((moles * 22.4).toFixed(3));
  const volumeRTP = Number((moles * 24.0).toFixed(3));
  const particlesCoeff = Number((moles * 6.02).toFixed(3));

  return {
    valid: true,
    moles,
    particles,
    volumeSTP,
    volumeRTP,
    steps: [
      {
        stepNumber: 1,
        title: 'حساب عدد المولات (n) من الكتلة والكتلة المولية',
        formula: `n = m / M = ${massGrams} / ${molarMass} = ${moles} mol`,
        explanation:
          'المول هو الجسر المركزي في كل مسائل الحساب الكيميائي؛ نقسم الكتلة بالجرام على الكتلة المولية لنصل إلى عدد المولات.',
      },
      {
        stepNumber: 2,
        title: 'حساب عدد الجسيمات (ذرات أو جزيئات أو أيونات)',
        formula: `N = n × 6.02 × 10²³ = ${moles} × 6.02 × 10²³ = ${particlesCoeff} × 10²³`,
        explanation:
          'كل 1 mol من أي مادة يحتوي دائماً على عدد أفوجادرو الثابت (6.02 × 10²³) من الجسيمات.',
      },
      {
        stepNumber: 3,
        title: 'حساب حجم الغاز في الظروف القياسية (STP) وظروف الغرفة (rtp)',
        formula: `V(STP) = ${moles} × 22.4 = ${volumeSTP} L  |  V(rtp) = ${moles} × 24 = ${volumeRTP} L`,
        explanation:
          'عند 0°C وضغط 1 atm (STP) يشغل المول 22.4 L، أما عند 25°C وضغط 1 atm (rtp) فيشغل 24.0 L.',
      },
    ],
    examTrap:
      'فخ امتحاني: تأكد هل المطلوب عدد الجزيئات أم عدد الذرات داخل الجزيء (اضرب في عدد ذرات الجزيء)، وانتبه للفرق بين STP (22.4 L) و rtp (24 L).',
  };
}

export interface DilutionTutorResult {
  valid: boolean;
  error?: string;
  molesSolute: number;
  v2Ml: number;
  waterAddedMl: number;
  concentrationRatio: number;
  steps: TutorStep[];
  examTrap: string;
}

export function solveDilutionProblem(
  m1: number,
  v1Ml: number,
  m2: number
): DilutionTutorResult {
  if (!Number.isFinite(m1) || m1 <= 0 || !Number.isFinite(v1Ml) || v1Ml <= 0) {
    return {
      valid: false,
      error: 'أدخل تركيزاً ابتدائياً M₁ وحجماً ابتدائياً V₁ أكبر من الصفر.',
      molesSolute: 0,
      v2Ml: 0,
      waterAddedMl: 0,
      concentrationRatio: 0,
      steps: [],
      examTrap: '',
    };
  }
  if (!Number.isFinite(m2) || m2 <= 0 || m2 >= m1) {
    return {
      valid: false,
      error: 'في التخفيف يجب أن يكون التركيز النهائي M₂ أكبر من الصفر وأصغر من التركيز الابتدائي M₁.',
      molesSolute: 0,
      v2Ml: 0,
      waterAddedMl: 0,
      concentrationRatio: 0,
      steps: [],
      examTrap: '',
    };
  }

  const v2Ml = Number(((m1 * v1Ml) / m2).toFixed(2));
  const waterAddedMl = Number((v2Ml - v1Ml).toFixed(2));
  const molesSolute = Number(((m1 * v1Ml) / 1000).toFixed(4));
  const concentrationRatio = Number((m2 / m1).toFixed(3));

  return {
    valid: true,
    molesSolute,
    v2Ml,
    waterAddedMl,
    concentrationRatio,
    steps: [
      {
        stepNumber: 1,
        title: 'حساب عدد مولات المذاب الثابتة قبل وبعد التخفيف',
        formula: `n = M₁ × V₁(L) = ${m1} × (${v1Ml} / 1000) = ${molesSolute} mol`,
        explanation:
          'إضافة الماء المقطر تزيد حجم المحلول وتقلل التركيز، لكن عدد مولات المذاب يظل ثابتاً لا يتغير.',
      },
      {
        stepNumber: 2,
        title: 'تطبيق قانون التخفيف لإيجاد الحجم النهائي الكلي للمحلول (V₂)',
        formula: `M₁ × V₁ = M₂ × V₂  ⇒  V₂ = (${m1} × ${v1Ml}) / ${m2} = ${v2Ml} mL`,
        explanation:
          'نلاحظ أنه يمكن استخدام mL في الطرفين بشرط توحيد الوحدة في V₁ و V₂.',
      },
      {
        stepNumber: 3,
        title: 'حساب حجم الماء المقطر الواجب إضافته',
        formula: `V(الماء المضاف) = V₂ − V₁ = ${v2Ml} − ${v1Ml} = ${waterAddedMl} mL`,
        explanation:
          'الحجم الكلي الناتج هو V₂، لكن السؤال الامتحاني غالباً يطلب حجم الماء المضاف فقط وهو الفرق (V₂ − V₁).',
      },
    ],
    examTrap:
      'أشهر فخ في الدرس 04: لا تكتب V₂ كإجابة عندما يسألك «ما حجم الماء المضاف؟» بل اطرح دائماً V₂ − V₁.',
  };
}

export interface OrbitalBox {
  ml: number;
  electrons: Array<'up' | 'down'>;
}

export interface SubshellConfig {
  label: string;
  n: number;
  l: number;
  count: number;
  capacity: number;
  boxes: OrbitalBox[];
}

export interface QuantumTutorResult {
  atomicNumber: number;
  symbol: string;
  nameAr: string;
  fullConfig: string;
  nobleGasConfig: string;
  subshells: SubshellConfig[];
  lastSubshell: SubshellConfig;
  lastElectronQuantum: {
    n: number;
    l: number;
    subshellLetter: string;
    ml: number;
    ms: '+½' | '-½';
  };
  period: number;
  block: 's' | 'p' | 'd';
  groupLabel: string;
  unpairedElectrons: number;
  isAnomaly: boolean;
  anomalyNote?: string;
}

const ELEMENTS_1_36: ReadonlyArray<{ z: number; symbol: string; nameAr: string }> = [
  { z: 1, symbol: 'H', nameAr: 'الهيدروجين' },
  { z: 2, symbol: 'He', nameAr: 'الهيليوم' },
  { z: 3, symbol: 'Li', nameAr: 'الليثيوم' },
  { z: 4, symbol: 'Be', nameAr: 'البريليوم' },
  { z: 5, symbol: 'B', nameAr: 'البورون' },
  { z: 6, symbol: 'C', nameAr: 'الكربون' },
  { z: 7, symbol: 'N', nameAr: 'النيتروجين' },
  { z: 8, symbol: 'O', nameAr: 'الأكسجين' },
  { z: 9, symbol: 'F', nameAr: 'الفلور' },
  { z: 10, symbol: 'Ne', nameAr: 'النيون' },
  { z: 11, symbol: 'Na', nameAr: 'الصوديوم' },
  { z: 12, symbol: 'Mg', nameAr: 'الماغنسيوم' },
  { z: 13, symbol: 'Al', nameAr: 'الألومنيوم' },
  { z: 14, symbol: 'Si', nameAr: 'السيليكون' },
  { z: 15, symbol: 'P', nameAr: 'الفوسفور' },
  { z: 16, symbol: 'S', nameAr: 'الكبريت' },
  { z: 17, symbol: 'Cl', nameAr: 'الكلور' },
  { z: 18, symbol: 'Ar', nameAr: 'الأرجون' },
  { z: 19, symbol: 'K', nameAr: 'البوتاسيوم' },
  { z: 20, symbol: 'Ca', nameAr: 'الكالسيوم' },
  { z: 21, symbol: 'Sc', nameAr: 'السكانديوم' },
  { z: 22, symbol: 'Ti', nameAr: 'التيتانيوم' },
  { z: 23, symbol: 'V', nameAr: 'الفاناديوم' },
  { z: 24, symbol: 'Cr', nameAr: 'الكروم' },
  { z: 25, symbol: 'Mn', nameAr: 'المنجنيز' },
  { z: 26, symbol: 'Fe', nameAr: 'الحديد' },
  { z: 27, symbol: 'Co', nameAr: 'الكوبالت' },
  { z: 28, symbol: 'Ni', nameAr: 'النيكل' },
  { z: 29, symbol: 'Cu', nameAr: 'النحاس' },
  { z: 30, symbol: 'Zn', nameAr: 'الخارصين' },
  { z: 31, symbol: 'Ga', nameAr: 'الجاليوم' },
  { z: 32, symbol: 'Ge', nameAr: 'الجرمانيوم' },
  { z: 33, symbol: 'As', nameAr: 'الزرنيخ' },
  { z: 34, symbol: 'Se', nameAr: 'السيلينيوم' },
  { z: 35, symbol: 'Br', nameAr: 'البروم' },
  { z: 36, symbol: 'Kr', nameAr: 'الكريبتون' },
];

const AUFBAU_ORDER: ReadonlyArray<{
  label: string;
  n: number;
  l: number;
  letter: 's' | 'p' | 'd';
  capacity: number;
}> = [
  { label: '1s', n: 1, l: 0, letter: 's', capacity: 2 },
  { label: '2s', n: 2, l: 0, letter: 's', capacity: 2 },
  { label: '2p', n: 2, l: 1, letter: 'p', capacity: 6 },
  { label: '3s', n: 3, l: 0, letter: 's', capacity: 2 },
  { label: '3p', n: 3, l: 1, letter: 'p', capacity: 6 },
  { label: '4s', n: 4, l: 0, letter: 's', capacity: 2 },
  { label: '3d', n: 3, l: 2, letter: 'd', capacity: 10 },
  { label: '4p', n: 4, l: 1, letter: 'p', capacity: 6 },
];

const SUPERSCRIPTS: Record<string, string> = {
  '0': '⁰',
  '1': '¹',
  '2': '²',
  '3': '³',
  '4': '⁴',
  '5': '⁵',
  '6': '⁶',
  '7': '⁷',
  '8': '⁸',
  '9': '⁹',
};

function toSuperscript(num: number): string {
  return String(num)
    .split('')
    .map((ch) => SUPERSCRIPTS[ch] ?? ch)
    .join('');
}

function buildOrbitalBoxes(l: number, count: number): OrbitalBox[] {
  const numOrbitals = 2 * l + 1;
  const boxes: OrbitalBox[] = [];
  for (let i = 0; i < numOrbitals; i += 1) {
    boxes.push({ ml: -l + i, electrons: [] });
  }
  // Hund's rule: fill singly with spin up first, then pair with spin down
  for (let e = 0; e < count; e += 1) {
    const idx = e % numOrbitals;
    boxes[idx].electrons.push(e < numOrbitals ? 'up' : 'down');
  }
  return boxes;
}

export function analyzeElementQuantum(zInput: number): QuantumTutorResult {
  const z = Math.max(1, Math.min(36, Math.round(Number.isFinite(zInput) ? zInput : 1)));
  const el = ELEMENTS_1_36[z - 1];

  const counts = new Map<string, number>();
  let remaining = z;
  for (const sub of AUFBAU_ORDER) {
    if (remaining <= 0) break;
    const take = Math.min(remaining, sub.capacity);
    counts.set(sub.label, take);
    remaining -= take;
  }

  // Handle curriculum anomalies Cr (24) and Cu (29)
  let isAnomaly = false;
  let anomalyNote: string | undefined;
  if (z === 24) {
    counts.set('4s', 1);
    counts.set('3d', 5);
    isAnomaly = true;
    anomalyNote =
      'شذوذ الكروم (₂₄Cr): ينتقل إلكترون من 4s إلى 3d ليصبح كلاهما نصف ممتلئ (4s¹ 3d⁵) مما يحقق أعلى استقرار للذرة (6 إلكترونات مفردة).';
  } else if (z === 29) {
    counts.set('4s', 1);
    counts.set('3d', 10);
    isAnomaly = true;
    anomalyNote =
      'شذوذ النحاس (₂₉Cu): ينتقل إلكترون من 4s إلى 3d ليصبح المستوى 3d تام الامتلاء (3d¹⁰) والمستوى 4s نصف ممتلئ (4s¹) مما يمنح الذرة استقراراً أعلى.';
  }

  const subshells: SubshellConfig[] = [];
  for (const sub of AUFBAU_ORDER) {
    const count = counts.get(sub.label);
    if (!count) continue;
    subshells.push({
      label: sub.label,
      n: sub.n,
      l: sub.l,
      count,
      capacity: sub.capacity,
      boxes: buildOrbitalBoxes(sub.l, count),
    });
  }

  const fullConfig = subshells.map((s) => `${s.label}${toSuperscript(s.count)}`).join(' ');

  let nobleGasConfig = fullConfig;
  if (z > 18) {
    const tail = subshells
      .filter((s) => !['1s', '2s', '2p', '3s', '3p'].includes(s.label))
      .map((s) => `${s.label}${toSuperscript(s.count)}`)
      .join(' ');
    nobleGasConfig = `[Ar] ${tail}`;
  } else if (z > 10) {
    const tail = subshells
      .filter((s) => !['1s', '2s', '2p'].includes(s.label))
      .map((s) => `${s.label}${toSuperscript(s.count)}`)
      .join(' ');
    nobleGasConfig = `[Ne] ${tail}`;
  } else if (z > 2) {
    const tail = subshells
      .filter((s) => s.label !== '1s')
      .map((s) => `${s.label}${toSuperscript(s.count)}`)
      .join(' ');
    nobleGasConfig = `[He] ${tail}`;
  }

  const lastSubshell = subshells[subshells.length - 1];
  const orbitals = 2 * lastSubshell.l + 1;
  const lastElectronIndex = lastSubshell.count - 1;
  const lastMl = -lastSubshell.l + (lastElectronIndex % orbitals);
  const lastMs: '+½' | '-½' = lastElectronIndex < orbitals ? '+½' : '-½';
  const subshellLetter = lastSubshell.l === 0 ? 's' : lastSubshell.l === 1 ? 'p' : 'd';

  const period = Math.max(...subshells.map((s) => s.n));
  const block: 's' | 'p' | 'd' = subshellLetter;

  let groupLabel = '';
  if (z === 2) {
    groupLabel = 'المجموعة الصفرية (18) — غاز خامل';
  } else if (block === 's') {
    groupLabel = lastSubshell.count === 1 ? 'المجموعة 1A (1)' : 'المجموعة 2A (2)';
  } else if (block === 'p') {
    const sCount = counts.get(`${period}s`) ?? 2;
    const totalValence = sCount + lastSubshell.count;
    groupLabel =
      totalValence === 8
        ? 'المجموعة الصفرية (18) — غاز خامل'
        : `المجموعة ${totalValence}A (${totalValence + 10})`;
  } else {
    const s4 = counts.get('4s') ?? 0;
    const d3 = counts.get('3d') ?? 0;
    const sum = s4 + d3;
    if (sum >= 8 && sum <= 10) {
      groupLabel = `المجموعة الثامنة VIII (${sum})`;
    } else if (sum === 11) {
      groupLabel = 'المجموعة 1B (11)';
    } else if (sum === 12) {
      groupLabel = 'المجموعة 2B (12)';
    } else {
      groupLabel = `المجموعة ${sum}B (${sum})`;
    }
  }

  let unpairedElectrons = 0;
  for (const sub of subshells) {
    for (const box of sub.boxes) {
      if (box.electrons.length === 1) unpairedElectrons += 1;
    }
  }

  return {
    atomicNumber: z,
    symbol: el.symbol,
    nameAr: el.nameAr,
    fullConfig,
    nobleGasConfig,
    subshells,
    lastSubshell,
    lastElectronQuantum: {
      n: lastSubshell.n,
      l: lastSubshell.l,
      subshellLetter,
      ml: lastMl,
      ms: lastMs,
    },
    period,
    block,
    groupLabel,
    unpairedElectrons,
    isAnomaly,
    anomalyNote,
  };
}

export const FEATURED_QUANTUM_ELEMENTS = [
  { z: 6, label: '₆C (الكربون)' },
  { z: 7, label: '₇N (نصف ممتلئ)' },
  { z: 11, label: '₁₁Na (الصوديوم)' },
  { z: 17, label: '₁₇Cl (الكلور)' },
  { z: 24, label: '₂₄Cr (شذوذ الكروم)' },
  { z: 26, label: '₂₆Fe (الحديد)' },
  { z: 29, label: '₂₉Cu (شذوذ النحاس)' },
  { z: 30, label: '₃₀Zn (الخارصين)' },
] as const;

export interface OxidationWorkedCase {
  id: string;
  formula: string;
  targetElement: string;
  result: string;
  category: string;
  equationSteps: string[];
  ruleSummary: string;
}

export const OXIDATION_WORKED_CASES: readonly OxidationWorkedCase[] = [
  {
    id: 'ox-kmno4',
    formula: 'KMnO₄',
    targetElement: 'Mn',
    result: '+7',
    category: 'مركب متعادل (أعلى حالة تأكسد للمنجنيز)',
    equationSteps: [
      'مجموع أعداد التأكسد في المركب المتعادل = 0',
      '(+1) + Mn + 4(−2) = 0',
      'Mn − 7 = 0  ⇒  Mn = +7',
    ],
    ruleSummary: 'البوتاسيوم (المجموعة 1A) دائماً +1، والأكسجين في الأكسيد العادي −2.',
  },
  {
    id: 'ox-k2cr2o7',
    formula: 'K₂Cr₂O₇',
    targetElement: 'Cr',
    result: '+6',
    category: 'مركب متعادل (ثاني كرومات البوتاسيوم)',
    equationSteps: [
      '2(+1) + 2Cr + 7(−2) = 0',
      '2Cr − 12 = 0  ⇒  2Cr = +12',
      'Cr = +6',
    ],
    ruleSummary: 'انتبه للقسمة على 2 في النهاية لأن الصيغة تحتوي على ذرتَي كروم (Cr₂).',
  },
  {
    id: 'ox-of2',
    formula: 'OF₂',
    targetElement: 'O',
    result: '+2',
    category: 'حالة شاذة للأكسجين (مع الفلور)',
    equationSteps: [
      'الفلور أعلى العناصر سالبية كهربية فيأخذ دائماً −1',
      'O + 2(−1) = 0',
      'O = +2 (عدد تأكسد موجب للأكسجين!)',
    ],
    ruleSummary: 'المركب الوحيد بالمنهج الذي يكون فيه عدد تأكسد الأكسجين موجباً (+2).',
  },
  {
    id: 'ox-h2o2',
    formula: 'H₂O₂',
    targetElement: 'O',
    result: '−1',
    category: 'فوق أكسيد (Peroxide)',
    equationSteps: [
      '2(+1) + 2O = 0',
      '2O = −2  ⇒  O = −1',
    ],
    ruleSummary: 'في فوق الأكاسيد (H₂O₂، Na₂O₂) يكون عدد تأكسد الأكسجين −1 وليس −2.',
  },
  {
    id: 'ox-ko2',
    formula: 'KO₂',
    targetElement: 'O',
    result: '−½',
    category: 'سوبر أكسيد (Superoxide)',
    equationSteps: [
      '(+1) + 2O = 0',
      '2O = −1  ⇒  O = −½ (−0.5)',
    ],
    ruleSummary: 'سوبر أكسيد البوتاسيوم KO₂ يُستخدم لتنقية جو الغواصات، وفيه الأكسجين = −½.',
  },
  {
    id: 'ox-nah',
    formula: 'NaH',
    targetElement: 'H',
    result: '−1',
    category: 'هيدريد فلز نشط (حالة شاذة للهيدروجين)',
    equationSteps: [
      'الصوديوم (1A) دائماً +1',
      '(+1) + H = 0  ⇒  H = −1',
    ],
    ruleSummary: 'في هيدريدات الفلزات النشطة (NaH، CaH₂) يكون الهيدروجين −1 لأن سالبيته أعلى من الفلز.',
  },
];

export interface ConceptComparisonDeck {
  id: string;
  unitId: UnitId;
  lessonId: string;
  title: string;
  leftTitle: string;
  leftPoints: string[];
  rightTitle: string;
  rightPoints: string[];
  goldenRule: string;
  quickCheck: {
    question: string;
    options: [string, string, string];
    correctIndex: number;
    feedback: string;
  };
}

export const CONCEPT_COMPARISON_DECKS: readonly ConceptComparisonDeck[] = [
  {
    id: 'cmp-stp-rtp',
    unitId: 'unit1',
    lessonId: 'lesson-1',
    title: 'الحجم المولي للغاز: STP مقابل rtp',
    leftTitle: 'الظروف القياسية (STP)',
    leftPoints: [
      'درجة الحرارة: 0°C (273 K)',
      'الضغط الجوي: 1 atm',
      'حجم المول الواحد = 22.4 L',
    ],
    rightTitle: 'ظروف الغرفة (rtp)',
    rightPoints: [
      'درجة الحرارة: 25°C (298 K)',
      'الضغط الجوي: 1 atm',
      'حجم المول الواحد = 24.0 L',
    ],
    goldenRule: 'ارتفاع الحرارة من 0°C إلى 25°C يزيد تمدد الغاز من 22.4 L إلى 24.0 L لكل مول.',
    quickCheck: {
      question: 'ما حجم 0.5 mol من غاز O₂ في ظروف الغرفة (rtp)؟',
      options: ['11.2 L', '12.0 L', '24.0 L'],
      correctIndex: 1,
      feedback: 'في rtp نضرب في 24 L: إذن 0.5 × 24 = 12.0 L.',
    },
  },
  {
    id: 'cmp-emp-mol',
    unitId: 'unit1',
    lessonId: 'lesson-3',
    title: 'الصيغة الأولية مقابل الصيغة الجزيئية',
    leftTitle: 'الصيغة الأولية (Empirical)',
    leftPoints: [
      'تعبّر عن أبسط نسبة عددية صحيحة لذرات العناصر',
      'قد تشترك فيها عدة مركبات مختلفة (مثل CH₂O للجلوكوز وحمض الأسيتيك)',
      'تُحسب بقسمة النسب على الكتل الذرية ثم القسمة على أصغر ناتج',
    ],
    rightTitle: 'الصيغة الجزيئية (Molecular)',
    rightPoints: [
      'تعبّر عن العدد الفعلي والحقيقي للذرات داخل الجزيء الواحد',
      'تساوي الصيغة الأولية مضروبة في عدد وحداتها (n)',
      'n = الكتلة المولية للجزيئية ÷ الكتلة المولية للأولية',
    ],
    goldenRule: 'لا تقرّب الكسور مثل 1.5 أو 1.33 عند إيجاد الصيغة الأولية، بل اضرب كل الأرقام في 2 أو 3.',
    quickCheck: {
      question: 'مركب صيغته الأولية CH₂ وكتلته المولية 56 g/mol (C=12, H=1)، فما صيغته الجزيئية؟',
      options: ['C₂H₄', 'C₃H₆', 'C₄H₈'],
      correctIndex: 2,
      feedback: 'كتلة CH₂ = 14، إذن n = 56 ÷ 14 = 4، فتكون الصيغة الجزيئية C₄H₈.',
    },
  },
  {
    id: 'cmp-cloud-orbital',
    unitId: 'unit2',
    lessonId: 'lesson-7',
    title: 'السحابة الإلكترونية مقابل الأوربيتال (شرودنجر)',
    leftTitle: 'السحابة الإلكترونية',
    leftPoints: [
      'منطقة الفراغ المحيطة بالنواة التي يُحتمل وجود الإلكترون فيها في كل الاتجاهات والأبعاد',
      'تعكس الطبيعة الموجية ومبدأ عدم التأكد لهايزنبرج',
      'المفهوم الأوسع والأشمل لحركة الإلكترون حول النواة',
    ],
    rightTitle: 'الأوربيتال (Orbital)',
    rightPoints: [
      'منطقة داخل السحابة الإلكترونية يزداد فيها احتمال تواجد الإلكترون إلى أقصى حد',
      'يتسع الأوربيتال الواحد لإلكترونين على الأكثر متعاكسي الغزل',
      'أشكاله: s كروي متماثل، p كمثريتان متقابلتان بالرأس',
    ],
    goldenRule: 'الأوربيتال جزء محدّد عالي الكثافة الاحتمالية داخل السحابة الإلكترونية وليس مداراً دائرياً مسطحاً.',
    quickCheck: {
      question: 'كم عدد الأوربيتالات في المستوى الرئيسي الثالث (n = 3)؟',
      options: ['3 أوربيتالات', '9 أوربيتالات', '18 أوربيتالاً'],
      correctIndex: 1,
      feedback: 'عدد الأوربيتالات = n² = 3² = 9 أوربيتالات (1s-like + 3p + 5d)، بينما 18 هو عدد الإلكترونات (2n²).',
    },
  },
  {
    id: 'cmp-ie-ea-en',
    unitId: 'unit3',
    lessonId: 'lesson-10',
    title: 'فك الاشتباك: جهد التأين والميل الإلكتروني والسالبية الكهربية',
    leftTitle: 'جهد التأين والميل الإلكتروني (ذرة مفردة غازية)',
    leftPoints: [
      'جهد التأين: طاقة ممتصة (ماص ΔH+) لفصل أقل الإلكترونات ارتباطاً من ذرة مفردة غازية',
      'الميل الإلكتروني: طاقة منطلقة (طارد ΔH−) عند اكتساب الذرة المفردة الغازية إلكتروناً',
      'شذوذ شهير: الميل الإلكتروني لـ Cl أكبر من F بسبب صغر حجم F وتنافر إلكتروناته',
    ],
    rightTitle: 'السالبية الكهربية (ذرة مرتبطة في جزيء)',
    rightPoints: [
      'قدرة الذرة المرتبطة على جذب إلكترونات الرابطة الكيميائية نحوها',
      'تحدد نوع الرابطة (تساهمية نقية / قطبية / أيونية)',
      'الفلور (F = 4.0) أعلى العناصر سالبية كهربية في الجدول الدوري دون استثناء',
    ],
    goldenRule: 'جهد التأين والميل يصفان الذرة المفردة الغازية، بينما السالبية الكهربية صفة للذرة المرتبطة داخل جزيء.',
    quickCheck: {
      question: 'أيهما أعلى في الميل الإلكتروني وأيهما أعلى في السالبية الكهربية بين الفلور (F) والكلور (Cl)؟',
      options: [
        'الفلور أعلى في كليهما',
        'الكلور أعلى في الميل، والفلور أعلى في السالبية',
        'الفلور أعلى في الميل، والكلور أعلى في السالبية',
      ],
      correctIndex: 1,
      feedback: 'صحيح! الكلور يتفوق في الميل الإلكتروني (شذوذ الفلور)، بينما الفلور هو الأعلى عالمياً في السالبية الكهربية.',
    },
  },
  {
    id: 'cmp-oxides',
    unitId: 'unit3',
    lessonId: 'lesson-11',
    title: 'أنواع الأكاسيد الأربعة في المنهج',
    leftTitle: 'الأكاسيد القاعدية والحامضية',
    leftPoints: [
      'القاعدية (أكاسيد فلزات مثل Na₂O, MgO): تتفاعل مع الأحماض وتذوب في الماء معطية قلويات',
      'الحامضية (أكاسيد لافلزات مثل CO₂, SO₃): تتفاعل مع القواعد وتذوب في الماء معطية أحماضاً',
      'في الدورة من اليسار لليمين: تقل الصفة القاعدية وتزداد الصفة الحامضية',
    ],
    rightTitle: 'الأكاسيد المترددة والمتعادلة (الأكثر وروداً بالامتحان)',
    rightPoints: [
      'المترددة الأربعة: Al₂O₃، ZnO، Sb₂O₃، SnO (تتفاعل مع الأحماض والقواعد معاً)',
      'المتعادلة الثلاثة: CO، NO، N₂O (لا تتفاعل مع الأحماض ولا مع القواعد)',
      'مثال شهير: Al₂O₃ يتفاعل مع HCl كقاعدة ومع NaOH كحمض',
    ],
    goldenRule: 'احفظ الرباعية المترددة (Al₂O₃, ZnO, Sb₂O₃, SnO) والثلاثية المتعادلة (CO, NO, N₂O) عن ظهر قلب.',
    quickCheck: {
      question: 'أي من الأزواج التالية يتكوّن من أكسيد متردد وأكسيد متعادل على الترتيب؟',
      options: ['ZnO و CO', 'MgO و SO₃', 'Al₂O₃ و Na₂O'],
      correctIndex: 0,
      feedback: 'ممتاز! ZnO أكسيد متردد، و CO أكسيد متعادل لا يتفاعل مع الأحماض أو القواعد.',
    },
  },
  {
    id: 'cmp-disprop',
    unitId: 'unit3',
    lessonId: 'lesson-12',
    title: 'عدم التناسب مقابل التناسب المشترك (أكسدة واختزال)',
    leftTitle: 'تفاعل عدم التناسب (Disproportionation)',
    leftPoints: [
      'يتأكسد ويُختزل نفس العنصر من حالة تأكسد واحدة إلى حالتين مختلفتين',
      'مثال: Cl₂ (0) + H₂O → HCl (−1) + HClO (+1)',
      'تكون المادة نفسها عاملاً مؤكسداً وعاملاً مختزلاً في آنٍ واحد',
    ],
    rightTitle: 'تفاعل التناسب المشترك (Comproportionation)',
    rightPoints: [
      'تتفاعل ذرات نفس العنصر بحالتي تأكسد مختلفتين لتعطي حالة وسطية واحدة',
      'مثال: 2H₂S (−2) + SO₂ (+4) → 3S (0) + 2H₂O',
      'عكس تفاعل عدم التناسب تماماً',
    ],
    goldenRule: 'تتبّع عدد تأكسد العنصر المتكرر في المتفاعلات والنواتج؛ التفرع من حالة لحالتين = عدم تناسب، والالتقاء = تناسب مشترك.',
    quickCheck: {
      question: 'يُصنّف التفاعل Cl₂ + 2NaOH → NaCl + NaClO + H₂O على أنه تفاعل:',
      options: ['عدم تناسب (أكسدة واختزال ذاتي)', 'تناسب مشترك', 'تفاعل ليس به أكسدة أو اختزال'],
      correctIndex: 0,
      feedback: 'صحيح! تغيّر الكلور من (0) إلى (−1) اختزالاً وإلى (+1) أكسدةً في التفاعل نفسه.',
    },
  },
];

export interface LessonMasteryNode {
  lessonId: string;
  lessonNumber: number;
  unitId: UnitId;
  title: string;
  status: 'mastered' | 'needs-review' | 'in-progress';
  unresolvedMistakes: number;
  prerequisiteIds: string[];
  keyTakeaway: string;
}

export interface ReadinessDiagnostic {
  overallPercent: number;
  byUnit: Array<{
    unitId: UnitId;
    unitName: string;
    completedCount: number;
    totalLessons: number;
    unresolvedMistakes: number;
    readinessPercent: number;
  }>;
  nodes: LessonMasteryNode[];
  priorityAction: {
    title: string;
    reason: string;
    lessonId: string;
    mode: 'mistakes' | 'lesson';
  };
}

const PREREQUISITE_MAP: Record<string, string[]> = {
  'lesson-1': [],
  'lesson-2': ['lesson-1'],
  'lesson-3': ['lesson-1'],
  'lesson-4': ['lesson-1', 'lesson-2'],
  'lesson-5': [],
  'lesson-6': ['lesson-5'],
  'lesson-7': ['lesson-6'],
  'lesson-8': ['lesson-7'],
  'lesson-9': ['lesson-8'],
  'lesson-10': ['lesson-9'],
  'lesson-11': ['lesson-10'],
  'lesson-12': ['lesson-9', 'lesson-11'],
};

export function computeReadinessDiagnostic(
  lessons: readonly LessonItem[],
  completedLessonIds: readonly string[],
  mistakes: readonly MistakeRecord[]
): ReadinessDiagnostic {
  const completedSet = new Set(completedLessonIds);
  const unresolvedByLesson = new Map<string, number>();

  for (const m of mistakes) {
    if (!m.resolved) {
      unresolvedByLesson.set(m.lessonId, (unresolvedByLesson.get(m.lessonId) ?? 0) + 1);
    }
  }

  const nodes: LessonMasteryNode[] = lessons.map((lesson) => {
    const unresolved = unresolvedByLesson.get(lesson.id) ?? 0;
    const isCompleted = completedSet.has(lesson.id);
    const status: LessonMasteryNode['status'] =
      unresolved > 0 ? 'needs-review' : isCompleted ? 'mastered' : 'in-progress';

    return {
      lessonId: lesson.id,
      lessonNumber: lesson.lessonNumber,
      unitId: lesson.unitId,
      title: lesson.title,
      status,
      unresolvedMistakes: unresolved,
      prerequisiteIds: PREREQUISITE_MAP[lesson.id] ?? [],
      keyTakeaway: lesson.coreIdea,
    };
  });

  const unitOrder: Array<{ unitId: UnitId; unitName: string }> = [
    { unitId: 'unit1', unitName: 'الباب الأول: الحساب الكيميائي' },
    { unitId: 'unit2', unitName: 'الباب الثاني: بنية الذرة' },
    { unitId: 'unit3', unitName: 'الباب الثالث: الجدول الدوري وتصنيف العناصر' },
  ];

  const byUnit = unitOrder.map(({ unitId, unitName }) => {
    const unitNodes = nodes.filter((n) => n.unitId === unitId);
    const completedCount = unitNodes.filter((n) => completedSet.has(n.lessonId)).length;
    const unresolvedMistakes = unitNodes.reduce((s, n) => s + n.unresolvedMistakes, 0);
    const basePct = unitNodes.length > 0 ? (completedCount / unitNodes.length) * 100 : 0;
    const penalty = Math.min(30, unresolvedMistakes * 8);
    const readinessPercent = Math.max(0, Math.round(basePct - penalty));

    return {
      unitId,
      unitName,
      completedCount,
      totalLessons: unitNodes.length,
      unresolvedMistakes,
      readinessPercent,
    };
  });

  const overallPercent =
    byUnit.length > 0
      ? Math.round(byUnit.reduce((sum, u) => sum + u.readinessPercent, 0) / byUnit.length)
      : 0;

  // Priority action: highest unresolved mistakes first, else first incomplete lesson
  const mostMissed = [...nodes]
    .filter((n) => n.unresolvedMistakes > 0)
    .sort((a, b) => b.unresolvedMistakes - a.unresolvedMistakes)[0];

  if (mostMissed) {
    return {
      overallPercent,
      byUnit,
      nodes,
      priorityAction: {
        title: `عالج أخطاء الدرس ${String(mostMissed.lessonNumber).padStart(2, '0')}: ${mostMissed.title}`,
        reason: `لديك ${mostMissed.unresolvedMistakes} سؤال قيد المراجعة في هذا الدرس؛ مراجعة فقرة الشرح ستثبّت الفهم فوراً.`,
        lessonId: mostMissed.lessonId,
        mode: 'mistakes',
      },
    };
  }

  const nextIncomplete = nodes.find((n) => n.status === 'in-progress') ?? nodes[0];
  return {
    overallPercent,
    byUnit,
    nodes,
    priorityAction: {
      title: `واصل دراسة الدرس ${String(nextIncomplete.lessonNumber).padStart(2, '0')}: ${nextIncomplete.title}`,
      reason: 'سجلك خالٍ من الأخطاء المعلّقة حالياً؛ تابع خطة المنهج بالترتيب لإتمام الأبواب الثلاثة.',
      lessonId: nextIncomplete.lessonId,
      mode: 'lesson',
    },
  };
}
