import test from 'node:test';
import assert from 'node:assert/strict';
import { ACADEMY_DATA } from '../data/academyData';

test('all 12 lessons are complete with axes, exam traps, focus points, and interactive practice checks', () => {
  const lessons = ACADEMY_DATA.lessons.items;
  assert.equal(lessons.length, 12);

  const unitCounts: Record<string, number> = {};
  for (const lesson of lessons) {
    unitCounts[lesson.unitId] = (unitCounts[lesson.unitId] || 0) + 1;
    assert.ok(lesson.coreIdea.length > 10, `${lesson.id} missing coreIdea`);
    assert.ok(lesson.curriculumImportance.length > 10, `${lesson.id} missing curriculumImportance`);
    assert.ok(lesson.sections.length >= 2, `${lesson.id} should have >= 2 sections`);
    assert.ok(lesson.examTraps.length >= 3, `${lesson.id} should have >= 3 examTraps`);
    assert.ok(lesson.focusPoints.length >= 3, `${lesson.id} should have >= 3 focusPoints`);
    assert.ok(lesson.practiceChecks.length >= 2, `${lesson.id} should have >= 2 practiceChecks`);
    assert.ok(
      lesson.practiceChecks.some((c) => c.kind === 'mcq'),
      `${lesson.id} should have at least one MCQ practice check`
    );
  }

  assert.deepEqual(unitCounts, { unit1: 4, unit2: 4, unit3: 4 });
});

test('all 93 final revision points across 12 lessons are intact inside Open Book', () => {
  const revisionLessons = ACADEMY_DATA.openBook.revisionLessons;
  assert.equal(revisionLessons.length, 12);
  const totalPoints = revisionLessons.reduce((sum, item) => sum + item.points.length, 0);
  assert.equal(totalPoints, 93);
  for (const rl of revisionLessons) {
    assert.ok(rl.points.length >= 5, `${rl.lessonId} should have >= 5 revision points`);
    for (const pt of rl.points) {
      assert.ok(pt.text.trim().length > 0, `Empty revision point in ${rl.lessonId}`);
    }
  }
});

test('complete question bank contains 798 valid MCQs + 762 worked essays = 1,560 questions (160 elite/deductive)', () => {
  const mcqs = ACADEMY_DATA.quiz.questions;
  const essays = ACADEMY_DATA.quiz.essayQuestions;
  const validLessonIds = new Set(ACADEMY_DATA.lessons.items.map((l) => l.id));

  assert.equal(mcqs.length, 798);
  assert.equal(essays.length, 762);
  assert.equal(mcqs.length + essays.length, 1560);

  for (const q of mcqs) {
    assert.equal(q.options.length, 4, `MCQ ${q.id} must have 4 options`);
    assert.ok(q.options.every((opt) => opt.trim().length > 0), `MCQ ${q.id} has empty option`);
    assert.ok(q.correctIndex >= 0 && q.correctIndex <= 3, `MCQ ${q.id} invalid correctIndex`);
    assert.ok(q.explanation.trim().length > 0, `MCQ ${q.id} missing explanation`);
    assert.ok(validLessonIds.has(q.lessonId), `MCQ ${q.id} invalid lessonId ${q.lessonId}`);
  }

  for (const e of essays) {
    assert.ok(e.question.trim().length > 0, `Essay ${e.id} missing question`);
    assert.ok(e.modelAnswer.trim().length > 0, `Essay ${e.id} missing modelAnswer`);
    assert.ok(validLessonIds.has(e.lessonId), `Essay ${e.id} invalid lessonId ${e.lessonId}`);
  }

  const eliteMcqs = mcqs.filter((q) => q.sourceTag !== 'بنك الدرس');
  const eliteEssays = essays.filter((e) => e.sourceTag !== 'بنك الدرس');
  assert.equal(eliteMcqs.length + eliteEssays.length, 160);
});

test('File 16 syllabus14 contains all 14 unified lessons mapped across the 3 units', () => {
  const { lessons } = ACADEMY_DATA.syllabus14;
  assert.equal(lessons.length, 14);

  const unitCounts: Record<string, number> = {};
  for (let i = 0; i < lessons.length; i++) {
    const lesson = lessons[i];
    assert.equal(lesson.number, i + 1);
    assert.ok(lesson.sections.length >= 1, `${lesson.id} must have >= 1 section`);
    unitCounts[lesson.unitId] = (unitCounts[lesson.unitId] || 0) + 1;
  }
  assert.deepEqual(unitCounts, { unit1: 5, unit2: 4, unit3: 5 });
});

test('File 17 Open Book contains 14 law cards, 6 Grade 2 constants, 21 atomic masses, 18 balanced equations, and zero Grade 3 constants', () => {
  const { entries, constants, atomicMasses, equations } = ACADEMY_DATA.openBook;
  assert.equal(entries.length, 14);
  assert.equal(constants.length, 6);
  assert.equal(atomicMasses.length, 21);
  assert.equal(equations.length, 18);

  const allConstText = constants.map((c) => `${c.label} ${c.value} ${c.detail}`).join(' ');
  assert.equal(allConstText.includes('96,500'), false, 'Faraday Grade 3 constant must not appear');
  assert.equal(allConstText.includes('0.0821'), false, 'Gas constant R must not appear');
});

test('File 18 Studio contains exactly 70 flashcards (5 cards per lesson across all 14 lessons)', () => {
  const { flashcards } = ACADEMY_DATA.studio;
  assert.equal(flashcards.length, 70);

  const perLesson: Record<number, number> = {};
  for (const fc of flashcards) {
    assert.ok(fc.front.trim().length > 0, `${fc.id} missing front`);
    assert.ok(fc.back.trim().length > 0, `${fc.id} missing back`);
    perLesson[fc.lessonNum] = (perLesson[fc.lessonNum] || 0) + 1;
  }

  for (let num = 1; num <= 14; num++) {
    assert.equal(perLesson[num], 5, `Lesson ${num} must have exactly 5 flashcards`);
  }
});
