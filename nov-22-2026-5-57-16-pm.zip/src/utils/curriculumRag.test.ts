import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  NOT_FOUND_LITERAL,
  STRICT_SYSTEM_PROMPT,
  buildLocalFallbackResponse,
  buildRagContextBlock,
  buildRevisionSchedule,
  generateLocalMcqJson,
  normalizeArabic,
  parseCurriculumKnowledge,
  searchCurriculumRag,
} from './curriculumRag';

const CURRICULUM_PATH = path.resolve(process.cwd(), 'public/curriculum_knowledge.txt');
const RAW_CURRICULUM = fs.readFileSync(CURRICULUM_PATH, 'utf8');
const PARSED = parseCurriculumKnowledge(RAW_CURRICULUM);

test('normalizeArabic normalizes Alef, Ta Marbuta, Ya, Tashkeel, and chemical subscripts', () => {
  assert.equal(normalizeArabic('أَثَرُ الإِشْعَاعِ الشَّمْسِيِّ عَلَى البِيئَةِ المَائِيَّةِ'), 'اثر الاشعاع الشمسي علي البييه الماييه');
  assert.equal(normalizeArabic('حمض الكبريتيك H₂SO₄ وغاز الأوزون O₃'), 'حمض الكبريتيك h2so4 وغاز الاوزون o3');
  assert.equal(normalizeArabic('أإآ ة ى'), 'ااا ه ي');
});

test('STRICT_SYSTEM_PROMPT includes exact literal refusal phrase', () => {
  assert.ok(STRICT_SYSTEM_PROMPT.includes(NOT_FOUND_LITERAL));
  assert.equal(NOT_FOUND_LITERAL, 'هذا السؤال غير موجود في المنهج المرفق حالياً');
});

test('parseCurriculumKnowledge parses full merged curriculum_knowledge.txt without omissions', () => {
  assert.ok(PARSED.rawLength > 300000, `Expected >300000 chars, got ${PARSED.rawLength}`);
  assert.ok(PARSED.lessons.length >= 11, `Expected >=11 lessons, got ${PARSED.lessons.length}`);
  assert.equal(PARSED.flashcards.length, 70, `Expected 70 flashcards, got ${PARSED.flashcards.length}`);
  assert.ok(
    PARSED.equationsAndLaws.length >= 12,
    `Expected >=12 equations/laws, got ${PARSED.equationsAndLaws.length}`
  );
  assert.ok(PARSED.mcqs.length >= 250, `Expected >=250 MCQs, got ${PARSED.mcqs.length}`);
  assert.ok(PARSED.chunks.length >= 400, `Expected >=400 chunks, got ${PARSED.chunks.length}`);
});

test('searchCurriculumRag finds accurate passages for in-curriculum queries', () => {
  const ozoneResult = searchCurriculumRag(PARSED, 'معادلة تكوين الأوزون في الستراتوسفير', { topK: 5 });
  assert.equal(ozoneResult.hasRelevantMatch, true);
  assert.ok(ozoneResult.hits.length > 0);
  const ozoneContext = buildRagContextBlock(ozoneResult.hits);
  assert.ok(
    ozoneContext.includes('O₃') || ozoneContext.includes('O3') || ozoneContext.includes('الأوزون'),
    'Expected ozone passage in RAG context'
  );

  const coResult = searchCurriculumRag(PARSED, 'لماذا يعد أول أكسيد الكربون CO قاتلاً صامتاً؟', { topK: 5 });
  assert.equal(coResult.hasRelevantMatch, true);
  assert.ok(coResult.hits.some((h) => h.chunk.lessonCode === '12' || h.chunk.text.includes('الهيموجلوبين')));
});

test('searchCurriculumRag strictly rejects out-of-curriculum queries with literal refusal', () => {
  const offTopic = searchCurriculumRag(PARSED, 'طريقة عمل بيتزا مارجريتا الإيطالية بالجبن الموتزاريلا والريحان', {
    topK: 5,
  });
  assert.equal(offTopic.hasRelevantMatch, false);
  assert.equal(offTopic.hits.length, 0);

  const fallback = buildLocalFallbackResponse('طريقة عمل بيتزا مارجريتا', offTopic);
  assert.ok(fallback.includes(NOT_FOUND_LITERAL));
});

test('buildRevisionSchedule distributes lessons cleanly across requested days', () => {
  const plan = buildRevisionSchedule(PARSED.lessons, 7, 2.5, 'balanced');
  assert.equal(plan.length, 7);
  assert.equal(plan[0].day, 1);
  assert.equal(plan[6].day, 7);
  assert.ok(plan[6].title.includes('المراجعة النهائية'));
  assert.ok(plan.every((d) => d.estimatedHours === 2.5 && d.tasks.length >= 3));
});

test('generateLocalMcqJson produces valid schema matching curriculum style', () => {
  const mcqs = generateLocalMcqJson(PARSED, { lessonCode: '12', count: 5, difficulty: 'الكل' });
  assert.equal(mcqs.length, 5);
  for (const item of mcqs) {
    assert.ok(item.id.startsWith('Q_'));
    assert.ok(item.question.length > 5);
    assert.ok(['a', 'b', 'c', 'd'].includes(item.correctAnswer));
    assert.ok(item.options.a.length > 0);
    assert.ok(item.options.b.length > 0);
  }
});
