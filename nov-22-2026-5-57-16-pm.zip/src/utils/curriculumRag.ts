export const STRICT_SYSTEM_PROMPT =
  'أنت مساعد تعليمي متخصص. لا تعلم ولا تجب إلا مما تم إطلاقه وإرفاقه لك في ملف التفكير/المنهج المدمج فقط، وبنفس دقة أرقامه وقوانينه ومعادلاته ومفاهيمه. ممنوع نهائياً الإجابة من معلومات خارجية أو تخمين خارج النص المرفق. إذا لم تجد الإجابة في النص المرفق، اعتذر بلطف وقل حرفياً: (هذا السؤال غير موجود في المنهج المرفق حالياً).';

export const NOT_FOUND_LITERAL = 'هذا السؤال غير موجود في المنهج المرفق حالياً';

export type CurriculumChunkKind =
  | 'explanation'
  | 'mcq'
  | 'essay'
  | 'flashcard'
  | 'law'
  | 'equation'
  | 'table'
  | 'simulator'
  | 'general';

export interface CurriculumChunk {
  id: string;
  sourceTitle: string;
  lessonCode: string;
  kind: CurriculumChunkKind;
  text: string;
  normalizedText: string;
  tokens: string[];
  tokenSet: Set<string>;
}

export interface ParsedCurriculumLesson {
  code: string;
  title: string;
  unit: string;
  summary: string;
  chunkCount: number;
}

export interface ParsedFlashcard {
  id: string;
  cardNumber: number;
  lessonCode: string;
  lessonLabel: string;
  front: string;
  back: string;
}

export interface ParsedEquationOrLaw {
  id: string;
  category: 'equation' | 'law';
  title: string;
  lessonCode: string;
  lessonLabel: string;
  formulaRaw: string;
  katexExpression: string;
  details: string[];
  steps: string[];
  calculatorId?: 'water-pressure' | 'temp-convert' | 'troposphere-temp' | 'heat-quantity' | 'pressure-convert';
}

export interface ParsedMcqQuestion {
  id: string;
  lessonCode: string;
  lessonLabel: string;
  difficulty: 'أساسي' | 'متوسط' | 'متفوقين';
  question: string;
  options: { key: string; text: string }[];
  correctKey: string;
  correctIndex: number;
  explanation: string;
}

export interface ParsedCurriculumKnowledge {
  rawLength: number;
  chunks: CurriculumChunk[];
  lessons: ParsedCurriculumLesson[];
  flashcards: ParsedFlashcard[];
  equationsAndLaws: ParsedEquationOrLaw[];
  mcqs: ParsedMcqQuestion[];
  docFreq: Map<string, number>;
}

export interface RagHit {
  chunk: CurriculumChunk;
  score: number;
  matchedTerms: string[];
}

export interface RagSearchResult {
  query: string;
  normalizedQuery: string;
  hits: RagHit[];
  bestScore: number;
  hasRelevantMatch: boolean;
}

export interface RevisionDayPlan {
  day: number;
  title: string;
  lessons: { code: string; title: string }[];
  tasks: string[];
  estimatedHours: number;
}

const ARABIC_STOP_WORDS = new Set([
  'في', 'من', 'الي', 'علي', 'عن', 'مع', 'او', 'و', 'ان', 'انها', 'انه', 'التي', 'الذي',
  'التي', 'الذين', 'ما', 'ماذا', 'كيف', 'لماذا', 'متي', 'اين', 'هل', 'لا', 'لم', 'لن',
  'قد', 'كل', 'بعض', 'هذا', 'هذه', 'ذلك', 'تلك', 'هو', 'هي', 'هم', 'هن', 'نحن', 'انا',
  'انت', 'كان', 'كانت', 'يكون', 'تكون', 'بين', 'عند', 'حتي', 'منذ', 'خلال', 'حول', 'ضد',
  'نحو', 'فوق', 'تحت', 'امام', 'خلف', 'بسبب', 'عبر', 'لديه', 'لدي', 'له', 'لها', 'لهم',
  'فيه', 'فيها', 'منه', 'منها', 'عليه', 'عليها', 'اليه', 'اليها', 'كما', 'ايضا', 'فقط',
  'جدا', 'اكثر', 'اقل', 'شرح', 'اشرح', 'لي', 'لخص', 'هات', 'اعطني', 'اريد', 'سوال', 'اساله',
  'الدرس', 'درس', 'المنهج', 'المرفق', 'بشكل', 'مختصر', 'تفصيل', 'بالتفصيل', 'عن', 'معني',
  'ماهي', 'ماهو', 'اذكر', 'وضح', 'فسر', 'علل', 'قارن', 'اهم', 'طريقه', 'عمل', 'كيفيه',
  'افضل', 'احسن', 'ممكن', 'سمحت', 'قولي', 'كلمني', 'يعني', 'ايه', 'ازاي',
]);

const SUBSCRIPT_MAP: Record<string, string> = {
  '₀': '0', '₁': '1', '₂': '2', '₃': '3', '₄': '4',
  '₅': '5', '₆': '6', '₇': '7', '₈': '8', '₉': '9',
  '⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4',
  '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9',
  '⁺': '+', '⁻': '-', '٠': '0', '١': '1', '٢': '2',
  '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
};

/**
 * Arabic & scientific text normalizer for Local RAG:
 * - أ/إ/آ/ٱ -> ا
 * - ة -> ه
 * - ى -> ي
 * - ؤ -> و, ئ -> ي
 * - Removes Arabic diacritics (Tashkeel) and Tatweel
 * - Normalizes Arabic-Indic digits & chemical subscripts/superscripts to ASCII
 */
export function normalizeArabic(input: string): string {
  if (!input) return '';
  let out = input
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/[₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻٠١٢٣٤٥٦٧٨٩]/g, (ch) => SUBSCRIPT_MAP[ch] ?? ch)
    .toLowerCase();

  out = out.replace(/[^\u0621-\u064Aa-z0-9\s%°/+.-]/g, ' ');
  return out.replace(/\s+/g, ' ').trim();
}

function stemArabicWord(word: string): string {
  let w = word;
  if (w.length > 4 && (w.startsWith('وال') || w.startsWith('بال') || w.startsWith('كال') || w.startsWith('فال') || w.startsWith('لل'))) {
    w = w.slice(w.startsWith('لل') ? 2 : 3);
  } else if (w.length > 3 && w.startsWith('ال')) {
    w = w.slice(2);
  } else if (w.length > 4 && (w.startsWith('و') || w.startsWith('ب') || w.startsWith('ف') || w.startsWith('ل'))) {
    w = w.slice(1);
  }
  return w;
}

export function tokenizeArabic(input: string): string[] {
  const norm = normalizeArabic(input);
  if (!norm) return [];
  const rawTokens = norm.split(' ').filter(Boolean);
  const tokens: string[] = [];
  for (const raw of rawTokens) {
    const clean = raw.replace(/^[./+-]+|[./+-]+$/g, '');
    if (!clean) continue;
    // Keep chemical/scientific short symbols like o2, o3, co, uv, ph, co2, n2, h2o
    const isSci = /^[a-z]+[0-9]*[+-]?$/.test(clean) && clean.length >= 2;
    const isNum = /^\d+(\.\d+)?%?$/.test(clean);
    if (!isSci && !isNum && clean.length < 2) continue;
    if (ARABIC_STOP_WORDS.has(clean)) continue;
    tokens.push(clean);
    if (!isSci && !isNum && /[\u0621-\u064A]/.test(clean)) {
      const stemmed = stemArabicWord(clean);
      if (stemmed.length >= 2 && stemmed !== clean && !ARABIC_STOP_WORDS.has(stemmed)) {
        tokens.push(stemmed);
      }
    }
  }
  return tokens;
}

function detectLessonCodeAndTitle(block: string): { code: string; title: string; unit: string } {
  const lessonMatch = block.match(/الدرس\s*0?(\d{1,2})\s*(?:\([^)]+\))?\s*[:\-–]\s*([^\n\r]+)/);
  if (lessonMatch) {
    const code = lessonMatch[1].padStart(2, '0');
    const title = `الدرس ${code}: ${lessonMatch[2].trim()}`;
    const num = Number(code);
    const unit = num >= 11 ? 'الوحدة الثانية: الغلاف الجوي' : 'الوحدة الأولى: النظام البيئي المائي';
    return { code, title, unit };
  }
  const fileMatch = block.match(/العنوان\s*:\s*ملف\s*(\d{1,2})\s*[-–:]\s*([^\n\r]+)/);
  if (fileMatch) {
    const code = fileMatch[1].padStart(2, '0');
    const title = `ملف ${code}: ${fileMatch[2].trim()}`;
    return { code, title, unit: 'مراجع وبنوك إضافية' };
  }
  const firstLine = block
    .split(/\r?\n/)
    .map((l) => l.trim())
    .find((l) => l.length > 4 && !/^[=\-_]+$/.test(l));
  return {
    code: '00',
    title: firstLine ? firstLine.slice(0, 90) : 'محتوى المنهج المرفق',
    unit: 'المنهج المرفق',
  };
}

function splitDocumentSections(rawText: string): Array<{ header: string; body: string }> {
  // Split at major document headers starting with ===== followed by الموجه في المنصة or منصة العلوم
  const lines = rawText.replace(/\r\n/g, '\n').split('\n');
  const docs: string[] = [];
  let current: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const nextLine = lines[i + 1] ?? '';
    const isDocBoundary =
      /^={20,}\s*$/.test(line) &&
      (/الموجه في المنصة|منصة العلوم المتكاملة/.test(nextLine)) &&
      current.length > 15;
    if (isDocBoundary) {
      docs.push(current.join('\n'));
      current = [line];
    } else {
      current.push(line);
    }
  }
  if (current.length > 0) {
    docs.push(current.join('\n'));
  }
  return docs.map((d) => ({ header: d.slice(0, 600), body: d }));
}

function convertFormulaToKatex(formula: string, isChemical: boolean): string {
  const cleaned = formula
    .trim()
    .replace(/←/g, '\\rightarrow ')
    .replace(/→/g, '\\rightarrow ')
    .replace(/⇌/g, '\\rightleftharpoons ')
    .replace(/⇄/g, '\\rightleftharpoons ')
    .replace(/↑/g, '\\uparrow ')
    .replace(/↓/g, '\\downarrow ')
    .replace(/×/g, ' \\times ')
    .replace(/≈/g, ' \\approx ')
    .replace(/≥/g, ' \\ge ')
    .replace(/≤/g, ' \\le ')
    .replace(/°C/g, '^\\circ\\text{C}')
    .replace(/°F/g, '^\\circ\\text{F}')
    .replace(/Δ/g, '\\Delta ')
    .replace(/ρ/g, '\\rho ')
    .replace(/_([A-Za-z]{2,})/g, '_{\\text{$1}}')
    .replace(/\([^)]*[\u0621-\u064A][^)]*\)/g, '')
    .trim();

  if (isChemical) {
    // Convert unicode sub/superscripts back for mhchem \ce{...}
    const mh = formula
      .trim()
      .replace(/\([^)]*[\u0621-\u064A][^)]*\)/g, '')
      .replace(/[₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]/g, (ch) => {
        const mapped = SUBSCRIPT_MAP[ch] ?? ch;
        if ('⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻'.includes(ch)) return `^${mapped}`;
        return mapped;
      })
      .replace(/⇌/g, '<=>')
      .replace(/→|←/g, '->')
      .replace(/↑/g, '^')
      .replace(/--\(ضوء الشمس \/ كلوروفيل\)-->/g, '->[\\text{Sunlight / Chlorophyll}]')
      .replace(/UV\s*\(<\s*240\s*nm\)/gi, '\\text{UV (< 240 nm)}')
      .trim();
    return `\\ce{${mh}}`;
  }
  return cleaned;
}

function parseFlashcardsFromText(rawText: string): ParsedFlashcard[] {
  const cards: ParsedFlashcard[] = [];
  const regex =
    /\[بطاقة\s*(\d+)\s*\|\s*([^\]]+)\]\s*\n\s*الوجه الأمامي\s*:\s*([^\n]+)\s*\n\s*الوجه الخلفي\s*:\s*([^\n=]+)/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(rawText)) !== null) {
    const num = Number(match[1]);
    const label = match[2].trim();
    const codeMatch = label.match(/0?(\d{1,2})/);
    const lessonCode = codeMatch ? codeMatch[1].padStart(2, '0') : '00';
    cards.push({
      id: `fc-${num}`,
      cardNumber: num,
      lessonCode,
      lessonLabel: label,
      front: match[3].trim(),
      back: match[4].trim(),
    });
  }
  return cards;
}

function parseMcqsFromDoc(docBody: string, lessonCode: string, lessonLabel: string): ParsedMcqQuestion[] {
  const results: ParsedMcqQuestion[] = [];
  const blocks = docBody.split(/\n={20,}\n/);
  const isAdvancedFile = lessonCode === '15';

  for (const block of blocks) {
    const trimmed = block.trim();
    if (!trimmed.includes('الإجابة الصحيحة:')) continue;
    const lines = trimmed.split('\n').map((l) => l.trim()).filter(Boolean);
    const qLineIdx = lines.findIndex((l) => /^\d+[\-.)]\s+/.test(l));
    if (qLineIdx === -1) continue;

    const qText = lines[qLineIdx].replace(/^\d+[\-.)]\s+/, '').trim();
    const options: { key: string; text: string }[] = [];
    let answerLine = '';
    for (let i = qLineIdx + 1; i < lines.length; i++) {
      const line = lines[i];
      const optMatch = line.match(/^([أبجد])[\-.)]\s*(.+)$/);
      if (optMatch) {
        options.push({ key: optMatch[1], text: optMatch[2].trim() });
      } else if (line.startsWith('الإجابة الصحيحة:')) {
        answerLine = line;
      }
    }
    if (options.length < 3 || !answerLine) continue;

    const ansMatch = answerLine.match(/الإجابة الصحيحة:\s*([أبجد])/);
    if (!ansMatch) continue;
    const correctKey = ansMatch[1];
    const correctIndex = options.findIndex((o) => o.key === correctKey);
    if (correctIndex === -1) continue;

    const explMatch = answerLine.match(/التعليل:\s*(.+)$/);
    const explanation = explMatch ? explMatch[1].trim() : answerLine.replace('الإجابة الصحيحة:', '').trim();

    // If inside IS_15, extract referenced lesson code like (الدرس 09 - ...)
    let effectiveCode = lessonCode;
    let effectiveLabel = lessonLabel;
    if (isAdvancedFile) {
      const refLesson = qText.match(/^\(الدرس\s*0?(\d{1,2})\s*[-–]\s*([^)]+)\)/);
      if (refLesson) {
        effectiveCode = refLesson[1].padStart(2, '0');
        effectiveLabel = `الدرس ${effectiveCode}: ${refLesson[2].trim()}`;
      }
    }

    results.push({
      id: `mcq-${lessonCode}-${results.length + 1}`,
      lessonCode: effectiveCode,
      lessonLabel: effectiveLabel,
      difficulty: isAdvancedFile ? 'متفوقين' : results.length < 10 ? 'أساسي' : 'متوسط',
      question: qText,
      options,
      correctKey,
      correctIndex,
      explanation,
    });
  }
  return results;
}

function parseEquationsAndLaws(rawText: string): ParsedEquationOrLaw[] {
  const items: ParsedEquationOrLaw[] = [];
  const seen = new Set<string>();

  // 1) Parse structured [قانون X - ...] blocks (IS_16)
  const lawRegex = /\[قانون\s*(\d+)\s*[-–]\s*([^\]]+)\]([\s\S]*?)(?=\n\[قانون|\n={20,}|$)/g;
  let lawMatch: RegExpExecArray | null;
  while ((lawMatch = lawRegex.exec(rawText)) !== null) {
    const num = lawMatch[1];
    const titleRaw = lawMatch[2].trim();
    const body = lawMatch[3].trim();
    const lines = body.split('\n').map((l) => l.trim()).filter(Boolean);
    const lessonMatch = titleRaw.match(/الدرس\s*0?(\d{1,2})/);
    const lessonCode = lessonMatch ? lessonMatch[1].padStart(2, '0') : '16';
    const formulaLines = lines.filter((l) => /[=<>≤≥]/.test(l) && !l.startsWith('- الدلالات'));
    const primaryFormula = (formulaLines[0] || lines[0] || '')
      .replace(/^-\s*(الصيغة|القوة الضاغطة|من سيليزي إلى كلفن)\s*:\s*/, '')
      .trim();

    let calculatorId: ParsedEquationOrLaw['calculatorId'];
    if (num === '2') calculatorId = 'heat-quantity';
    else if (num === '3') calculatorId = 'water-pressure';
    else if (num === '4') calculatorId = 'troposphere-temp';
    else if (num === '6') calculatorId = 'temp-convert';
    else if (num === '7') calculatorId = 'pressure-convert';

    const key = `law-${num}`;
    if (!seen.has(key)) {
      seen.add(key);
      items.push({
        id: key,
        category: 'law',
        title: `قانون ${num}: ${titleRaw}`,
        lessonCode,
        lessonLabel: lessonMatch ? `الدرس ${lessonCode}` : 'مرجع الكتاب المفتوح',
        formulaRaw: primaryFormula,
        katexExpression: convertFormulaToKatex(
          primaryFormula.replace(/\([^)]*[\u0621-\u064A][^)]*\)/g, '').trim(),
          false
        ),
        details: lines,
        steps: [
          'حدّد المعطيات بدقة وتأكد من توحيد وحدات القياس وفق ثوابت المنهج.',
          `طبّق العلاقة الرياضية: ${primaryFormula}`,
          'راجع الوحدة النهائية للناتج وقارنها بالنقاط المرجعية الواردة في الدرس.',
        ],
        calculatorId,
      });
    }
  }

  // 2) Parse balanced chemical equations section in IS_16 + photosynthesis equation in IS_07
  const eqSectionMatch = rawText.match(/ثالثاً:\s*جميع المعادلات الكيميائية الموزونة في المنهج([\s\S]*?)(?=\n={20,}\nرابعاً:|$)/);
  if (eqSectionMatch) {
    const eqBlock = eqSectionMatch[1];
    const eqItems = eqBlock.split(/\n(?=\d+\)\s)/).map((s) => s.trim()).filter(Boolean);
    for (const part of eqItems) {
      const lines = part.split('\n').map((l) => l.trim()).filter(Boolean);
      if (lines.length < 2) continue;
      const heading = lines[0].replace(/^\d+\)\s*/, '').replace(/:$/, '').trim();
      const lessonMatch = heading.match(/الدرس\s*0?(\d{1,2})/);
      const lessonCode = lessonMatch ? lessonMatch[1].padStart(2, '0') : '16';
      const eqLines = lines.slice(1);

      eqLines.forEach((line, idx) => {
        const cleanEq = line.replace(/^-\s*[^:]+:\s*/, '').trim();
        if (!/[→⇌]|->/.test(cleanEq)) return;
        const subLabel = line.startsWith('-') ? line.split(':')[0].replace(/^-\s*/, '').trim() : '';
        const id = `eq-${items.length + 1}-${idx}`;
        const key = normalizeArabic(cleanEq);
        if (seen.has(key)) return;
        seen.add(key);

        const parts = cleanEq.split(/→|⇌|->/);
        const reactants = (parts[0] || '').trim();
        const products = (parts[1] || '').trim();

        items.push({
          id,
          category: 'equation',
          title: subLabel ? `${heading} — ${subLabel}` : heading,
          lessonCode,
          lessonLabel: lessonMatch ? `الدرس ${lessonCode}` : 'معادلات المنهج',
          formulaRaw: cleanEq,
          katexExpression: convertFormulaToKatex(cleanEq, true),
          details: [
            `المتفاعلات: ${reactants}`,
            `النواتج: ${products}`,
            cleanEq.includes('⇌')
              ? 'نوع السهم: تفاعل انعكاسي متزن (يسير في الاتجاهين الطردي والعكسي).'
              : 'نوع السهم: تفاعل تام في اتجاه تكوين النواتج.',
          ],
          steps: [
            `تحديد المواد المتفاعلة وحالتها الفيزيائية: ${reactants}`,
            `تحديد النواتج المتكونة من التفاعل: ${products}`,
            'التحقق من قانون بقاء الكتلة وتساوي عدد ذرات كل عنصر في طرفي المعادلة الموزونة.',
          ],
        });
      });
    }
  }

  // Also capture photosynthesis equation from IS_07 if present
  const photoMatch = rawText.match(/6CO₂\s*\+\s*12H₂O[^\n]+O₂↑?/);
  if (photoMatch) {
    const eq = photoMatch[0].trim();
    const key = normalizeArabic(eq);
    if (!seen.has(key)) {
      seen.add(key);
      items.push({
        id: 'eq-photosynthesis',
        category: 'equation',
        title: 'معادلة البناء الضوئي في النباتات والطحالب المائية (الدرس 07)',
        lessonCode: '07',
        lessonLabel: 'الدرس 07',
        formulaRaw: eq,
        katexExpression: '\\ce{6CO2 + 12H2O ->[\\text{ضوء الشمس / كلوروفيل}] C6H12O6 + 6H2O + 6O2^}',
        details: [
          'المتفاعلات: 6 جزيئات ثاني أكسيد الكربون + 12 جزيء ماء في وجود ضوء الشمس والكلوروفيل.',
          'النواتج: جزيء جلوكوز + 6 جزيئات ماء + 6 جزيئات أكسجين متصاعدة.',
          'المصدر الحيوي الرئيسي لغاز الأكسجين المذاب في البيئات المائية.',
        ],
        steps: [
          'تمتص النباتات المائية والطحالب غاز CO₂ بخاصية الانتشار.',
          'تُستخدم طاقة الضوء والكلوروفيل لبناء سكر الجلوكوز (C₆H₁₂O₆).',
          'يتصاعد 6 مول من غاز O₂ مقابل كل 1 مول جلوكوز متكون.',
        ],
      });
    }
  }

  // If user uploaded a completely custom curriculum without IS_16 markers, auto-extract any lines with → / ⇌ / =
  if (items.length === 0) {
    const lines = rawText.split(/\r?\n/).map((l) => l.trim());
    for (const line of lines) {
      if (items.length >= 20) break;
      if (line.length > 8 && line.length < 140 && /[→⇌]/.test(line)) {
        const key = normalizeArabic(line);
        if (seen.has(key)) continue;
        seen.add(key);
        items.push({
          id: `custom-eq-${items.length + 1}`,
          category: 'equation',
          title: `معادلة ${items.length + 1} من المنهج المرفق`,
          lessonCode: '00',
          lessonLabel: 'الملف المرفق',
          formulaRaw: line,
          katexExpression: convertFormulaToKatex(line, true),
          details: [line],
          steps: ['مراجعة المتفاعلات والنواتج ووزن الذرات في طرفي المعادلة كما وردت في النص المرفق.'],
        });
      }
    }
  }

  return items;
}

export function parseCurriculumKnowledge(rawText: string): ParsedCurriculumKnowledge {
  const safeText = (rawText || '').replace(/^\uFEFF/, '').trim();
  const docs = splitDocumentSections(safeText);
  const chunks: CurriculumChunk[] = [];
  const lessonMap = new Map<string, ParsedCurriculumLesson>();
  const mcqs: ParsedMcqQuestion[] = [];
  const docFreq = new Map<string, number>();

  for (let dIdx = 0; dIdx < docs.length; dIdx++) {
    const doc = docs[dIdx];
    const meta = detectLessonCodeAndTitle(doc.header);

    const parsedDocMcqs = parseMcqsFromDoc(doc.body, meta.code, meta.title);
    mcqs.push(...parsedDocMcqs);

    // Split each document into semantic blocks using ===== separators or blank-line paragraphs
    const rawBlocks = doc.body
      .split(/\n={20,}\n|\n-{20,}\n/)
      .map((b) => b.trim())
      .filter((b) => b.length >= 25);

    let subChunkCount = 0;

    for (const block of rawBlocks) {
      // Skip pure title banners
      if (/^(الموجه في المنصة|منصة العلوم المتكاملة)/.test(block) && block.length < 360) {
        continue;
      }

      // Further subdivide large explanation blocks by double newlines into ~450-950 char chunks
      const subParts: string[] = [];
      if (block.length <= 1050) {
        subParts.push(block);
      } else {
        const paras = block.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
        let acc = '';
        for (const p of paras) {
          if (acc && acc.length + p.length > 950) {
            subParts.push(acc);
            acc = p;
          } else {
            acc = acc ? `${acc}\n\n${p}` : p;
          }
        }
        if (acc) subParts.push(acc);
      }

      for (const part of subParts) {
        if (part.length < 20) continue;
        let kind: CurriculumChunkKind = 'explanation';
        if (part.includes('الوجه الأمامي:')) kind = 'flashcard';
        else if (part.includes('الإجابة الصحيحة:')) kind = 'mcq';
        else if (part.includes('الإجابة النموذجية:')) kind = 'essay';
        else if (part.startsWith('[قانون')) kind = 'law';
        else if (part.startsWith('[محاكي')) kind = 'simulator';
        else if (/^جدول\s*\d+/.test(part)) kind = 'table';
        else if (/[→⇌]/.test(part) && part.length < 400) kind = 'equation';

        const normalizedText = normalizeArabic(`${meta.title} ${part}`);
        const tokens = tokenizeArabic(`${meta.title} ${part}`);
        const tokenSet = new Set(tokens);
        for (const t of tokenSet) {
          docFreq.set(t, (docFreq.get(t) ?? 0) + 1);
        }

        chunks.push({
          id: `chk-${dIdx}-${chunks.length}`,
          sourceTitle: meta.title,
          lessonCode: meta.code,
          kind,
          text: part,
          normalizedText,
          tokens,
          tokenSet,
        });
        subChunkCount++;
      }
    }

    if (meta.code !== '00' && subChunkCount > 0) {
      const existing = lessonMap.get(meta.code);
      if (!existing) {
        const firstExpl = chunks.find((c) => c.lessonCode === meta.code && c.kind === 'explanation');
        lessonMap.set(meta.code, {
          code: meta.code,
          title: meta.title,
          unit: meta.unit,
          summary: firstExpl ? firstExpl.text.slice(0, 180).replace(/\n/g, ' ') + '...' : meta.title,
          chunkCount: subChunkCount,
        });
      } else {
        existing.chunkCount += subChunkCount;
      }
    }
  }

  let flashcards = parseFlashcardsFromText(safeText);
  // If user uploaded a custom text without [بطاقة] markers, build flashcards from essays/MCQs
  if (flashcards.length === 0) {
    const qaChunks = chunks.filter((c) => c.kind === 'essay' || c.kind === 'mcq').slice(0, 40);
    flashcards = qaChunks.map((c, idx) => {
      const parts = c.text.split(/الإجابة النموذجية:|الإجابة الصحيحة:/);
      return {
        id: `auto-fc-${idx + 1}`,
        cardNumber: idx + 1,
        lessonCode: c.lessonCode,
        lessonLabel: c.sourceTitle,
        front: (parts[0] || c.text).trim().slice(0, 220),
        back: (parts[1] || c.text).trim().slice(0, 320),
      };
    });
  }

  const equationsAndLaws = parseEquationsAndLaws(safeText);
  const lessons = Array.from(lessonMap.values()).sort((a, b) => Number(a.code) - Number(b.code));

  return {
    rawLength: safeText.length,
    chunks,
    lessons,
    flashcards,
    equationsAndLaws,
    mcqs,
    docFreq,
  };
}

export function searchCurriculumRag(
  index: ParsedCurriculumKnowledge,
  query: string,
  options: {
    lessonCode?: string;
    topK?: number;
    preferKinds?: CurriculumChunkKind[];
  } = {}
): RagSearchResult {
  const { lessonCode, topK = 6, preferKinds } = options;
  const normalizedQuery = normalizeArabic(query);
  const queryTokens = Array.from(new Set(tokenizeArabic(query)));
  const totalDocs = Math.max(index.chunks.length, 1);

  // Detect explicit lesson number in query like "درس 12" or "الدرس 9"
  const explicitLessonMatch = normalizedQuery.match(/درس\s*0?(\d{1,2})\b/);
  const targetLesson = lessonCode && lessonCode !== 'all' ? lessonCode : explicitLessonMatch?.[1]?.padStart(2, '0');

  // If user clicked a quick chip with a selected lesson and few content tokens, return top chunks of that lesson
  if (queryTokens.length === 0 && targetLesson) {
    const lessonChunks = index.chunks
      .filter((c) => c.lessonCode === targetLesson)
      .sort((a, b) => {
        const aPref = preferKinds?.includes(a.kind) ? 1 : 0;
        const bPref = preferKinds?.includes(b.kind) ? 1 : 0;
        return bPref - aPref;
      })
      .slice(0, topK)
      .map((chunk) => ({ chunk, score: 10, matchedTerms: [`الدرس ${targetLesson}`] }));
    return {
      query,
      normalizedQuery,
      hits: lessonChunks,
      bestScore: lessonChunks.length > 0 ? 10 : 0,
      hasRelevantMatch: lessonChunks.length > 0,
    };
  }

  if (queryTokens.length === 0) {
    return {
      query,
      normalizedQuery,
      hits: [],
      bestScore: 0,
      hasRelevantMatch: false,
    };
  }

  const scored: RagHit[] = [];

  for (const chunk of index.chunks) {
    if (lessonCode && lessonCode !== 'all' && chunk.lessonCode !== lessonCode) {
      continue;
    }

    let score = 0;
    const matchedTerms: string[] = [];

    for (const qt of queryTokens) {
      if (chunk.tokenSet.has(qt)) {
        const df = index.docFreq.get(qt) ?? 1;
        const idf = Math.log((totalDocs + 1) / (df + 0.5)) + 1;
        // Count frequency in chunk (capped)
        let tf = 0;
        for (const t of chunk.tokens) {
          if (t === qt) tf++;
        }
        const tfWeight = 1 + Math.log(Math.min(tf, 6));
        const sciBoost = /^[a-z]+[0-9]*[+-]?$/.test(qt) ? 1.45 : 1;
        score += idf * tfWeight * sciBoost;
        matchedTerms.push(qt);
      } else if (qt.length >= 4 && chunk.normalizedText.includes(qt)) {
        // Substring match for Arabic plural/conjugation variants
        const df = index.docFreq.get(qt) ?? 2;
        const idf = Math.log((totalDocs + 1) / (df + 1)) + 0.5;
        score += idf * 0.72;
        matchedTerms.push(qt);
      }
    }

    if (score <= 0) continue;

    // Coverage ratio bonus (reward chunks matching a higher fraction of query terms)
    const uniqueMatched = new Set(matchedTerms).size;
    const coverage = uniqueMatched / Math.max(queryTokens.length, 1);
    score *= 0.75 + coverage * 1.15;

    // Exact phrase match bonus
    if (normalizedQuery.length >= 6 && chunk.normalizedText.includes(normalizedQuery)) {
      score += 5.5;
    }

    // Lesson hint match bonus
    if (targetLesson && chunk.lessonCode === targetLesson) {
      score += 4.0;
    }

    // Preferred chunk kind bonus (e.g., explanations for "اشرح", equations/laws for "لخص المعادلات")
    if (preferKinds && preferKinds.includes(chunk.kind)) {
      score *= 1.28;
    } else if (chunk.kind === 'explanation' || chunk.kind === 'law' || chunk.kind === 'equation') {
      score *= 1.08;
    }

    scored.push({ chunk, score, matchedTerms: Array.from(new Set(matchedTerms)) });
  }

  scored.sort((a, b) => b.score - a.score);
  const topHits = scored.slice(0, topK);
  const bestScore = topHits[0]?.score ?? 0;

  // Minimum relevance gate: require meaningful term coverage + score to prevent false hits on out-of-curriculum topics
  const topMatchedCount = topHits[0]?.matchedTerms.length ?? 0;
  const topCoverage = topMatchedCount / Math.max(queryTokens.length, 1);
  const exactPhraseMatched =
    topHits.length > 0 &&
    normalizedQuery.length >= 6 &&
    topHits[0].chunk.normalizedText.includes(normalizedQuery);
  const hasRelevantMatch =
    topHits.length > 0 &&
    (exactPhraseMatched ||
      (queryTokens.length === 1 && bestScore >= 2.4 && topMatchedCount >= 1) ||
      (queryTokens.length === 2 && bestScore >= 2.8 && topMatchedCount >= 1) ||
      (queryTokens.length >= 3 && queryTokens.length <= 5 && bestScore >= 4.0 && topMatchedCount >= 2) ||
      (queryTokens.length > 5 && bestScore >= 4.6 && topMatchedCount >= 2 && topCoverage >= 0.28));

  return {
    query,
    normalizedQuery,
    hits: hasRelevantMatch ? topHits : [],
    bestScore,
    hasRelevantMatch,
  };
}

export function buildRagContextBlock(hits: RagHit[], maxChars = 6500): string {
  let out = '';
  for (let i = 0; i < hits.length; i++) {
    const h = hits[i].chunk;
    const entry = `--- [مقطع ${i + 1} | المصدر: ${h.sourceTitle}] ---\n${h.text}\n\n`;
    if (out.length + entry.length > maxChars) break;
    out += entry;
  }
  return out.trim();
}

export function buildLocalFallbackResponse(
  query: string,
  result: RagSearchResult,
  reasonNote?: string
): string {
  if (!result.hasRelevantMatch || result.hits.length === 0) {
    return `نعتذر، ${NOT_FOUND_LITERAL}.`;
  }

  const header = reasonNote
    ? `**تم استخراج الإجابة مباشرة من ملف المنهج المرفق** (${reasonNote}):\n\n`
    : `**نتائج مطابقة من ملف المنهج المرفق لسؤالك:** "${query}"\n\n`;

  const body = result.hits
    .slice(0, 4)
    .map((hit, idx) => {
      const cleanText = hit.chunk.text.trim();
      return `### ${idx + 1}. ${hit.chunk.sourceTitle}\n${cleanText}`;
    })
    .join('\n\n---\n\n');

  return `${header}${body}`;
}

export function buildRevisionSchedule(
  lessons: ParsedCurriculumLesson[],
  daysCount: number,
  hoursPerDay: number,
  focusMode: 'balanced' | 'fast' | 'advanced'
): RevisionDayPlan[] {
  const safeDays = Math.max(1, Math.min(30, Math.round(daysCount)));
  const safeHours = Math.max(1, Math.min(12, Number(hoursPerDay) || 2));
  const coreLessons = lessons.filter((l) => Number(l.code) >= 1 && Number(l.code) <= 14);
  const pool = coreLessons.length > 0 ? coreLessons : lessons;

  if (pool.length === 0) {
    return [
      {
        day: 1,
        title: 'اليوم 1 — مراجعة شاملة لملف المنهج المرفق',
        lessons: [{ code: '00', title: 'ملف المنهج المرفق بالكامل' }],
        tasks: [
          'قراءة الشرح الأساسي واستخراج المصطلحات المهمة.',
          'مراجعة المعادلات والقوانين والبطاقات ثلاثية الأبعاد.',
          'حل تدريبات التحقق الذاتي عبر المحادثة الذكية.',
        ],
        estimatedHours: safeHours,
      },
    ];
  }

  const reserveReviewDay = safeDays >= 4 ? 1 : 0;
  const studyDays = Math.max(1, safeDays - reserveReviewDay);
  const plan: RevisionDayPlan[] = [];

  for (let d = 0; d < studyDays; d++) {
    const startIdx = Math.floor((d * pool.length) / studyDays);
    const endIdx = Math.floor(((d + 1) * pool.length) / studyDays);
    const dayLessons = pool.slice(startIdx, Math.max(startIdx + 1, endIdx));
    const names = dayLessons.map((l) => ({ code: l.code, title: l.title }));

    const tasks: string[] = [
      `قراءة وفهم الشرح المنهجي لـ: ${names.map((n) => `الدرس ${n.code}`).join('، ')}`,
      focusMode === 'fast'
        ? 'مراجعة سريعة للبطاقات ثلاثية الأبعاد (Flashcards) وأهم التعليلات.'
        : focusMode === 'advanced'
          ? 'حل مسائل مستويات التفكير العليا (ملف 15) وتطبيق القوانين والمعادلات بالخطوات.'
          : 'مراجعة القوانين والمعادلات + حل 10 أسئلة اختيار من متعدد ومقالي من المنهج.',
      'استخدام أداة «لماذا إجابتي خاطئة؟» لتثبيت أي نقطة صعبة فور ظهورها.',
    ];

    plan.push({
      day: d + 1,
      title: `اليوم ${d + 1} — ${names.map((n) => `الدرس ${n.code}`).join(' + ')}`,
      lessons: names,
      tasks,
      estimatedHours: safeHours,
    });
  }

  if (reserveReviewDay === 1) {
    plan.push({
      day: safeDays,
      title: `اليوم ${safeDays} — المراجعة النهائية الشاملة وليلة الامتحان`,
      lessons: [{ code: 'ALL', title: 'مراجعة الكتاب المفتوح (ملف 16) + المتفوقين (ملف 15) + البطاقات (ملف 17)' }],
      tasks: [
        'مراجعة جميع القوانين الـ 7 والمعادلات الموزونة والثوابت القياسية في مفكك المعادلات.',
        'اختبار سريع عبر الشات الذكي بزر «📝 هات لي سؤالين اختبار» على كل وحدة.',
        'مراجعة بطاقات المراجعة 3D التي لم تُتقن بعد.',
      ],
      estimatedHours: safeHours,
    });
  }

  return plan;
}

export interface GeneratedTeacherMcq {
  id: string;
  lesson: string;
  difficulty: string;
  question: string;
  options: { a: string; b: string; c: string; d: string };
  correctAnswer: 'a' | 'b' | 'c' | 'd';
  explanation: string;
}

const ARABIC_KEY_TO_LATIN: Record<string, 'a' | 'b' | 'c' | 'd'> = {
  'أ': 'a',
  'ب': 'b',
  'ج': 'c',
  'د': 'd',
};

export function generateLocalMcqJson(
  index: ParsedCurriculumKnowledge,
  options: { lessonCode?: string; count: number; difficulty: 'الكل' | 'أساسي' | 'متوسط' | 'متفوقين' }
): GeneratedTeacherMcq[] {
  let pool = [...index.mcqs];
  if (options.lessonCode && options.lessonCode !== 'all') {
    const filtered = pool.filter((q) => q.lessonCode === options.lessonCode);
    if (filtered.length > 0) pool = filtered;
  }
  if (options.difficulty !== 'الكل') {
    const diffFiltered = pool.filter((q) => q.difficulty === options.difficulty);
    if (diffFiltered.length > 0) pool = diffFiltered;
  }

  // Deterministic spread sampling across pool
  const count = Math.max(1, Math.min(20, options.count));
  const picked: ParsedMcqQuestion[] = [];
  if (pool.length <= count) {
    picked.push(...pool);
  } else {
    const step = pool.length / count;
    for (let i = 0; i < count; i++) {
      picked.push(pool[Math.floor(i * step)]);
    }
  }

  return picked.map((q, idx) => ({
    id: `Q_${q.lessonCode}_${String(idx + 1).padStart(2, '0')}`,
    lesson: q.lessonLabel,
    difficulty: q.difficulty,
    question: q.question,
    options: {
      a: q.options[0]?.text ?? '',
      b: q.options[1]?.text ?? '',
      c: q.options[2]?.text ?? '',
      d: q.options[3]?.text ?? '',
    },
    correctAnswer: ARABIC_KEY_TO_LATIN[q.correctKey] ?? 'a',
    explanation: q.explanation,
  }));
}
