import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CONFIG_ELEMENTS_CATALOG,
  HYDROGEN_VISIBLE_SPECTRUM,
  LIMITING_REACTIONS,
  OXIDATION_CHALLENGES,
  OXIDE_SAMPLES,
  buildElectronConfiguration,
  evaluateHydrogenTransition,
  simulateRutherfordBurst,
  solveDilution,
  solveLimitingReactant,
  testOxideWithReagent,
} from './grade2LabEngine';

test('Lab 1: solveLimitingReactant computes H2 + F2 -> 2HF limiting reactant and excess accurately', () => {
  assert.ok(LIMITING_REACTIONS.some((r) => r.id === 'h2-f2'));

  const res = solveLimitingReactant('h2-f2', 6, 4);
  assert.equal(res.limiting, 'B');
  assert.equal(res.limitingFormula, 'F₂');
  assert.equal(res.productMoles, 8);
  assert.equal(res.remainingA, 2);
  assert.equal(res.remainingB, 0);
  assert.equal(res.excessFormula, 'H₂');
  assert.equal(res.productVolumeStpL, 179.2);
});

test('Lab 1: solveDilution computes M1*V1 = M2*V2 and added water volume cleanly', () => {
  const res = solveDilution(2, 100, 0.5);
  assert.equal(res.valid, true);
  assert.equal(res.v2Ml, 400);
  assert.equal(res.waterAddedMl, 300);
  assert.equal(res.soluteMoles, 0.2);

  const invalid = solveDilution(0.5, 100, 2);
  assert.equal(invalid.valid, false);
});

test('Lab 2: simulateRutherfordBurst preserves particle conservation and gold-foil physics ratio', () => {
  const result = simulateRutherfordBurst(200);
  assert.equal(result.total, 200);
  assert.equal(result.passed + result.deflected + result.bounced, 200);
  assert.ok(result.passed > result.deflected);
  assert.ok(result.deflected >= result.bounced);
  assert.ok(result.passed / result.total > 0.9);
});

test('Lab 3: evaluateHydrogenTransition reproduces all 4 visible Balmer lines plus UV and IR alerts', () => {
  assert.equal(HYDROGEN_VISIBLE_SPECTRUM.length, 4);

  const red = evaluateHydrogenTransition(3, 2);
  assert.equal(red.region, 'visible');
  assert.equal(red.wavelengthNm, 656);

  const green = evaluateHydrogenTransition(4, 2);
  assert.equal(green.region, 'visible');
  assert.equal(green.wavelengthNm, 486);

  const blue = evaluateHydrogenTransition(5, 2);
  assert.equal(blue.region, 'visible');
  assert.equal(blue.wavelengthNm, 434);

  const violet = evaluateHydrogenTransition(6, 2);
  assert.equal(violet.region, 'visible');
  assert.equal(violet.wavelengthNm, 410);

  const uv = evaluateHydrogenTransition(3, 1);
  assert.equal(uv.region, 'uv');

  const ir = evaluateHydrogenTransition(5, 3);
  assert.equal(ir.region, 'ir');

  const absorb = evaluateHydrogenTransition(2, 4);
  assert.equal(absorb.region, 'absorption');
});

test('Lab 4: buildElectronConfiguration handles 24Cr and 29Cu anomalies, Hund rule, and 4 quantum numbers', () => {
  assert.equal(CONFIG_ELEMENTS_CATALOG.length, 36);

  const cr = buildElectronConfiguration(24);
  assert.equal(cr.isAnomaly, true);
  assert.equal(cr.shorthandConfig, '[Ar] 4s¹ 3d⁵');
  assert.equal(cr.unpairedCount, 6);
  assert.equal(cr.lastElectronQuantum.n, 3);
  assert.equal(cr.lastElectronQuantum.l, 2);
  assert.equal(cr.lastElectronQuantum.ml, 2);
  assert.equal(cr.lastElectronQuantum.ms, '+1/2');

  const cu = buildElectronConfiguration(29);
  assert.equal(cu.isAnomaly, true);
  assert.equal(cu.shorthandConfig, '[Ar] 4s¹ 3d¹⁰');
  assert.equal(cu.unpairedCount, 1);

  const n = buildElectronConfiguration(7);
  assert.equal(n.isAnomaly, false);
  assert.equal(n.unpairedCount, 3);
});

test('Lab 6: testOxideWithReagent distinguishes basic, acidic, amphoteric (Al2O3), and neutral (CO) oxides', () => {
  assert.equal(OXIDE_SAMPLES.length, 7);
  assert.equal(OXIDATION_CHALLENGES.length, 7);

  const naWater = testOxideWithReagent('na2o', 'H2O');
  assert.equal(naWater.reacts, true);
  assert.equal(naWater.litmusHex, '#2563eb');
  assert.ok(naWater.equation.includes('2NaOH'));

  const alAcid = testOxideWithReagent('al2o3', 'HCl');
  const alBase = testOxideWithReagent('al2o3', 'NaOH');
  assert.equal(alAcid.reacts, true);
  assert.equal(alBase.reacts, true);
  assert.ok(alBase.equation.includes('NaAlO₂'));

  const coAcid = testOxideWithReagent('co', 'HCl');
  const coBase = testOxideWithReagent('co', 'NaOH');
  assert.equal(coAcid.reacts, false);
  assert.equal(coBase.reacts, false);
});
