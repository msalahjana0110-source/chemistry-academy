/**
 * Pure deterministic simulation engines for Grade 2 Secondary (Term 1) Chemistry Labs.
 * Covers all 6 curriculum labs:
 * 1. Stoichiometry, Limiting Reactant & Dilution (M1V1 = M2V2)
 * 2. Rutherford Gold Foil Experiment (alpha particles & ZnS flashes)
 * 3. Bohr Hydrogen Emission Spectrum (n=1..7 transitions, 656/486/434/410 nm, UV & IR)
 * 4. Electron Configuration, Aufbau/Hund/Pauli Orbital Boxes & 4 Quantum Numbers (Z=1..36)
 * 5. Periodic Trends Heatmap helpers
 * 6. Oxides Test-Tube Reactions & Oxidation State / Redox Trainer
 */

// ============================================================================
// LAB 1: LIMITING REACTANT & DILUTION VISUALIZER
// ============================================================================

export interface LimitingReactionPreset {
  id: 'h2-f2' | 'h2-o2' | 'n2-h2';
  titleAr: string;
  equationDisplay: string;
  reactantA: { formula: string; nameAr: string; coeff: number };
  reactantB: { formula: string; nameAr: string; coeff: number };
  product: { formula: string; nameAr: string; coeff: number };
}

export const LIMITING_REACTIONS: readonly LimitingReactionPreset[] = [
  {
    id: 'h2-f2',
    titleAr: 'تفاعل الهيدروجين مع الفلور (مثال الكتاب)',
    equationDisplay: 'H₂(g) + F₂(g) → 2HF(g)',
    reactantA: { formula: 'H₂', nameAr: 'غاز الهيدروجين', coeff: 1 },
    reactantB: { formula: 'F₂', nameAr: 'غاز الفلور', coeff: 1 },
    product: { formula: 'HF', nameAr: 'فلوريد الهيدروجين', coeff: 2 },
  },
  {
    id: 'h2-o2',
    titleAr: 'تكوين الماء من الهيدروجين والأكسجين',
    equationDisplay: '2H₂(g) + O₂(g) → 2H₂O(l)',
    reactantA: { formula: 'H₂', nameAr: 'غاز الهيدروجين', coeff: 2 },
    reactantB: { formula: 'O₂', nameAr: 'غاز الأكسجين', coeff: 1 },
    product: { formula: 'H₂O', nameAr: 'بخار الماء', coeff: 2 },
  },
  {
    id: 'n2-h2',
    titleAr: 'تحضير غاز النشادر من النيتروجين والهيدروجين',
    equationDisplay: 'N₂(g) + 3H₂(g) → 2NH₃(g)',
    reactantA: { formula: 'N₂', nameAr: 'غاز النيتروجين', coeff: 1 },
    reactantB: { formula: 'H₂', nameAr: 'غاز الهيدروجين', coeff: 3 },
    product: { formula: 'NH₃', nameAr: 'غاز النشادر', coeff: 2 },
  },
];

export interface LimitingReactantResult {
  reaction: LimitingReactionPreset;
  ratioA: number;
  ratioB: number;
  limiting: 'A' | 'B' | 'both';
  limitingFormula: string;
  excessFormula: string | null;
  productMoles: number;
  productVolumeStpL: number;
  consumedA: number;
  consumedB: number;
  remainingA: number;
  remainingB: number;
  summaryAr: string;
}

export function solveLimitingReactant(
  reactionId: LimitingReactionPreset['id'],
  molA: number,
  molB: number
): LimitingReactantResult {
  const reaction =
    LIMITING_REACTIONS.find((r) => r.id === reactionId) ?? LIMITING_REACTIONS[0];
  const safeA = Math.max(0, molA);
  const safeB = Math.max(0, molB);
  const ratioA = safeA / reaction.reactantA.coeff;
  const ratioB = safeB / reaction.reactantB.coeff;
  const eps = 1e-6;

  let limiting: 'A' | 'B' | 'both' = 'both';
  let minRatio = ratioA;
  if (ratioA < ratioB - eps) {
    limiting = 'A';
    minRatio = ratioA;
  } else if (ratioB < ratioA - eps) {
    limiting = 'B';
    minRatio = ratioB;
  } else {
    limiting = 'both';
    minRatio = Math.min(ratioA, ratioB);
  }

  const consumedA = Number((minRatio * reaction.reactantA.coeff).toFixed(2));
  const consumedB = Number((minRatio * reaction.reactantB.coeff).toFixed(2));
  const remainingA = Number(Math.max(0, safeA - consumedA).toFixed(2));
  const remainingB = Number(Math.max(0, safeB - consumedB).toFixed(2));
  const productMoles = Number((minRatio * reaction.product.coeff).toFixed(2));
  const productVolumeStpL = Number((productMoles * 22.4).toFixed(2));

  const limitingFormula =
    limiting === 'A'
      ? reaction.reactantA.formula
      : limiting === 'B'
        ? reaction.reactantB.formula
        : `${reaction.reactantA.formula} و ${reaction.reactantB.formula} معاً`;

  const excessFormula =
    limiting === 'A'
      ? reaction.reactantB.formula
      : limiting === 'B'
        ? reaction.reactantA.formula
        : null;

  const summaryAr =
    limiting === 'both'
      ? `كميتا المتفاعلين متكافئتان تماماً (نسبة كل منهما ${minRatio.toFixed(2)})؛ يُستهلك كلاهما بالكامل وينتج ${productMoles} mol من ${reaction.product.formula}.`
      : `العامل المحدد هو ${limitingFormula} لأن نسبته (${minRatio.toFixed(2)}) أقل؛ يُستهلك تماماً وينتج ${productMoles} mol من ${reaction.product.formula} ويتبقى ${
          limiting === 'A' ? remainingB : remainingA
        } mol فائض من ${excessFormula}.`;

  return {
    reaction,
    ratioA: Number(ratioA.toFixed(2)),
    ratioB: Number(ratioB.toFixed(2)),
    limiting,
    limitingFormula,
    excessFormula,
    productMoles,
    productVolumeStpL,
    consumedA,
    consumedB,
    remainingA,
    remainingB,
    summaryAr,
  };
}

export interface DilutionResult {
  valid: boolean;
  error?: string;
  m1: number;
  v1Ml: number;
  m2: number;
  v2Ml: number;
  waterAddedMl: number;
  soluteMoles: number;
  beforeIntensity: number;
  afterIntensity: number;
}

export function solveDilution(m1: number, v1Ml: number, m2: number): DilutionResult {
  if (m1 <= 0 || v1Ml <= 0 || m2 <= 0) {
    return {
      valid: false,
      error: 'يجب أن تكون قيم التركيز والحجم أكبر من الصفر.',
      m1,
      v1Ml,
      m2,
      v2Ml: 0,
      waterAddedMl: 0,
      soluteMoles: 0,
      beforeIntensity: 0.8,
      afterIntensity: 0.4,
    };
  }
  if (m2 > m1) {
    return {
      valid: false,
      error: 'في عملية التخفيف بالماء يجب أن يكون التركيز النهائي M₂ أقل من أو يساوي M₁.',
      m1,
      v1Ml,
      m2,
      v2Ml: 0,
      waterAddedMl: 0,
      soluteMoles: 0,
      beforeIntensity: 0.8,
      afterIntensity: 0.8,
    };
  }

  const v2Ml = Number(((m1 * v1Ml) / m2).toFixed(1));
  const waterAddedMl = Number(Math.max(0, v2Ml - v1Ml).toFixed(1));
  const soluteMoles = Number(((m1 * v1Ml) / 1000).toFixed(4));
  const beforeIntensity = Math.min(0.92, Math.max(0.25, m1 / 2.5));
  const afterIntensity = Math.min(0.92, Math.max(0.12, (m2 / m1) * beforeIntensity));

  return {
    valid: true,
    m1,
    v1Ml,
    m2,
    v2Ml,
    waterAddedMl,
    soluteMoles,
    beforeIntensity,
    afterIntensity,
  };
}

// ============================================================================
// LAB 2: RUTHERFORD GOLD FOIL EXPERIMENT SIMULATOR
// ============================================================================

export type RutherfordOutcome = 'passed' | 'deflected' | 'bounced';

export interface RutherfordRay {
  id: number;
  startY: number;
  outcome: RutherfordOutcome;
  endX: number;
  endY: number;
  flashAngleDeg: number;
}

export interface RutherfordBurstSummary {
  rays: RutherfordRay[];
  passed: number;
  deflected: number;
  bounced: number;
  total: number;
}

export function simulateRutherfordBurst(
  count = 100,
  seedOffset = 0
): RutherfordBurstSummary {
  const safeCount = Math.max(10, Math.min(500, Math.floor(count)));
  // Curriculum-faithful ratios: ~93% pass straight, ~5% deflect near nucleus, ~2% bounce back
  const bouncedCount = Math.max(1, Math.round(safeCount * 0.02));
  const deflectedCount = Math.max(2, Math.round(safeCount * 0.05));
  const passedCount = Math.max(1, safeCount - bouncedCount - deflectedCount);

  const rays: RutherfordRay[] = [];
  const visualRaySlots = 18;
  for (let i = 0; i < visualRaySlots; i += 1) {
    const idx = (i + seedOffset) % visualRaySlots;
    const norm = (i / (visualRaySlots - 1)) * 2 - 1; // -1..+1
    const startY = 120 + norm * 78;

    let outcome: RutherfordOutcome = 'passed';
    let endX = 372;
    let endY = startY;
    let flashAngleDeg = norm * 16;

    if (Math.abs(norm) < 0.1) {
      outcome = 'bounced';
      endX = 88;
      endY = 120 + (idx % 2 === 0 ? -42 : 42);
      flashAngleDeg = idx % 2 === 0 ? 155 : -155;
    } else if (Math.abs(norm) < 0.28) {
      outcome = 'deflected';
      const dir = norm >= 0 ? 1 : -1;
      endX = 335;
      endY = 120 + dir * 92;
      flashAngleDeg = dir * 54;
    }

    rays.push({
      id: i + 1,
      startY: Number(startY.toFixed(1)),
      outcome,
      endX,
      endY: Number(endY.toFixed(1)),
      flashAngleDeg: Number(flashAngleDeg.toFixed(1)),
    });
  }

  return {
    rays,
    passed: passedCount,
    deflected: deflectedCount,
    bounced: bouncedCount,
    total: safeCount,
  };
}

// ============================================================================
// LAB 3: BOHR HYDROGEN EMISSION SPECTRUM SIMULATOR (n=1..7)
// ============================================================================

export type SpectralRegion = 'uv' | 'visible' | 'ir' | 'absorption' | 'none';

export interface HydrogenTransitionResult {
  nInitial: number;
  nFinal: number;
  isEmission: boolean;
  region: SpectralRegion;
  wavelengthNm: number | null;
  deltaEev: number;
  colorNameAr: string;
  hexColor: string;
  seriesNameAr: string;
  alertAr: string;
}

const VISIBLE_BALMER_LINES: Record<number, { nm: number; nameAr: string; hex: string }> = {
  3: { nm: 656, nameAr: 'أحمر (Red)', hex: '#ef4444' },
  4: { nm: 486, nameAr: 'أخضر (Green / Cyan)', hex: '#10b981' },
  5: { nm: 434, nameAr: 'أزرق (Blue)', hex: '#3b82f6' },
  6: { nm: 410, nameAr: 'بنفسجي (Violet)', hex: '#8b5cf6' },
};

export const HYDROGEN_VISIBLE_SPECTRUM = [
  { nInitial: 3, nFinal: 2, nm: 656, nameAr: 'أحمر', hex: '#ef4444', posPct: 78 },
  { nInitial: 4, nFinal: 2, nm: 486, nameAr: 'أخضر', hex: '#10b981', posPct: 48 },
  { nInitial: 5, nFinal: 2, nm: 434, nameAr: 'أزرق', hex: '#3b82f6', posPct: 30 },
  { nInitial: 6, nFinal: 2, nm: 410, nameAr: 'بنفسجي', hex: '#8b5cf6', posPct: 18 },
] as const;

export function evaluateHydrogenTransition(
  nInitial: number,
  nFinal: number
): HydrogenTransitionResult {
  const ni = Math.max(1, Math.min(7, Math.floor(nInitial)));
  const nf = Math.max(1, Math.min(7, Math.floor(nFinal)));

  if (ni === nf) {
    return {
      nInitial: ni,
      nFinal: nf,
      isEmission: false,
      region: 'none',
      wavelengthNm: null,
      deltaEev: 0,
      colorNameAr: 'لا يوجد انتقال',
      hexColor: '#94a3b8',
      seriesNameAr: 'حالة مستقرة',
      alertAr: 'اختر مستويين مختلفين لمشاهدة امتصاص أو انبعاث كم (كوانتم) من الطاقة.',
    };
  }

  const deltaEev = Number(Math.abs(-13.6 / (nf * nf) - -13.6 / (ni * ni)).toFixed(2));
  const isEmission = ni > nf;

  if (!isEmission) {
    return {
      nInitial: ni,
      nFinal: nf,
      isEmission: false,
      region: 'absorption',
      wavelengthNm: Math.round(1240 / Math.max(0.01, deltaEev)),
      deltaEev,
      colorNameAr: 'امتصاص كم (إثارة)',
      hexColor: '#f59e0b',
      seriesNameAr: 'عملية إثارة للإلكترون',
      alertAr: `يمتص الإلكترون كماً من الطاقة قدره ${deltaEev} eV لينتقل من n=${ni} إلى مستوى أعلى n=${nf} وتصبح الذرة مثارة.`,
    };
  }

  // Emission (ni > nf)
  const RH = 0.01097373; // nm^-1
  const exactNm = Math.round(1 / (RH * (1 / (nf * nf) - 1 / (ni * ni))));

  if (nf === 2 && VISIBLE_BALMER_LINES[ni]) {
    const line = VISIBLE_BALMER_LINES[ni];
    return {
      nInitial: ni,
      nFinal: nf,
      isEmission: true,
      region: 'visible',
      wavelengthNm: line.nm,
      deltaEev,
      colorNameAr: line.nameAr,
      hexColor: line.hex,
      seriesNameAr: 'سلسلة بالمر (الطيف المرئي)',
      alertAr: `عودة الإلكترون من n=${ni} إلى n=2 تُصدر خطاً طيفياً مرئياً بلون ${line.nameAr} بطول موجي ${line.nm} nm.`,
    };
  }

  if (nf === 1 || (nf === 2 && ni === 7)) {
    return {
      nInitial: ni,
      nFinal: nf,
      isEmission: true,
      region: 'uv',
      wavelengthNm: exactNm,
      deltaEev,
      colorNameAr: 'أشعة فوق بنفسجية (UV)',
      hexColor: '#a855f7',
      seriesNameAr: nf === 1 ? 'سلسلة ليمان (فوق بنفسجية)' : 'بالمر فوق بنفسجي (n=7→2)',
      alertAr: `تنبيه طيفي: العودة إلى n=${nf} بطول موجي ${exactNm} nm تقع في منطقة الأشعة فوق البنفسجية غير المرئية للعين البشرية (طاقة عالية جداً).`,
    };
  }

  return {
    nInitial: ni,
    nFinal: nf,
    isEmission: true,
    region: 'ir',
    wavelengthNm: exactNm,
    deltaEev,
    colorNameAr: 'أشعة تحت حمراء (IR)',
    hexColor: '#f97316',
    seriesNameAr: nf === 3 ? 'سلسلة باشن (تحت حمراء)' : 'تحت حمراء بعيدة',
    alertAr: `تنبيه طيفي: العودة إلى n=${nf} بطول موجي ${exactNm} nm تقع في منطقة الأشعة تحت الحمراء غير المرئية للعين البشرية (طاقة منخفضة).`,
  };
}

// ============================================================================
// LAB 4: ELECTRON CONFIGURATION, HUND/PAULI ORBITALS & 4 QUANTUM NUMBERS (Z=1..36)
// ============================================================================

export interface OrbitalBox {
  ml: number;
  hasUp: boolean;
  hasDown: boolean;
}

export interface FilledSubshell {
  label: string;
  n: number;
  l: number;
  electrons: number;
  capacity: number;
  orbitals: OrbitalBox[];
}

export interface FourQuantumNumbers {
  n: number;
  l: number;
  ml: number;
  ms: '+1/2' | '-1/2';
  subshellLabel: string;
}

export interface ElectronConfigReport {
  atomicNumber: number;
  symbol: string;
  nameAr: string;
  fullConfig: string;
  shorthandConfig: string;
  isAnomaly: boolean;
  anomalyNoteAr: string | null;
  subshells: FilledSubshell[];
  lastElectronQuantum: FourQuantumNumbers;
  unpairedCount: number;
}

const ELEMENTS_1_TO_36: ReadonlyArray<{ z: number; symbol: string; nameAr: string }> = [
  { z: 1, symbol: 'H', nameAr: 'هيدروجين' },
  { z: 2, symbol: 'He', nameAr: 'هيليوم' },
  { z: 3, symbol: 'Li', nameAr: 'ليثيوم' },
  { z: 4, symbol: 'Be', nameAr: 'بيريليوم' },
  { z: 5, symbol: 'B', nameAr: 'بورون' },
  { z: 6, symbol: 'C', nameAr: 'كربون' },
  { z: 7, symbol: 'N', nameAr: 'نيتروجين' },
  { z: 8, symbol: 'O', nameAr: 'أكسجين' },
  { z: 9, symbol: 'F', nameAr: 'فلور' },
  { z: 10, symbol: 'Ne', nameAr: 'نيون' },
  { z: 11, symbol: 'Na', nameAr: 'صوديوم' },
  { z: 12, symbol: 'Mg', nameAr: 'ماغنيسيوم' },
  { z: 13, symbol: 'Al', nameAr: 'ألومنيوم' },
  { z: 14, symbol: 'Si', nameAr: 'سيليكون' },
  { z: 15, symbol: 'P', nameAr: 'فوسفور' },
  { z: 16, symbol: 'S', nameAr: 'كبريت' },
  { z: 17, symbol: 'Cl', nameAr: 'كلور' },
  { z: 18, symbol: 'Ar', nameAr: 'أرجون' },
  { z: 19, symbol: 'K', nameAr: 'بوتاسيوم' },
  { z: 20, symbol: 'Ca', nameAr: 'كالسيوم' },
  { z: 21, symbol: 'Sc', nameAr: 'سكانديوم' },
  { z: 22, symbol: 'Ti', nameAr: 'تيتانيوم' },
  { z: 23, symbol: 'V', nameAr: 'فاناديوم' },
  { z: 24, symbol: 'Cr', nameAr: 'كروم' },
  { z: 25, symbol: 'Mn', nameAr: 'منجنيز' },
  { z: 26, symbol: 'Fe', nameAr: 'حديد' },
  { z: 27, symbol: 'Co', nameAr: 'كوبالت' },
  { z: 28, symbol: 'Ni', nameAr: 'نيكل' },
  { z: 29, symbol: 'Cu', nameAr: 'نحاس' },
  { z: 30, symbol: 'Zn', nameAr: 'خارصين' },
  { z: 31, symbol: 'Ga', nameAr: 'جاليوم' },
  { z: 32, symbol: 'Ge', nameAr: 'جرمانيوم' },
  { z: 33, symbol: 'As', nameAr: 'زرنيخ' },
  { z: 34, symbol: 'Se', nameAr: 'سيلينيوم' },
  { z: 35, symbol: 'Br', nameAr: 'بروم' },
  { z: 36, symbol: 'Kr', nameAr: 'كريبتون' },
];

export const CONFIG_ELEMENTS_CATALOG = ELEMENTS_1_TO_36;

const AUFBAU_SEQUENCE: ReadonlyArray<{ label: string; n: number; l: number; capacity: number }> = [
  { label: '1s', n: 1, l: 0, capacity: 2 },
  { label: '2s', n: 2, l: 0, capacity: 2 },
  { label: '2p', n: 2, l: 1, capacity: 6 },
  { label: '3s', n: 3, l: 0, capacity: 2 },
  { label: '3p', n: 3, l: 1, capacity: 6 },
  { label: '4s', n: 4, l: 0, capacity: 2 },
  { label: '3d', n: 3, l: 2, capacity: 10 },
  { label: '4p', n: 4, l: 1, capacity: 6 },
];

const SUPERSCRIPTS: Record<string, string> = {
  '0': '⁰',
  '1': '¹',
  '2': '²',
  '3': '³',
  '4': '⁴',
  '5': '⁵',
  '6': '⁶',
  '7': '⁷',
  '8': '⁸',
  '9': '⁹',
};

function toSuperscript(num: number): string {
  return String(num)
    .split('')
    .map((d) => SUPERSCRIPTS[d] ?? d)
    .join('');
}

function buildHundOrbitals(l: number, electrons: number): OrbitalBox[] {
  const orbCount = 2 * l + 1;
  const boxes: OrbitalBox[] = [];
  for (let i = 0; i < orbCount; i += 1) {
    const ml = -l + i;
    const hasUp = electrons > i;
    const hasDown = electrons > orbCount + i;
    boxes.push({ ml, hasUp, hasDown });
  }
  return boxes;
}

export function buildElectronConfiguration(atomicNumber: number): ElectronConfigReport {
  const z = Math.max(1, Math.min(36, Math.floor(atomicNumber)));
  const meta = ELEMENTS_1_TO_36[z - 1];

  const counts = new Map<string, number>();
  let remaining = z;
  for (const sub of AUFBAU_SEQUENCE) {
    if (remaining <= 0) break;
    const take = Math.min(remaining, sub.capacity);
    counts.set(sub.label, take);
    remaining -= take;
  }

  let isAnomaly = false;
  let anomalyNoteAr: string | null = null;
  if (z === 24) {
    // Cr anomaly: 4s1 3d5
    counts.set('4s', 1);
    counts.set('3d', 5);
    isAnomaly = true;
    anomalyNoteAr =
      'حالة شذوذ إلكتروني (الكروم ₂₄Cr): ينتقل إلكترون من 4s إلى 3d ليصبح المستوى الفرعي 3d نصف ممتلئ (3d⁵) وأكثر استقراراً.';
  } else if (z === 29) {
    // Cu anomaly: 4s1 3d10
    counts.set('4s', 1);
    counts.set('3d', 10);
    isAnomaly = true;
    anomalyNoteAr =
      'حالة شذوذ إلكتروني (النحاس ₂₉Cu): ينتقل إلكترون من 4s إلى 3d ليصبح المستوى الفرعي 3d تام الامتلاء (3d¹⁰) وأكثر استقراراً.';
  }

  const subshells: FilledSubshell[] = [];
  let unpairedCount = 0;
  for (const sub of AUFBAU_SEQUENCE) {
    const eCount = counts.get(sub.label) ?? 0;
    if (eCount <= 0) continue;
    const orbitals = buildHundOrbitals(sub.l, eCount);
    orbitals.forEach((o) => {
      if (o.hasUp && !o.hasDown) unpairedCount += 1;
    });
    subshells.push({
      label: sub.label,
      n: sub.n,
      l: sub.l,
      electrons: eCount,
      capacity: sub.capacity,
      orbitals,
    });
  }

  const fullConfig = subshells
    .map((s) => `${s.label}${toSuperscript(s.electrons)}`)
    .join(' ');

  let shorthandConfig = fullConfig;
  if (z > 18) {
    shorthandConfig =
      '[Ar] ' +
      subshells
        .filter((s) => !['1s', '2s', '2p', '3s', '3p'].includes(s.label))
        .map((s) => `${s.label}${toSuperscript(s.electrons)}`)
        .join(' ');
  } else if (z > 10) {
    shorthandConfig =
      '[Ne] ' +
      subshells
        .filter((s) => !['1s', '2s', '2p'].includes(s.label))
        .map((s) => `${s.label}${toSuperscript(s.electrons)}`)
        .join(' ');
  } else if (z > 2) {
    shorthandConfig =
      '[He] ' +
      subshells
        .filter((s) => s.label !== '1s')
        .map((s) => `${s.label}${toSuperscript(s.electrons)}`)
        .join(' ');
  }

  const lastSub = subshells[subshells.length - 1];
  const orbCount = 2 * lastSub.l + 1;
  const eInLast = lastSub.electrons;
  const isSecondPass = eInLast > orbCount;
  const orbIndex = isSecondPass ? eInLast - orbCount - 1 : eInLast - 1;
  const lastElectronQuantum: FourQuantumNumbers = {
    n: lastSub.n,
    l: lastSub.l,
    ml: -lastSub.l + orbIndex,
    ms: isSecondPass ? '-1/2' : '+1/2',
    subshellLabel: lastSub.label,
  };

  return {
    atomicNumber: z,
    symbol: meta.symbol,
    nameAr: meta.nameAr,
    fullConfig,
    shorthandConfig,
    isAnomaly,
    anomalyNoteAr,
    subshells,
    lastElectronQuantum,
    unpairedCount,
  };
}

// ============================================================================
// LAB 6: OXIDES TEST-TUBE LAB & OXIDATION STATE / REDOX TRAINER
// ============================================================================

export type OxideKind = 'قاعدي' | 'حامضي' | 'متردد' | 'متعادل';
export type ReagentId = 'H2O' | 'HCl' | 'NaOH';

export interface OxideSample {
  id: string;
  formula: string;
  nameAr: string;
  kind: OxideKind;
  powderColor: string;
}

export const OXIDE_SAMPLES: readonly OxideSample[] = [
  { id: 'na2o', formula: 'Na₂O', nameAr: 'أكسيد الصوديوم', kind: 'قاعدي', powderColor: '#e2e8f0' },
  { id: 'mgo', formula: 'MgO', nameAr: 'أكسيد الماغنسيوم', kind: 'قاعدي', powderColor: '#f1f5f9' },
  { id: 'al2o3', formula: 'Al₂O₃', nameAr: 'أكسيد الألومنيوم', kind: 'متردد', powderColor: '#cbd5e1' },
  { id: 'zno', formula: 'ZnO', nameAr: 'أكسيد الخارصين', kind: 'متردد', powderColor: '#fef9c3' },
  { id: 'co2', formula: 'CO₂', nameAr: 'ثاني أكسيد الكربون', kind: 'حامضي', powderColor: '#bae6fd' },
  { id: 'so3', formula: 'SO₃', nameAr: 'ثالث أكسيد الكبريت', kind: 'حامضي', powderColor: '#ddd6fe' },
  { id: 'co', formula: 'CO', nameAr: 'أول أكسيد الكربون', kind: 'متعادل', powderColor: '#94a3b8' },
];

export interface OxideTestResult {
  oxide: OxideSample;
  reagent: ReagentId;
  reacts: boolean;
  equation: string;
  litmusHex: string;
  litmusLabelAr: string;
  solutionHex: string;
  observationAr: string;
}

export function testOxideWithReagent(oxideId: string, reagent: ReagentId): OxideTestResult {
  const oxide = OXIDE_SAMPLES.find((o) => o.id === oxideId) ?? OXIDE_SAMPLES[0];

  const reactions: Record<string, Record<ReagentId, Omit<OxideTestResult, 'oxide' | 'reagent'>>> = {
    na2o: {
      H2O: {
        reacts: true,
        equation: 'Na₂O(s) + H₂O(l) → 2NaOH(aq)',
        litmusHex: '#2563eb',
        litmusLabelAr: 'يزرق عباد الشمس (قلوي قوي)',
        solutionHex: 'rgba(59, 130, 246, 0.35)',
        observationAr: 'يذوب أكسيد الصوديوم القاعدي بشدة في الماء مكوناً محلول هيدروكسيد الصوديوم القلوي.',
      },
      HCl: {
        reacts: true,
        equation: 'Na₂O(s) + 2HCl(aq) → 2NaCl(aq) + H₂O(l)',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'تفاعل تعادل (ملح وماء)',
        solutionHex: 'rgba(148, 163, 184, 0.25)',
        observationAr: 'يتفاعل الأكسيد القاعدي مع حمض الهيدروكلوريك وينتج ملح كلوريد الصوديوم وماء.',
      },
      NaOH: {
        reacts: false,
        equation: 'Na₂O + NaOH → لا يحدث تفاعل',
        litmusHex: '#2563eb',
        litmusLabelAr: 'الوسط قلوي (لا تفاعل مع القاعدة)',
        solutionHex: 'rgba(59, 130, 246, 0.2)',
        observationAr: 'الأكاسيد القاعدية لا تتفاعل مع القلويات (NaOH).',
      },
    },
    mgo: {
      H2O: {
        reacts: true,
        equation: 'MgO(s) + H₂O(l) → Mg(OH)₂(aq) (شحيح الذوبان)',
        litmusHex: '#3b82f6',
        litmusLabelAr: 'يزرق عباد الشمس بدرجة خفيفة',
        solutionHex: 'rgba(96, 165, 250, 0.28)',
        observationAr: 'أكسيد الماغنسيوم أكسيد قاعدي شحيح الذوبان في الماء ويعطي محلولاً قلوياً ضعيفاً.',
      },
      HCl: {
        reacts: true,
        equation: 'MgO(s) + 2HCl(aq) → MgCl₂(aq) + H₂O(l)',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'تفاعل تعادل (ملح MgCl₂ وماء)',
        solutionHex: 'rgba(148, 163, 184, 0.25)',
        observationAr: 'يذوب MgO سريعاً في الأحماض القوية مثل HCl أو H₂SO₄ مكوناً ملحاً وماءً.',
      },
      NaOH: {
        reacts: false,
        equation: 'MgO + NaOH → لا يحدث تفاعل',
        litmusHex: '#2563eb',
        litmusLabelAr: 'لا يتفاعل مع القلويات',
        solutionHex: 'rgba(148, 163, 184, 0.2)',
        observationAr: 'أكسيد قاعدي خالص لذلك لا يتفاعل مع هيدروكسيد الصوديوم.',
      },
    },
    al2o3: {
      H2O: {
        reacts: false,
        equation: 'Al₂O₃(s) + H₂O(l) → لا يذوب في الماء',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'بنفسجي متعادل (لا يذوب)',
        solutionHex: 'rgba(148, 163, 184, 0.16)',
        observationAr: 'أكسيد الألومنيوم أكسيد متردد لا يذوب في الماء النقي، لكنه يتفاعل مع كل من الأحماض والقلويات.',
      },
      HCl: {
        reacts: true,
        equation: 'Al₂O₃(s) + 6HCl(aq) → 2AlCl₃(aq) + 3H₂O(l)',
        litmusHex: '#ef4444',
        litmusLabelAr: 'يسلك كأكسيد قاعدي مع الحمض',
        solutionHex: 'rgba(248, 113, 113, 0.25)',
        observationAr: 'يسلك Al₂O₃ سلوك الأكسيد القاعدي أمام الحمض مكوناً ملح كلوريد الألومنيوم وماء.',
      },
      NaOH: {
        reacts: true,
        equation: 'Al₂O₃(s) + 2NaOH(aq) → 2NaAlO₂(aq) + H₂O(l)',
        litmusHex: '#2563eb',
        litmusLabelAr: 'يسلك كأكسيد حامضي مع القلوي (ميتا ألومينات الصوديوم)',
        solutionHex: 'rgba(56, 189, 248, 0.3)',
        observationAr: 'يسلك Al₂O₃ سلوك الأكسيد الحامضي أمام NaOH مكوناً ملح ميتا ألومينات الصوديوم وماء.',
      },
    },
    zno: {
      H2O: {
        reacts: false,
        equation: 'ZnO(s) + H₂O(l) → لا يذوب في الماء',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'بنفسجي متعادل (أكسيد متردد)',
        solutionHex: 'rgba(254, 249, 195, 0.25)',
        observationAr: 'أكسيد الخارصين متردد لا يذوب في الماء، ويتفاعل مع الأحماض والقلويات على حد سواء.',
      },
      HCl: {
        reacts: true,
        equation: 'ZnO(s) + 2HCl(aq) → ZnCl₂(aq) + H₂O(l)',
        litmusHex: '#ef4444',
        litmusLabelAr: 'يتفاعل كقاعدة مع الحمض',
        solutionHex: 'rgba(248, 113, 113, 0.24)',
        observationAr: 'يذوب ZnO في حمض HCl (أو H₂SO₄ ليعطي ZnSO₄) مكوناً ملحاً وماءً.',
      },
      NaOH: {
        reacts: true,
        equation: 'ZnO(s) + 2NaOH(aq) → Na₂ZnO₂(aq) + H₂O(l)',
        litmusHex: '#2563eb',
        litmusLabelAr: 'يتفاعل كحمض مع القلوي (خارصينات الصوديوم)',
        solutionHex: 'rgba(56, 189, 248, 0.3)',
        observationAr: 'يتفاعل ZnO مع NaOH منتجاً ملح خارصينات الصوديوم الذائب وماء.',
      },
    },
    co2: {
      H2O: {
        reacts: true,
        equation: 'CO₂(g) + H₂O(l) → H₂CO₃(aq)',
        litmusHex: '#ef4444',
        litmusLabelAr: 'يحمر عباد الشمس (حمض الكربونيك)',
        solutionHex: 'rgba(239, 68, 68, 0.28)',
        observationAr: 'يذوب غاز CO₂ الحامضي في الماء مكوناً حمض الكربونيك الضعيف H₂CO₃.',
      },
      HCl: {
        reacts: false,
        equation: 'CO₂ + HCl → لا يحدث تفاعل',
        litmusHex: '#ef4444',
        litmusLabelAr: 'أكسيد حامضي لا يتفاعل مع الأحماض',
        solutionHex: 'rgba(239, 68, 68, 0.18)',
        observationAr: 'الأكاسيد الحامضية للافلزات لا تتفاعل مع الأحماض.',
      },
      NaOH: {
        reacts: true,
        equation: 'CO₂(g) + 2NaOH(aq) → Na₂CO₃(aq) + H₂O(l)',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'يتفاعل مع القلوي مكوناً كربونات الصوديوم وماء',
        solutionHex: 'rgba(148, 163, 184, 0.25)',
        observationAr: 'يتفاعل الأكسيد الحامضي مع القلوي NaOH مكوناً ملح كربونات الصوديوم وماء.',
      },
    },
    so3: {
      H2O: {
        reacts: true,
        equation: 'SO₃(g) + H₂O(l) → H₂SO₄(aq)',
        litmusHex: '#dc2626',
        litmusLabelAr: 'يحمر عباد الشمس بشدة (حمض الكبريتيك القوي)',
        solutionHex: 'rgba(220, 38, 38, 0.36)',
        observationAr: 'يتحد SO₃ بعنف مع الماء مكوناً حمض الكبريتيك القوي H₂SO₄.',
      },
      HCl: {
        reacts: false,
        equation: 'SO₃ + HCl → لا يحدث تفاعل',
        litmusHex: '#dc2626',
        litmusLabelAr: 'أكسيد حامضي لا يتفاعل مع الأحماض',
        solutionHex: 'rgba(220, 38, 38, 0.18)',
        observationAr: 'ثالث أكسيد الكبريت أكسيد حامضي فلا يتفاعل مع حمض HCl.',
      },
      NaOH: {
        reacts: true,
        equation: 'SO₃(g) + 2NaOH(aq) → Na₂SO₄(aq) + H₂O(l)',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'تعادل تام (كبريتات الصوديوم وماء)',
        solutionHex: 'rgba(148, 163, 184, 0.25)',
        observationAr: 'يتفاعل SO₃ الحامضي مع القلوي مكوناً كبريتات الصوديوم وماء.',
      },
    },
    co: {
      H2O: {
        reacts: false,
        equation: 'CO(g) + H₂O(l) → لا يذوب ولا يتفاعل',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'بنفسجي متعادل (لا يؤثر على عباد الشمس)',
        solutionHex: 'rgba(148, 163, 184, 0.14)',
        observationAr: 'أول أكسيد الكربون CO (مثل NO و N₂O) أكسيد متعادل لا يكوّن حمضاً ولا قلوياً.',
      },
      HCl: {
        reacts: false,
        equation: 'CO + HCl → لا يحدث تفاعل',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'متعادل (لا يتفاعل مع الأحماض)',
        solutionHex: 'rgba(148, 163, 184, 0.14)',
        observationAr: 'الأكسيد المتعادل لا يتفاعل مع الأحماض في الظروف العادية.',
      },
      NaOH: {
        reacts: false,
        equation: 'CO + NaOH → لا يحدث تفاعل',
        litmusHex: '#8b5cf6',
        litmusLabelAr: 'متعادل (لا يتفاعل مع القلويات)',
        solutionHex: 'rgba(148, 163, 184, 0.14)',
        observationAr: 'الأكسيد المتعادل لا يتفاعل مع القلويات في الظروف العادية.',
      },
    },
  };

  return {
    oxide,
    reagent,
    ...reactions[oxide.id][reagent],
  };
}

export interface OxidationChallenge {
  id: string;
  formula: string;
  nameAr: string;
  targetElement: string;
  promptAr: string;
  options: string[];
  correctOption: string;
  isAnomaly: boolean;
  stepsAr: string;
  redoxRoleAr: string;
}

export const OXIDATION_CHALLENGES: readonly OxidationChallenge[] = [
  {
    id: 'ox-h2o2',
    formula: 'H₂O₂',
    nameAr: 'فوق أكسيد الهيدروجين',
    targetElement: 'O',
    promptAr: 'ما عدد تأكسد الأكسجين (O) في جزيء فوق أكسيد الهيدروجين H₂O₂؟',
    options: ['-2', '-1', '-1/2', '+2'],
    correctOption: '-1',
    isAnomaly: true,
    stepsAr: '2(+1) + 2(O) = 0  ⇒  2(O) = -2  ⇒  O = -1 (حالة شاذة في فوق الأكاسيد).',
    redoxRoleAr: 'حالة وسطية للأكسجين (بين -2 و 0) ← يسلك كعامل مؤكسد وعامل مختزل في تفاعل عدم التناسب (2H₂O₂ → 2H₂O + O₂).',
  },
  {
    id: 'ox-ko2',
    formula: 'KO₂',
    nameAr: 'سوبر أكسيد البوتاسيوم',
    targetElement: 'O',
    promptAr: 'ما عدد تأكسد الأكسجين (O) في مركب سوبر أكسيد البوتاسيوم KO₂؟',
    options: ['-2', '-1', '-1/2', '+1'],
    correctOption: '-1/2',
    isAnomaly: true,
    stepsAr: 'البوتاسيوم (1A) = +1 دائماً ← (+1) + 2(O) = 0  ⇒  O = -1/2 (سوبر أكسيد).',
    redoxRoleAr: 'يُستخدم في الغواصات والطائرات لتنقية الهواء وتوليد الأكسجين.',
  },
  {
    id: 'ox-of2',
    formula: 'OF₂',
    nameAr: 'ثاني فلوريد الأكسجين',
    targetElement: 'O',
    promptAr: 'ما عدد تأكسد الأكسجين (O) في مركب ثاني فلوريد الأكسجين OF₂؟',
    options: ['-2', '-1', '+1', '+2'],
    correctOption: '+2',
    isAnomaly: true,
    stepsAr: 'الفلور أعلى العناصر سالبية كهربية فعدده = -1 دائماً ← O + 2(-1) = 0  ⇒  O = +2.',
    redoxRoleAr: 'الحالة الوحيدة التي يظهر فيها الأكسجين بعدد تأكسد موجب (+2).',
  },
  {
    id: 'ox-nah',
    formula: 'NaH',
    nameAr: 'هيدريد الصوديوم',
    targetElement: 'H',
    promptAr: 'ما عدد تأكسد الهيدروجين (H) في هيدريد الصوديوم NaH؟',
    options: ['+1', '0', '-1', '-2'],
    correctOption: '-1',
    isAnomaly: true,
    stepsAr: 'الصوديوم (1A) = +1 دائماً ← (+1) + H = 0  ⇒  H = -1 (هيدريد فلز نشط).',
    redoxRoleAr: 'أقل حالة تأكسد للهيدروجين (-1) ← يعمل كعامل مختزل قوي فقط.',
  },
  {
    id: 'ox-kmno4',
    formula: 'KMnO₄',
    nameAr: 'برمنجنات البوتاسيوم',
    targetElement: 'Mn',
    promptAr: 'احسب عدد تأكسد المنجنيز (Mn) في برمنجنات البوتاسيوم KMnO₄:',
    options: ['+4', '+5', '+6', '+7'],
    correctOption: '+7',
    isAnomaly: false,
    stepsAr: '(+1) + Mn + 4(-2) = 0  ⇒  Mn - 7 = 0  ⇒  Mn = +7.',
    redoxRoleAr: 'أعلى حالة تأكسد للمنجنيز (+7) ← لا يمكنه فقد المزيد فيعمل كعامل مؤكسد قوي فقط.',
  },
  {
    id: 'ox-k2cr2o7',
    formula: 'K₂Cr₂O₇',
    nameAr: 'ثاني كرومات البوتاسيوم',
    targetElement: 'Cr',
    promptAr: 'احسب عدد تأكسد الكروم (Cr) في ثاني كرومات البوتاسيوم K₂Cr₂O₇:',
    options: ['+3', '+5', '+6', '+7'],
    correctOption: '+6',
    isAnomaly: false,
    stepsAr: '2(+1) + 2(Cr) + 7(-2) = 0  ⇒  2(Cr) = +12  ⇒  Cr = +6.',
    redoxRoleAr: 'أعلى حالة تأكسد للكروم (+6) ← عامل مؤكسد قوي فقط (يتحول من البرتقالي إلى الأخضر Cr³⁺ عند الاختزال).',
  },
  {
    id: 'ox-nh4no2',
    formula: 'NH₄NO₂',
    nameAr: 'نيتريت الأمونيوم',
    targetElement: 'N',
    promptAr: 'ما عددا تأكسد ذرتي النيتروجين في نيتريت الأمونيوم NH₄NO₂ (الأولى في NH₄⁺ والثانية في NO₂⁻)؟',
    options: ['-3 و +3', '-3 و +5', '+3 و +5', '0 و +4'],
    correctOption: '-3 و +3',
    isAnomaly: true,
    stepsAr: 'في NH₄⁺: N + 4(+1) = +1 ⇒ N = -3. وفي NO₂⁻: N + 2(-2) = -1 ⇒ N = +3.',
    redoxRoleAr: 'مثال كلاسيكي للامتحانات حيث تختلف حالتا تأكسد نفس العنصر داخل مركب أيوني واحد.',
  },
];
