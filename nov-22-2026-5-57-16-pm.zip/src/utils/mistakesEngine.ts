import {
  ACADEMY_DATA,
  type LessonItem,
  type LessonPracticeMcq,
  type QuizQuestion,
} from '../data/academyData';
import {
  HARD_CERTIFICATE_QUESTIONS,
  type HardChallengeQuestion,
} from './certificateEngine';

export type MistakeSource =
  | 'lesson-check'
  | 'question-bank'
  | 'adaptive-quiz'
  | 'certificate-challenge';

export interface MistakeLessonTarget {
  unitId: 'unit1' | 'unit2' | 'unit3';
  unitName: string;
  lessonId: string;
  lessonTitle: string;
  sectionIndex: number;
  sectionTitle: string;
}

export interface MistakeRecord {
  questionId: string;
  source: MistakeSource;
  sourceLabel: string;
  question: string;
  formula?: string;
  options: string[];
  selectedOptionIndex: number;
  correctIndex: number;
  explanation: string;
  difficulty?: string;
  unitId: 'unit1' | 'unit2' | 'unit3';
  unitName: string;
  lessonId: string;
  lessonTitle: string;
  sectionIndex: number;
  sectionTitle: string;
  wrongCount: number;
  resolved: boolean;
  lastMissedAtIso: string;
}

export interface MistakeInput {
  questionId: string;
  source: MistakeSource;
  question: string;
  formula?: string;
  options: string[];
  selectedOptionIndex: number;
  correctIndex: number;
  explanation: string;
  difficulty?: string;
  lessonId?: string;
  sectionIndex?: number;
}

export interface MistakeSummary {
  totalCount: number;
  unresolvedCount: number;
  resolvedCount: number;
  topWeakUnit: { unitName: string; count: number } | null;
}

export const MISTAKE_SOURCE_LABELS: Record<MistakeSource, string> = {
  'lesson-check': 'اختبر فهمك للدرس',
  'question-bank': 'بنك الأسئلة',
  'adaptive-quiz': 'الاختبار التكيّفي الذكي',
  'certificate-challenge': 'تحدي الشهادة الصعب',
};

/**
 * Resolves any question ID (from the 798-MCQ bank, 12 lesson practice checks,
 * or 5 hard certificate questions) to its exact lesson & section index so
 * clicking "انتقل لشرح السؤال" jumps straight to the relevant axis.
 */
export function resolveLessonExplanationTarget(
  questionId: string,
  fallbackLessonId?: string,
  fallbackSectionIndex?: number,
  lessons: readonly LessonItem[] = ACADEMY_DATA.lessons.items
): MistakeLessonTarget {
  // 1. Check hard certificate questions
  const hardMatch = HARD_CERTIFICATE_QUESTIONS.find((q) => q.id === questionId);
  // 2. Check full MCQ bank
  const bankMatch = !hardMatch
    ? ACADEMY_DATA.quiz.questions.find((q) => q.id === questionId)
    : undefined;
  // 3. Check lesson-check prefix (e.g. lesson-check-lesson-4 or lesson-4-check-2)
  const lessonIdMatch =
    hardMatch?.lessonId ??
    bankMatch?.lessonId ??
    fallbackLessonId ??
    questionId.match(/(lesson-\d+)/)?.[1] ??
    lessons[0].id;

  const lesson = lessons.find((l) => l.id === lessonIdMatch) ?? lessons[0];
  const rawIdx =
    hardMatch?.sectionIndex ??
    bankMatch?.sectionIndex ??
    fallbackSectionIndex ??
    0;
  const safeIdx =
    rawIdx >= 0 && rawIdx < lesson.sections.length ? rawIdx : 0;

  return {
    unitId: lesson.unitId,
    unitName: lesson.unitName,
    lessonId: lesson.id,
    lessonTitle: `${lesson.numberLabel}: ${lesson.title}`,
    sectionIndex: safeIdx,
    sectionTitle: lesson.sections[safeIdx]?.title ?? lesson.title,
  };
}

export function buildMistakeFromQuizQuestion(
  q: QuizQuestion,
  selectedOptionIndex: number,
  source: 'question-bank' | 'adaptive-quiz'
): MistakeInput {
  return {
    questionId: q.id,
    source,
    question: q.question,
    formula: q.formula,
    options: [...q.options],
    selectedOptionIndex,
    correctIndex: q.correctIndex,
    explanation: q.explanation,
    difficulty: q.difficulty,
    lessonId: q.lessonId,
    sectionIndex: q.sectionIndex,
  };
}

export function buildMistakeFromLessonCheck(
  lesson: LessonItem,
  selectedOptionIndex: number
): MistakeInput {
  return {
    questionId: `lesson-check-${lesson.id}`,
    source: 'lesson-check',
    question: lesson.quickCheck.question,
    options: [...lesson.quickCheck.options],
    selectedOptionIndex,
    correctIndex: lesson.quickCheck.correctIndex,
    explanation: lesson.quickCheck.explanation,
    difficulty: lesson.level,
    lessonId: lesson.id,
    sectionIndex: 0,
  };
}

export function buildMistakeFromLessonPracticeMcq(
  lesson: LessonItem,
  check: LessonPracticeMcq,
  selectedOptionIndex: number
): MistakeInput {
  return {
    questionId: check.id,
    source: 'lesson-check',
    question: check.question,
    options: [...check.options],
    selectedOptionIndex,
    correctIndex: check.correctIndex,
    explanation: check.explanation,
    difficulty: lesson.level,
    lessonId: lesson.id,
    sectionIndex: 0,
  };
}

export function buildMistakeFromCertificateQuestion(
  q: HardChallengeQuestion,
  selectedOptionIndex: number
): MistakeInput {
  return {
    questionId: q.id,
    source: 'certificate-challenge',
    question: q.question,
    formula: q.formula,
    options: [...q.options],
    selectedOptionIndex,
    correctIndex: q.correctIndex,
    explanation: q.explanation,
    difficulty: 'متقدم جداً',
    lessonId: q.lessonId,
    sectionIndex: q.sectionIndex,
  };
}

export function upsertMistakeRecord(
  existing: readonly MistakeRecord[],
  input: MistakeInput,
  nowIso: string = new Date().toISOString()
): MistakeRecord[] {
  const target = resolveLessonExplanationTarget(
    input.questionId,
    input.lessonId,
    input.sectionIndex
  );
  const prev = existing.find((item) => item.questionId === input.questionId);
  const nextRecord: MistakeRecord = {
    questionId: input.questionId,
    source: input.source,
    sourceLabel: MISTAKE_SOURCE_LABELS[input.source],
    question: input.question,
    formula: input.formula,
    options: input.options,
    selectedOptionIndex: input.selectedOptionIndex,
    correctIndex: input.correctIndex,
    explanation: input.explanation,
    difficulty: input.difficulty,
    unitId: target.unitId,
    unitName: target.unitName,
    lessonId: target.lessonId,
    lessonTitle: target.lessonTitle,
    sectionIndex: target.sectionIndex,
    sectionTitle: target.sectionTitle,
    wrongCount: prev ? prev.wrongCount + 1 : 1,
    resolved: false,
    lastMissedAtIso: nowIso,
  };

  return [nextRecord, ...existing.filter((item) => item.questionId !== input.questionId)];
}

export function markMistakeResolved(
  existing: readonly MistakeRecord[],
  questionId: string,
  resolved: boolean
): MistakeRecord[] {
  return existing.map((item) =>
    item.questionId === questionId ? { ...item, resolved } : item
  );
}

export function removeMistakeRecord(
  existing: readonly MistakeRecord[],
  questionId: string
): MistakeRecord[] {
  return existing.filter((item) => item.questionId !== questionId);
}

export function filterMistakeRecords(
  records: readonly MistakeRecord[],
  filters: {
    status: 'all' | 'unresolved' | 'resolved';
    unitId: 'all' | 'unit1' | 'unit2' | 'unit3';
    source: 'all' | MistakeSource;
  }
): MistakeRecord[] {
  return records.filter((item) => {
    const statusOk =
      filters.status === 'all' ||
      (filters.status === 'unresolved' && !item.resolved) ||
      (filters.status === 'resolved' && item.resolved);
    const unitOk = filters.unitId === 'all' || item.unitId === filters.unitId;
    const sourceOk = filters.source === 'all' || item.source === filters.source;
    return statusOk && unitOk && sourceOk;
  });
}

export function computeMistakeSummary(records: readonly MistakeRecord[]): MistakeSummary {
  const totalCount = records.length;
  let unresolvedCount = 0;
  let resolvedCount = 0;
  const unitCounts = new Map<string, number>();

  for (const r of records) {
    if (r.resolved) {
      resolvedCount += 1;
    } else {
      unresolvedCount += 1;
      unitCounts.set(r.unitName, (unitCounts.get(r.unitName) ?? 0) + 1);
    }
  }

  let topWeakUnit: { unitName: string; count: number } | null = null;
  for (const [unitName, count] of unitCounts.entries()) {
    if (!topWeakUnit || count > topWeakUnit.count) {
      topWeakUnit = { unitName, count };
    }
  }

  return {
    totalCount,
    unresolvedCount,
    resolvedCount,
    topWeakUnit,
  };
}
