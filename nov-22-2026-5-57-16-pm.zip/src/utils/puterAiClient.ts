import { STRICT_SYSTEM_PROMPT } from './curriculumRag';

declare global {
  interface Window {
    puter?: {
      auth?: {
        isSignedIn?: () => boolean;
      };
      ai?: {
        chat: (
          prompt: string | Array<{ role: string; content: unknown }>,
          imageOrOptions?: unknown,
          options?: Record<string, unknown>
        ) => Promise<unknown>;
      };
    };
  }
}

export interface PuterChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface PuterCallOptions {
  userPrompt: string;
  ragContext: string;
  history?: PuterChatMessage[];
  imageDataUrl?: string | null;
  model?: string;
  extraSystemDirective?: string;
  timeoutMs?: number;
}

export interface PuterCallResult {
  ok: boolean;
  text: string;
  usedFallbackReason?: string;
}

function extractPuterResponseText(raw: unknown): string {
  if (typeof raw === 'string') return raw.trim();
  if (!raw || typeof raw !== 'object') return '';
  const obj = raw as Record<string, unknown>;
  if (typeof obj.text === 'string') return obj.text.trim();
  if (obj.message && typeof obj.message === 'object') {
    const msg = obj.message as Record<string, unknown>;
    if (typeof msg.content === 'string') return msg.content.trim();
    if (Array.isArray(msg.content)) {
      return msg.content
        .map((part) => {
          if (typeof part === 'string') return part;
          if (part && typeof part === 'object' && 'text' in part && typeof (part as { text: unknown }).text === 'string') {
            return (part as { text: string }).text;
          }
          return '';
        })
        .join('\n')
        .trim();
    }
  }
  if (Array.isArray(obj.choices) && obj.choices.length > 0) {
    const first = obj.choices[0] as Record<string, unknown>;
    const msg = first?.message as Record<string, unknown> | undefined;
    if (typeof msg?.content === 'string') return msg.content.trim();
  }
  return String(raw).trim();
}

export function isPuterAvailable(): boolean {
  return typeof window !== 'undefined' && typeof window.puter?.ai?.chat === 'function';
}

/**
 * Sends ONLY the user's question + retrieved curriculum RAG passages to window.puter.ai.chat
 * using 100% free Puter.js v2 (zero API keys, zero paid services).
 * Automatically returns { ok: false, usedFallbackReason } if Puter is offline, blocked, or
 * the student closes the free Puter sign-in popup, so the caller can show the Local RAG fallback seamlessly.
 */
export async function callFreePuterChat(opts: PuterCallOptions): Promise<PuterCallResult> {
  if (!isPuterAvailable()) {
    return {
      ok: false,
      text: '',
      usedFallbackReason: 'تعذّر الاتصال بخدمة Puter المجانية (وضع البحث المحلي المباشر)',
    };
  }

  const systemInstruction = [
    STRICT_SYSTEM_PROMPT,
    'قواعد تنسيق المعادلات: عند كتابة معادلات كيميائية أو قوانين رياضية، اكتب المعادلة بوضوح بين علامتي دولار مثل $Q = m \\times c \\times \\Delta t$ أو $\\ce{O2 + O <=> O3}$ ليتم عرضها بشكل احترافي.',
    opts.extraSystemDirective ?? '',
  ]
    .filter(Boolean)
    .join('\n');

  const groundedPrompt = `المقاطع المرجعية المستخرجة حصرياً من ملف التفكير/المنهج المرفق:\n${opts.ragContext}\n\n---\nسؤال / طلب الطالب:\n${opts.userPrompt}\n\nالتزم التزاماً مطلقاً بالمقاطع المرجعية أعلاه فقط دون أي إضافة خارجية.`;

  const isSignedIn = Boolean(window.puter?.auth?.isSignedIn?.());
  const timeoutMs = opts.timeoutMs ?? (isSignedIn ? 24000 : 10000);
  const model = opts.model || 'gpt-4o-mini';

  const runChat = async (): Promise<unknown> => {
    const chatFn = window.puter!.ai!.chat;
    if (opts.imageDataUrl) {
      // Multimodal Puter v2 call: pass image data URL alongside the strict grounded prompt
      const combinedPrompt = `${systemInstruction}\n\n${groundedPrompt}\n\nملاحظة للصورة المرفقة: اقرأ السؤال الموجود في الصورة واشرح خطوات الحل في حدود المقاطع المرجعية من المنهج المرفق فقط. إذا كان السؤال خارج المنهج المرفق، قل حرفياً: (هذا السؤال غير موجود في المنهج المرفق حالياً).`;
      return chatFn(combinedPrompt, opts.imageDataUrl, { model });
    }

    const recentHistory = (opts.history ?? []).slice(-6).map((m) => ({
      role: m.role,
      content: m.content,
    }));

    const messages = [
      { role: 'system', content: systemInstruction },
      ...recentHistory,
      { role: 'user', content: groundedPrompt },
    ];

    return chatFn(messages, { model });
  };

  try {
    const response = await Promise.race([
      runChat(),
      new Promise<never>((_, reject) =>
        window.setTimeout(() => reject(new Error('timeout')), timeoutMs)
      ),
    ]);

    const text = extractPuterResponseText(response);
    if (!text) {
      return {
        ok: false,
        text: '',
        usedFallbackReason: 'لم يُرجع النموذج نصاً (تم التبديل تلقائياً للعرض من ملف المنهج)',
      };
    }

    return { ok: true, text };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err ?? '');
    const reason =
      msg === 'timeout'
        ? 'انتهت مهلة الاتصال بـ Puter — تم استخراج الإجابة مباشرة من ملف المنهج'
        : 'تم إغلاق نافذة Puter أو انقطع الاتصال — تم عرض الفقرات المطابقة من ملف المنهج تلقائياً';
    return { ok: false, text: '', usedFallbackReason: reason };
  }
}
