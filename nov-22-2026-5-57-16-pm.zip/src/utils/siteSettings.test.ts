import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_SITE_SETTINGS,
  PALETTE_SWATCHES,
  getContainerMaxWidthCss,
  getRootFontSizePercent,
  normalizeSiteSettings,
} from './siteSettings';

test('normalizeSiteSettings returns clean defaults for null, undefined, or corrupt payloads', () => {
  assert.deepEqual(normalizeSiteSettings(null), DEFAULT_SITE_SETTINGS);
  assert.deepEqual(normalizeSiteSettings('broken'), DEFAULT_SITE_SETTINGS);
  assert.deepEqual(
    normalizeSiteSettings({
      palette: 'neon',
      fontScale: 250,
      density: 'huge',
      containerWidth: 'tiny',
      visualEffects: 'yes',
    }),
    DEFAULT_SITE_SETTINGS
  );
});

test('normalizeSiteSettings preserves valid custom formatting preferences', () => {
  const normalized = normalizeSiteSettings({
    palette: 'royal',
    isDark: false,
    fontScale: 108,
    density: 'comfortable',
    containerWidth: 'balanced',
    visualEffects: false,
    reducedMotion: true,
    showScrollProgress: false,
    highContrast: true,
  });

  assert.equal(normalized.palette, 'royal');
  assert.equal(normalized.isDark, false);
  assert.equal(normalized.fontScale, 108);
  assert.equal(normalized.density, 'comfortable');
  assert.equal(normalized.containerWidth, 'balanced');
  assert.equal(normalized.visualEffects, false);
  assert.equal(normalized.reducedMotion, true);
  assert.equal(normalized.showScrollProgress, false);
  assert.equal(normalized.highContrast, true);
});

test('formatting helper utilities map font scale, container width, and 6 swatches cleanly', () => {
  assert.equal(PALETTE_SWATCHES.length, 6);
  assert.equal(getRootFontSizePercent(116), '116%');
  assert.equal(getContainerMaxWidthCss('balanced'), '1240px');
  assert.equal(getContainerMaxWidthCss('wide'), '1480px');
  assert.equal(getContainerMaxWidthCss('full'), '100%');
});
