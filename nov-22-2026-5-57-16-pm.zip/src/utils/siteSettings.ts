import { normalizePalette, type PaletteId } from './academyState';

export type FontScaleOption = 92 | 100 | 108 | 116;
export type LayoutDensity = 'auto' | 'compact' | 'comfortable';
export type ContainerWidthMode = 'balanced' | 'wide' | 'full';

export interface SiteSettings {
  palette: PaletteId;
  isDark: boolean;
  fontScale: FontScaleOption;
  density: LayoutDensity;
  containerWidth: ContainerWidthMode;
  visualEffects: boolean;
  reducedMotion: boolean;
  showScrollProgress: boolean;
  highContrast: boolean;
}

export const SITE_SETTINGS_STORAGE_KEY = 'chem_site_settings_v1';

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  palette: 'emerald',
  isDark: true,
  fontScale: 100,
  density: 'auto',
  containerWidth: 'wide',
  visualEffects: true,
  reducedMotion: false,
  showScrollProgress: true,
  highContrast: false,
};

export interface PaletteSwatchMeta {
  id: PaletteId;
  labelAr: string;
  labelEn: string;
  primary: string;
  secondary: string;
}

export const PALETTE_SWATCHES: readonly PaletteSwatchMeta[] = [
  { id: 'emerald', labelAr: 'زمردي', labelEn: 'Emerald', primary: '#10b981', secondary: '#06b6d4' },
  { id: 'royal', labelAr: 'ملكي', labelEn: 'Royal', primary: '#3b82f6', secondary: '#6366f1' },
  { id: 'violet', labelAr: 'بنفسجي', labelEn: 'Violet', primary: '#8b5cf6', secondary: '#ec4899' },
  { id: 'gold', labelAr: 'ذهبي', labelEn: 'Gold', primary: '#f59e0b', secondary: '#fbbf24' },
  { id: 'ruby', labelAr: 'ياقوتي', labelEn: 'Ruby', primary: '#f43f5e', secondary: '#fb7185' },
  { id: 'ocean', labelAr: 'محيطي', labelEn: 'Ocean', primary: '#0ea5e9', secondary: '#14b8a6' },
];

export const FONT_SCALE_OPTIONS: readonly { value: FontScaleOption; label: string }[] = [
  { value: 92, label: 'صغير' },
  { value: 100, label: 'قياسي' },
  { value: 108, label: 'كبير' },
  { value: 116, label: 'مريح جداً' },
];

export const DENSITY_OPTIONS: readonly { value: LayoutDensity; label: string; hint: string }[] = [
  { value: 'auto', label: 'تلقائي للجهاز', hint: 'يضبط المقاسات تلقائياً للهاتف والكمبيوتر' },
  { value: 'compact', label: 'مكثّف (كمبيوتر)', hint: 'مساحات مضغوطة لعرض محتوى أكثر' },
  { value: 'comfortable', label: 'مريح (قراءة ولمس)', hint: 'تباعد أوسع وأزرار مريحة للمس' },
];

export const CONTAINER_WIDTH_OPTIONS: readonly { value: ContainerWidthMode; label: string }[] = [
  { value: 'balanced', label: 'متوازن (1240px)' },
  { value: 'wide', label: 'قياسي واسع (1480px)' },
  { value: 'full', label: 'ملء الشاشة' },
];

const VALID_FONT_SCALES = new Set<number>([92, 100, 108, 116]);
const VALID_DENSITIES = new Set<string>(['auto', 'compact', 'comfortable']);
const VALID_CONTAINERS = new Set<string>(['balanced', 'wide', 'full']);

export function normalizeSiteSettings(raw: unknown): SiteSettings {
  if (!raw || typeof raw !== 'object') {
    return { ...DEFAULT_SITE_SETTINGS };
  }
  const obj = raw as Record<string, unknown>;
  const fontScaleNum = Number(obj.fontScale);

  return {
    palette: normalizePalette(typeof obj.palette === 'string' ? obj.palette : undefined),
    isDark: typeof obj.isDark === 'boolean' ? obj.isDark : DEFAULT_SITE_SETTINGS.isDark,
    fontScale: VALID_FONT_SCALES.has(fontScaleNum)
      ? (fontScaleNum as FontScaleOption)
      : DEFAULT_SITE_SETTINGS.fontScale,
    density:
      typeof obj.density === 'string' && VALID_DENSITIES.has(obj.density)
        ? (obj.density as LayoutDensity)
        : DEFAULT_SITE_SETTINGS.density,
    containerWidth:
      typeof obj.containerWidth === 'string' && VALID_CONTAINERS.has(obj.containerWidth)
        ? (obj.containerWidth as ContainerWidthMode)
        : DEFAULT_SITE_SETTINGS.containerWidth,
    visualEffects:
      typeof obj.visualEffects === 'boolean'
        ? obj.visualEffects
        : DEFAULT_SITE_SETTINGS.visualEffects,
    reducedMotion:
      typeof obj.reducedMotion === 'boolean'
        ? obj.reducedMotion
        : DEFAULT_SITE_SETTINGS.reducedMotion,
    showScrollProgress:
      typeof obj.showScrollProgress === 'boolean'
        ? obj.showScrollProgress
        : DEFAULT_SITE_SETTINGS.showScrollProgress,
    highContrast:
      typeof obj.highContrast === 'boolean'
        ? obj.highContrast
        : DEFAULT_SITE_SETTINGS.highContrast,
  };
}

export function loadSiteSettings(): SiteSettings {
  if (typeof window === 'undefined') {
    return { ...DEFAULT_SITE_SETTINGS };
  }
  try {
    const raw = window.localStorage.getItem(SITE_SETTINGS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_SITE_SETTINGS };
    return normalizeSiteSettings(JSON.parse(raw));
  } catch {
    return { ...DEFAULT_SITE_SETTINGS };
  }
}

export function saveSiteSettings(settings: SiteSettings): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(SITE_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage quota errors
  }
}

export function getRootFontSizePercent(scale: FontScaleOption): string {
  return `${scale}%`;
}

export function getContainerMaxWidthCss(mode: ContainerWidthMode): string {
  if (mode === 'balanced') return '1240px';
  if (mode === 'full') return '100%';
  return '1480px';
}
