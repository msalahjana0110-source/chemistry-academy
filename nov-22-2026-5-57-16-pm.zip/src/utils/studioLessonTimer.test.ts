import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_LESSON_REVIEW_SECONDS,
  createInitialLessonTimers,
  formatCountdownClock,
  getCountdownProgress,
  pauseAllLessonCountdowns,
  resetLessonCountdown,
  setLessonDurationPreset,
  tickLessonCountdown,
  toggleLessonCountdown,
} from './studioLessonTimer';

test('createInitialLessonTimers initializes unique lesson entries with default 3-minute countdown', () => {
  const timers = createInitialLessonTimers([1, 2, 2, 14]);
  assert.equal(Object.keys(timers).length, 3);
  assert.equal(timers[1].durationSec, DEFAULT_LESSON_REVIEW_SECONDS);
  assert.equal(timers[1].remainingSec, 180);
  assert.equal(timers[1].status, 'idle');
  assert.equal(timers[14].completedSessions, 0);
});

test('toggleLessonCountdown starts target lesson and automatically pauses other running lessons', () => {
  let timers = createInitialLessonTimers([1, 2]);
  timers = toggleLessonCountdown(timers, 1);
  assert.equal(timers[1].status, 'running');
  assert.equal(timers[2].status, 'idle');

  timers = toggleLessonCountdown(timers, 2);
  assert.equal(timers[1].status, 'paused');
  assert.equal(timers[2].status, 'running');

  timers = pauseAllLessonCountdowns(timers);
  assert.equal(timers[2].status, 'paused');
});

test('tickLessonCountdown decrements only the active running lesson and marks completion at zero', () => {
  let timers = createInitialLessonTimers([1, 2], 60);
  timers = setLessonDurationPreset(timers, 1, 30);
  timers[1] = { ...timers[1], remainingSec: 2, status: 'running' };

  const step1 = tickLessonCountdown(timers, 1);
  assert.equal(step1.justCompleted, false);
  assert.equal(step1.nextTimers[1].remainingSec, 1);
  assert.equal(step1.nextTimers[2].remainingSec, 60);

  const step2 = tickLessonCountdown(step1.nextTimers, 1);
  assert.equal(step2.justCompleted, true);
  assert.equal(step2.nextTimers[1].remainingSec, 0);
  assert.equal(step2.nextTimers[1].status, 'completed');
  assert.equal(step2.nextTimers[1].completedSessions, 1);

  // Restarting a completed lesson refills remainingSec to full duration
  const restarted = toggleLessonCountdown(step2.nextTimers, 1);
  assert.equal(restarted[1].status, 'running');
  assert.equal(restarted[1].remainingSec, 30);
});

test('resetLessonCountdown, formatCountdownClock, and getCountdownProgress report exact metrics and urgency', () => {
  let timers = createInitialLessonTimers([3], 120);
  timers[3] = { ...timers[3], remainingSec: 25, status: 'paused' };

  assert.equal(formatCountdownClock(125).formatted, '02:05');
  assert.equal(formatCountdownClock(0).formatted, '00:00');
  assert.equal(getCountdownProgress(timers[3]).urgency, 'warning');
  assert.equal(getCountdownProgress({ ...timers[3], remainingSec: 8 }).urgency, 'critical');
  assert.equal(getCountdownProgress({ ...timers[3], remainingSec: 0 }).urgency, 'done');

  timers = resetLessonCountdown(timers, 3);
  assert.equal(timers[3].remainingSec, 120);
  assert.equal(timers[3].status, 'idle');
  assert.equal(getCountdownProgress(timers[3]).urgency, 'calm');
});
