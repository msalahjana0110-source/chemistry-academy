export type LessonCountdownStatus = 'idle' | 'running' | 'paused' | 'completed';

export interface LessonCountdownState {
  lessonNum: number;
  durationSec: number;
  remainingSec: number;
  status: LessonCountdownStatus;
  completedSessions: number;
}

export type LessonTimerMap = Record<number, LessonCountdownState>;

export const DEFAULT_LESSON_REVIEW_SECONDS = 3 * 60; // 3 minutes per lesson (5 cards)

export const LESSON_TIMER_PRESETS: ReadonlyArray<{ seconds: number; label: string }> = [
  { seconds: 2 * 60, label: '2 د' },
  { seconds: 3 * 60, label: '3 د' },
  { seconds: 5 * 60, label: '5 د' },
  { seconds: 10 * 60, label: '10 د' },
];

export function createInitialLessonTimers(
  lessonNums: ReadonlyArray<number>,
  defaultDurationSec: number = DEFAULT_LESSON_REVIEW_SECONDS
): LessonTimerMap {
  const safeDuration = Math.max(30, Math.round(defaultDurationSec));
  const map: LessonTimerMap = {};
  for (const num of lessonNums) {
    if (!map[num]) {
      map[num] = {
        lessonNum: num,
        durationSec: safeDuration,
        remainingSec: safeDuration,
        status: 'idle',
        completedSessions: 0,
      };
    }
  }
  return map;
}

export function ensureLessonTimer(
  timers: LessonTimerMap,
  lessonNum: number,
  defaultDurationSec: number = DEFAULT_LESSON_REVIEW_SECONDS
): LessonCountdownState {
  return (
    timers[lessonNum] ?? {
      lessonNum,
      durationSec: defaultDurationSec,
      remainingSec: defaultDurationSec,
      status: 'idle',
      completedSessions: 0,
    }
  );
}

export function toggleLessonCountdown(
  timers: LessonTimerMap,
  lessonNum: number
): LessonTimerMap {
  const current = ensureLessonTimer(timers, lessonNum);
  const nextMap: LessonTimerMap = { ...timers };

  // Pause any other running lesson timer so only one lesson ticks at a time
  for (const key of Object.keys(nextMap)) {
    const num = Number(key);
    if (num !== lessonNum && nextMap[num].status === 'running') {
      nextMap[num] = { ...nextMap[num], status: 'paused' };
    }
  }

  if (current.status === 'running') {
    nextMap[lessonNum] = { ...current, status: 'paused' };
  } else {
    const remaining = current.remainingSec <= 0 ? current.durationSec : current.remainingSec;
    nextMap[lessonNum] = {
      ...current,
      remainingSec: remaining,
      status: 'running',
    };
  }

  return nextMap;
}

export function pauseAllLessonCountdowns(timers: LessonTimerMap): LessonTimerMap {
  let changed = false;
  const nextMap: LessonTimerMap = { ...timers };
  for (const key of Object.keys(nextMap)) {
    const num = Number(key);
    if (nextMap[num].status === 'running') {
      nextMap[num] = { ...nextMap[num], status: 'paused' };
      changed = true;
    }
  }
  return changed ? nextMap : timers;
}

export function tickLessonCountdown(
  timers: LessonTimerMap,
  lessonNum: number
): { nextTimers: LessonTimerMap; justCompleted: boolean } {
  const current = timers[lessonNum];
  if (!current || current.status !== 'running') {
    return { nextTimers: timers, justCompleted: false };
  }

  if (current.remainingSec <= 1) {
    return {
      nextTimers: {
        ...timers,
        [lessonNum]: {
          ...current,
          remainingSec: 0,
          status: 'completed',
          completedSessions: current.completedSessions + 1,
        },
      },
      justCompleted: true,
    };
  }

  return {
    nextTimers: {
      ...timers,
      [lessonNum]: {
        ...current,
        remainingSec: current.remainingSec - 1,
      },
    },
    justCompleted: false,
  };
}

export function setLessonDurationPreset(
  timers: LessonTimerMap,
  lessonNum: number,
  durationSec: number
): LessonTimerMap {
  const safeDuration = Math.max(30, Math.round(durationSec));
  const current = ensureLessonTimer(timers, lessonNum, safeDuration);
  return {
    ...timers,
    [lessonNum]: {
      ...current,
      durationSec: safeDuration,
      remainingSec: safeDuration,
      status: 'idle',
    },
  };
}

export function resetLessonCountdown(
  timers: LessonTimerMap,
  lessonNum: number
): LessonTimerMap {
  const current = ensureLessonTimer(timers, lessonNum);
  return {
    ...timers,
    [lessonNum]: {
      ...current,
      remainingSec: current.durationSec,
      status: 'idle',
    },
  };
}

export function formatCountdownClock(totalSeconds: number): {
  mm: string;
  ss: string;
  formatted: string;
} {
  const clamped = Math.max(0, Math.floor(totalSeconds));
  const mm = String(Math.floor(clamped / 60)).padStart(2, '0');
  const ss = String(clamped % 60).padStart(2, '0');
  return { mm, ss, formatted: `${mm}:${ss}` };
}

export type CountdownUrgency = 'calm' | 'warning' | 'critical' | 'done';

export function getCountdownProgress(state: LessonCountdownState): {
  remainingRatio: number;
  elapsedPct: number;
  urgency: CountdownUrgency;
} {
  const total = Math.max(1, state.durationSec);
  const clampedRemaining = Math.max(0, Math.min(total, state.remainingSec));
  const remainingRatio = clampedRemaining / total;
  const elapsedPct = Math.round((1 - remainingRatio) * 100);

  let urgency: CountdownUrgency = 'calm';
  if (clampedRemaining === 0) {
    urgency = 'done';
  } else if (clampedRemaining <= 10) {
    urgency = 'critical';
  } else if (clampedRemaining <= 30 || remainingRatio <= 0.25) {
    urgency = 'warning';
  }

  return { remainingRatio, elapsedPct, urgency };
}
